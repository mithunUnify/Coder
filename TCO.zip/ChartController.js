app.controller("CostByCategory", function ($scope, $http, $rootScope, sampleService) {
    $scope.$on('CostingByCategory', function (event, data) {

        $scope.selectedYear = sampleService.years;
        $scope.arrayObj = [];
        for (var i = 2; i <= sampleService.years; i++)
            $scope.arrayObj.push(i);
        $scope.TableData = data.CostBreakDown;
        $scope.Total = { AzureCost: GetCost('Azure', data.CostBreakDown), OnPremisesCost: GetCost('OnPremises', data.CostBreakDown), };
        $scope.electricity = new kendo.data.DataSource({
            data: GetYearChartObject(data.CostBreakDown, sampleService.years, sampleService.serverGrowth, sampleService.sa, sampleService.DiscountStatus, sampleService.IsUserCostSavedStatus1, $scope)
        });
        sampleService.YearCostObject = GetCostCalculationObject(data.CostBreakDown, sampleService.years, sampleService.serverGrowth, sampleService.sa, sampleService.DiscountStatus, sampleService.DBID, $scope, sampleService);
        sampleService.DetailedYearCostObject = GetCostCalculationDetailsObject(data.CostBreakDown, sampleService.years, sampleService.serverGrowth, sampleService.sa, sampleService.DiscountStatus, sampleService.DBID, $scope, sampleService);
        //HBC include clash flow
        sampleService.DetailedYearCostObject_HBC = GetCostCalculationDetailsObject_HBC(data.CostBreakDown_HBC, sampleService.years, sampleService.serverGrowth, sampleService.sa, sampleService.DiscountStatus, sampleService.DBID, $scope, sampleService);
        $scope.serverGrowth = sampleService.serverGrowth;
        $rootScope.$$childTail.$$childTail.loader = false;
        $scope.EditOnPrem = [];
        $scope.EditAzure = [];
        for (var i = 0; i < sampleService.DetailedYearCostObject.length; i++) {
            if (sampleService.DetailedYearCostObject[i].Type == "Compute" || sampleService.DetailedYearCostObject[i].Type == "Networking" || sampleService.DetailedYearCostObject[i].Type == "Storage") {
                for (var j = 0; j < sampleService.DetailedYearCostObject[i].SubItems.length; j++) {
                    var valueToPush = new Object();
                    valueToPush.Type = sampleService.DetailedYearCostObject[i].SubItems[j].Type;
                    valueToPush.Price = Math.round(sampleService.DetailedYearCostObject[i].SubItems[j].OnPremise * 100) / 100;
                    valueToPush.ModelName = "" + sampleService.DetailedYearCostObject[i].SubItems[j].Type + "_" + (sampleService.DetailedYearCostObject[i].Year).split(" ")[0];
                    $scope.EditOnPrem.push(valueToPush);


                    valueToPush = new Object();
                    valueToPush.Type = sampleService.DetailedYearCostObject[i].SubItems[j].Type;
                    valueToPush.Price = Math.round(sampleService.DetailedYearCostObject[i].SubItems[j].Azure * 100) / 100;
                    valueToPush.ModelName = "" + sampleService.DetailedYearCostObject[i].SubItems[j].Type + "_azure" + (sampleService.DetailedYearCostObject[i].Year).split(" ")[0];
                    $scope.EditAzure.push(valueToPush);

                }
            }
            else {
                var valueToPush = new Object();
                valueToPush.Type = sampleService.DetailedYearCostObject[i].Type;
                valueToPush.Price = Math.round(sampleService.DetailedYearCostObject[i].OnPremise * 100) / 100;
                valueToPush.ModelName = "" + sampleService.DetailedYearCostObject[i].Type + "_" + (sampleService.DetailedYearCostObject[i].Year).split(" ")[0];
                $scope.EditOnPrem.push(valueToPush);

                valueToPush = new Object();
                valueToPush.Type = sampleService.DetailedYearCostObject[i].Type;
                valueToPush.Price = Math.round(sampleService.DetailedYearCostObject[i].Azure * 100) / 100;
                valueToPush.ModelName = "" + sampleService.DetailedYearCostObject[i].Type + "_azure" + (sampleService.DetailedYearCostObject[i].Year).split(" ")[0];
                $scope.EditAzure.push(valueToPush);
            }
        }
        sampleService.EditOnPrem = $scope.EditOnPrem;
        sampleService.EditAzure = $scope.EditAzure;
    });
    //For Edit Option in On_prem.
    $scope.EditOnPremisePrices = function () {
        var AD = sampleService.UserCostSavedInDb;
        if (AD === undefined || AD.length > 0) {
            $scope.saveEditOnprmiseAssumption();
        }
    };
    //For Edit Option in On_prem if Already Saved.
    $scope.saveEditOnprmiseAssumption = function () {
        // $('#EditPopup').modal('toggle');
        $scope.loader = true;
        var planSelected = sampleService.plan === undefined || sampleService.plan === null ? 'threeyearmls' : sampleService.plan;
        //var tcoType = sampleService.tcoType === undefined || sampleService.tcoType === null || sampleService.tcoType === 'all' ? 'all' : 'sql';
        var tcoType = sampleService.tcoType === undefined || sampleService.tcoType === null || sampleService.tcoType === 'all' ? 'all' : sampleService.tcoType === 'sql' ? 'sql' : 'postgre';
        var planNew = sampleService.planNew === undefined || sampleService.planNew === null ? 'threeyearmls' : sampleService.planNew;
        var planPostgre = sampleService.planNewPostgre === undefined || sampleService.planNewPostgre === null ? 'threeyear' : sampleService.planNewPostgre;

        $scope.MasterData =
            {
                sqlType: sampleService.sqlType,
                tcoType: tcoType,
                plan: planSelected,
                planNew: planNew,
                planPostgre: planPostgre,
                years: sampleService.years
            };
        sampleService.MasterData = $scope.MasterData;
        $http.post('TCOCalculator.aspx/saveAssumption', {
            phy: sampleService.PhySer,
            Datab1: sampleService.DatabaseAssumptions,
            SQLVersionLicenseDetail1: sampleService.vw_SQLVersionLicenseDetail,
            StorageSave: sampleService.CoustumerInput,
            YearCostDetail: sampleService.RentingBenifits,
            Migration: sampleService.MigrationExcel[0],
            CashFlow: sampleService.CashFlowExcel,
            Assumptions: sampleService.Assumptions,
            SoftwareCostAssumption: sampleService.softCostAssumption,
            SaveYearCostDetails: sampleService.DetailedYearCostObject,
            MasterData: sampleService.MasterData
        }).then(function (response) {
            $('#EditPopup').modal('toggle');
            $scope.loader = true;
            EditCost = [];
            EditCost.push({ Category: "Hardware", Year1: $('#1Hardware_1').val() == "" ? 0 : $('#1Hardware_1').val(), Year2: $('#1Hardware_2').val() == "" ? 0 : $('#1Hardware_2').val(), Year3: $('#1Hardware_3').val() == "" ? 0 : $('#1Hardware_3').val(), Year4: $('#1Hardware_4').val() == "" ? 0 : $('#1Hardware_4').val(), Year5: $('#1Hardware_5').val() == "" ? 0 : $('#1Hardware_5').val() });
            EditCost.push({ Category: "Hardware Maintenance Cost", Year1: $("[id='1Hardware Maintenance Cost_1']").val() == "" ? 0 : $("[id='1Hardware Maintenance Cost_1']").val(), Year2: $("[id='1Hardware Maintenance Cost_2']").val() == "" ? 0 : $("[id='1Hardware Maintenance Cost_2']").val(), Year3: $("[id='1Hardware Maintenance Cost_3']").val() == "" ? 0 : $("[id='1Hardware Maintenance Cost_3']").val(), Year4: $("[id='1Hardware Maintenance Cost_4']").val() == "" ? 0 : $("[id='1Hardware Maintenance Cost_4']").val(), Year5: $("[id='1Hardware Maintenance Cost_5']").val() == "" ? 0 : $("[id='1Hardware Maintenance Cost_5']").val() });
            EditCost.push({ Category: "Software (Linux)", Year1: $("[id='1Software (Linux)_1']").val() == "" ? 0 : $("[id='1Software (Linux)_1']").val(), Year2: $("[id='1Software (Linux)_2']").val() == "" ? 0 : $("[id='1Software (Linux)_2']").val(), Year3: $("[id='1Software (Linux)_3']").val() == "" ? 0 : $("[id='1Software (Linux)_3']").val(), Year4: $("[id='1Software (Linux)_4']").val() == "" ? 0 : $("[id='1Software (Linux)_4']").val(), Year5: $("[id='1Software (Linux)_5']").val() == "" ? 0 : $("[id='1Software (Linux)_5']").val() });
            EditCost.push({ Category: "Software (Windows)", Year1: $("[id='1Software (Windows)_1']").val() == "" ? 0 : $("[id='1Software (Windows)_1']").val(), Year2: $("[id='1Software (Windows)_2']").val() == "" ? 0 : $("[id='1Software (Windows)_2']").val(), Year3: $("[id='1Software (Windows)_3']").val() == "" ? 0 : $("[id='1Software (Windows)_3']").val(), Year4: $("[id='1Software (Windows)_4']").val() == "" ? 0 : $("[id='1Software (Windows)_4']").val(), Year5: $("[id='1Software (Windows)_5']").val() == "" ? 0 : $("[id='1Software (Windows)_5']").val() });
            EditCost.push({ Category: "Electricity", Year1: $('#1Electricity_1').val() == "" ? 0 : $('#1Electricity_1').val(), Year2: $('#1Electricity_2').val() == "" ? 0 : $('#1Electricity_2').val(), Year3: $('#1Electricity_3').val() == "" ? 0 : $('#1Electricity_3').val(), Year4: $('#1Electricity_4').val() == "" ? 0 : $('#1Electricity_4').val(), Year5: $('#1Electricity_5').val() == "" ? 0 : $('#1Electricity_5').val() });
            EditCost.push({ Category: "Bandwidth", Year1: $('#1Bandwidth_1').val() == "" ? 0 : $('#1Bandwidth_1').val(), Year2: $('#1Bandwidth_2').val() == "" ? 0 : $('#1Bandwidth_2').val(), Year3: $('#1Bandwidth_3').val() == "" ? 0 : $('#1Bandwidth_3').val(), Year4: $('#1Bandwidth_4').val() == "" ? 0 : $('#1Bandwidth_4').val(), Year5: $('#1Bandwidth_5').val() == "" ? 0 : $('#1Bandwidth_5').val() });//Network hardware and software cost 
            EditCost.push({ Category: "Azure Advisor", Year1: $("[id='1Azure Advisor_1']").val() == "" ? 0 : $("[id='1Azure Advisor_1']").val(), Year2: $("[id='1Azure Advisor_2']").val() == "" ? 0 : $("[id='1Azure Advisor_2']").val(), Year3: $("[id='1Azure Advisor_3']").val() == "" ? 0 : $("[id='1Azure Advisor_3']").val(), Year4: $("[id='1Azure Advisor_4']").val() == "" ? 0 : $("[id='1Azure Advisor_4']").val(), Year5: $("[id='1Azure Advisor_5']").val() == "" ? 0 : $("[id='1Azure Advisor_5']").val() });//Network maintenance cost 
            EditCost.push({ Category: "Azure Security Center", Year1: $("[id='1Azure Security Center_1']").val() == "" ? 0 : $("[id='1Azure Security Center_1']").val(), Year2: $("[id='1Azure Security Center_2']").val() == "" ? 0 : $("[id='1Azure Security Center_2']").val(), Year3: $("[id='1Azure Security Center_3']").val() == "" ? 0 : $("[id='1Azure Security Center_3']").val(), Year4: $("[id='1Azure Security Center_4']").val() == "" ? 0 : $("[id='1Azure Security Center_4']").val(), Year5: $("[id='1Azure Security Center_5']").val() == "" ? 0 : $("[id='1Azure Security Center_5']").val() });//Service provider cost 
            EditCost.push({ Category: "Storage hardware cost", Year1: $("[id='1Storage hardware cost_1']").val() == "" ? 0 : $("[id='1Storage hardware cost_1']").val(), Year2: $("[id='1Storage hardware cost_2']").val() == "" ? 0 : $("[id='1Storage hardware cost_2']").val(), Year3: $("[id='1Storage hardware cost_3']").val() == "" ? 0 : $("[id='1Storage hardware cost_3']").val(), Year4: $("[id='1Storage hardware cost_4']").val() == "" ? 0 : $("[id='1Storage hardware cost_4']").val(), Year5: $("[id='1Storage hardware cost_5']").val() == "" ? 0 : $("[id='1Storage hardware cost_5']").val() });
            EditCost.push({ Category: "Backup and Archive cost", Year1: $("[id='1Backup and Archive cost_1']").val() == "" ? 0 : $("[id='1Backup and Archive cost_1']").val(), Year2: $("[id='1Backup and Archive cost_2']").val() == "" ? 0 : $("[id='1Backup and Archive cost_2']").val(), Year3: $("[id='1Backup and Archive cost_3']").val() == "" ? 0 : $("[id='1Backup and Archive cost_3']").val(), Year4: $("[id='1Backup and Archive cost_4']").val() == "" ? 0 : $("[id='1Backup and Archive cost_4']").val(), Year5: $("[id='1Backup and Archive cost_5']").val() == "" ? 0 : $("[id='1Backup and Archive cost_5']").val() });
            EditCost.push({ Category: "Storage Maintenance cost", Year1: $("[id='1Storage Maintenance cost_1']").val() == "" ? 0 : $("[id='1Storage Maintenance cost_1']").val(), Year2: $("[id='1Storage Maintenance cost_2']").val() == "" ? 0 : $("[id='1Storage Maintenance cost_2']").val(), Year3: $("[id='1Storage Maintenance cost_3']").val() == "" ? 0 : $("[id='1Storage Maintenance cost_3']").val(), Year4: $("[id='1Storage Maintenance cost_4']").val() == "" ? 0 : $("[id='1Storage Maintenance cost_4']").val(), Year5: $("[id='1Storage Maintenance cost_5']").val() == "" ? 0 : $("[id='1Storage Maintenance cost_5']").val() });
            EditCost.push({ Category: "IT Labor", Year1: $("[id='1IT Labor_1']").val() == "" ? 0 : $("[id='1IT Labor_1']").val(), Year2: $("[id='1IT Labor_2']").val() == "" ? 0 : $("[id='1IT Labor_2']").val(), Year3: $("[id='1IT Labor_3']").val() == "" ? 0 : $("[id='1IT Labor_3']").val(), Year4: $("[id='1IT Labor_4']").val() == "" ? 0 : $("[id='1IT Labor_4']").val(), Year5: $("[id='1IT Labor_5']").val() == "" ? 0 : $("[id='1IT Labor_5']").val() });
            EditCost.push({ Category: "BizTalk", Year1: $('#1BizTalk_1').val() == "" ? 0 : $('#1BizTalk_1').val(), Year2: $('#1BizTalk_2').val() == "" ? 0 : $('#1BizTalk_2').val(), Year3: $('#1BizTalk_3').val() == "" ? 0 : $('#1BizTalk_3').val(), Year4: $('#1BizTalk_4').val() == "" ? 0 : $('#1BizTalk_4').val(), Year5: $('#1BizTalk_5').val() == "" ? 0 : $('#1BizTalk_5').val() });
            EditCost.push({ Category: "Sql License Cost", Year1: $("[id='1Sql License Cost_1']").val() == "" ? 0 : $("[id='1Sql License Cost_1']").val(), Year2: $("[id='1Sql License Cost_2']").val() == "" ? 0 : $("[id='1Sql License Cost_2']").val(), Year3: $("[id='1Sql License Cost_3']").val() == "" ? 0 : $("[id='1Sql License Cost_3']").val(), Year4: $("[id='1Sql License Cost_4']").val() == "" ? 0 : $("[id='1Sql License Cost_4']").val(), Year5: $("[id='1Sql License Cost_5']").val() == "" ? 0 : $("[id='1Sql License Cost_5']").val() });
            EditCost.push({ Category: "Virtualization Cost", Year1: $("[id='1Virtualization Cost_1']").val() == "" ? 0 : $("[id='1Virtualization Cost_1']").val(), Year2: $("[id='1Virtualization Cost_2']").val() == "" ? 0 : $("[id='1Virtualization Cost_2']").val(), Year3: $("[id='1Virtualization Cost_3']").val() == "" ? 0 : $("[id='1Virtualization Cost_3']").val(), Year4: $("[id='1Virtualization Cost_4']").val() == "" ? 0 : $("[id='1Virtualization Cost_4']").val(), Year5: $("[id='1Virtualization Cost_5']").val() == "" ? 0 : $("[id='1Virtualization Cost_5']").val() });
            EditCost.push({ Category: "DR Cost", Year1: $("[id='1DR Cost_1']").val() == "" ? 0 : $("[id='1DR Cost_1']").val(), Year2: $("[id='1DR Cost_2']").val() == "" ? 0 : $("[id='1DR Cost_2']").val(), Year3: $("[id='1DR Cost_3']").val() == "" ? 0 : $("[id='1DR Cost_3']").val(), Year4: $("[id='1DR Cost_4']").val() == "" ? 0 : $("[id='1DR Cost_4']").val(), Year5: $("[id='1DR Cost_5']").val() == "" ? 0 : $("[id='1DR Cost_5']").val() });
            EditCost.push({ Category: "Data Center", Year1: $("[id='1Data Center_1']").val() == "" ? 0 : $("[id='1Data Center_1']").val(), Year2: $("[id='1Data Center_2']").val() == "" ? 0 : $("[id='1Data Center_2']").val(), Year3: $("[id='1Data Center_3']").val() == "" ? 0 : $("[id='1Data Center_3']").val(), Year4: $("[id='1Data Center_4']").val() == "" ? 0 : $("[id='1Data Center_4']").val(), Year5: $("[id='1Data Center_5']").val() == "" ? 0 : $("[id='1Data Center_5']").val() });
            EditCost.push({ Category: "Sa(SQL)", Year1: $("[id='1Sa(SQL)_1']").val() == "" ? 0 : $("[id='1Sa(SQL)_1']").val(), Year2: $("[id='1Sa(SQL)_2']").val() == "" ? 0 : $("[id='1Sa(SQL)_2']").val(), Year3: $("[id='1Sa(SQL)_3']").val() == "" ? 0 : $("[id='1Sa(SQL)_3']").val(), Year4: $("[id='1Sa(SQL)_4']").val() == "" ? 0 : $("[id='1Sa(SQL)_4']").val(), Year5: $("[id='1Sa(SQL)_5']").val() == "" ? 0 : $("[id='1Sa(SQL)_5']").val() });
            EditCost.push({ Category: "Sa(Windows License)", Year1: $("[id='1Sa(Windows License)_1']").val() == "" ? 0 : $("[id='1Sa(Windows License)_1']").val(), Year2: $("[id='1Sa(Windows License)_2']").val() == "" ? 0 : $("[id='1Sa(Windows License)_2']").val(), Year3: $("[id='1Sa(Windows License)_3']").val() == "" ? 0 : $("[id='1Sa(Windows License)_3']").val(), Year4: $("[id='1Sa(Windows License)_4']").val() == "" ? 0 : $("[id='1Sa(Windows License)_4']").val(), Year5: $("[id='1Sa(Windows License)_5']").val() == "" ? 0 : $("[id='1Sa(Windows License)_5']").val() });
            EditCost.push({ Category: "Oracle License", Year1: $("[id='1Oracle License_1']").val() == "" ? 0 : $("[id='1Oracle License_1']").val(), Year2: $("[id='1Oracle License_2']").val() == "" ? 0 : $("[id='1Oracle License_2']").val(), Year3: $("[id='1Oracle License_3']").val() == "" ? 0 : $("[id='1Oracle License_3']").val(), Year4: $("[id='1Oracle License_4']").val() == "" ? 0 : $("[id='1Oracle License_4']").val(), Year5: $("[id='1Oracle License_5']").val() == "" ? 0 : $("[id='1Oracle License_5']").val() });
            EditCost.push({ Category: "Sa(Oracle)", Year1: $("[id='1Sa(Oracle)_1']").val() == "" ? 0 : $("[id='1Sa(Oracle)_1']").val(), Year2: $("[id='1Sa(Oracle)_2']").val() == "" ? 0 : $("[id='1Sa(Oracle)_2']").val(), Year3: $("[id='1Sa(Oracle)_3']").val() == "" ? 0 : $("[id='1Sa(Oracle)_3']").val(), Year4: $("[id='1Sa(Oracle)_4']").val() == "" ? 0 : $("[id='1Sa(Oracle)_4']").val(), Year5: $("[id='1Sa(Oracle)_5']").val() == "" ? 0 : $("[id='1Sa(Oracle)_5']").val() });

            EditCost.push({ Category: "Sa(Linux License)", Year1: $("[id='1Sa(Linux License)_1']").val() == "" ? 0 : $("[id='1Sa(Linux License)_1']").val(), Year2: $("[id='1Sa(Linux License)_2']").val() == "" ? 0 : $("[id='1Sa(Linux License)_2']").val(), Year3: $("[id='1Sa(Linux License)_3']").val() == "" ? 0 : $("[id='1Sa(Linux License)_3']").val(), Year4: $("[id='1Sa(Linux License)_4']").val() == "" ? 0 : $("[id='1Sa(Linux License)_4']").val(), Year5: $("[id='1Sa(Linux License)_5']").val() == "" ? 0 : $("[id='1Sa(Linux License)_5']").val() });
            $.ajax({
                url: "TCOCalculator.aspx/SaveOnPreEditData",
                type: 'post',
                contentType: 'application/json; charset=UTF-8',
                data: JSON.stringify({ Editlist: EditCost }),
                dataType: 'json',
                async: false,
                success: function (data) {
                    window.location.reload(true);
                },
                error: function (request, error) {
                    console.log(arguments);
                }
            });
        }, function (error) {
            console.log(error);
        });
    };
    //Software Cost Logic.
    $scope.GetGrowthPrice = function (cost, rate, year, type) {
        //if (sampleService.IsUserCostSavedStatus1 == true && sampleService.IsAzureCostSavedStatus == true && type == "IT Labour") {
        //    var total;
        //    angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
        //        if ((value.Year.search(year) == 0) && ((value.Type.toLowerCase() == "it labor"))) {
        //            total = value.Azure;
        //        }
        //    });
        //    return total;
        //}
        if (sampleService.DiscountStatus != 1) {
            year = year - 1;

            if (year == 0)
                return cost;
            else {
                if (type != null) {
                    if (type.toLowerCase().indexOf("license") !== -1) {
                        return cost;
                    }
                    else {
                        var C = cost * (Math.pow((1 + (rate / 100)), year) - 1);
                        var Total = (cost + C);
                        return Total;
                    }
                }
                else {
                    var C = cost * (Math.pow((1 + (rate / 100)), year) - 1);
                    var Total = (cost + C);
                    return Total;
                }
                
            }
        }

    };
    $scope.GetGrowthPriceAzure = function (cost, rate, year, type) {
        //if (sampleService.IsUserCostSavedStatus1 == true && sampleService.IsAzureCostSavedStatus == true && type == "IT Labour") {
        //    var total;
        //    angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
        //        if ((value.Year.search(year) == 0) && ((value.Type.toLowerCase() == "it labor"))) {
        //            total = value.Azure;
        //        }
        //    });
        //    return total;
        //}
        if (sampleService.DiscountStatus != 1) {
            year = year - 1;

            if (year == 0)
                return cost;
            else {
                var C = cost * (Math.pow((1 + (rate / 100)), year) - 1);
                var Total = (cost + C);
                return Total;
            }
        }

    };
    //
    $scope.GetTotalGrowthPriceWithAssurance = function (item, rate, year) {
        var total = 0;
        year = year - 1;
        angular.forEach(item.SubItems, function (value, key) {
            if (value.Type.toLowerCase().indexOf("license") !== -1) {
                total += value.Cost;
            }
            else {
                var C1 = value.Cost * (Math.pow((1 + (rate / 100)), year) - 1);
                var C2 = C1 + value.Cost;
                total += C2;
            }
           
        });
        return total;
    };

    //Total compute of Azure
    $scope.GetTotalGrowthPriceWithAssuranceAZure = function (item, rate, year) {
        var total = 0;
        year = year - 1;
        angular.forEach(item.SubItemsAzure, function (value, key) {
            if (value.Type.toLowerCase().indexOf("license") !== -1) {
                total += value.Cost;
            }
            else {
                var C1 = value.Cost * (Math.pow((1 + (rate / 100)), year) - 1);
                var C2 = C1 + value.Cost;
                total += C2;
            }
        });
        return total;
    };

    // Unused Method
    $scope.GetGrowthPriceWithAssurance = function (item, rate, year) {
        var total = 0;
        if (item.Type === 'Sql License Cost') {
            if (year === 0) {
                return item.Cost;

            } else {
                var C = item.Cost * (Math.pow((1 + (rate / 100)), year) - 1);
                var totaldbCost = C + item.Cost;
                var M = totaldbCost * sampleService.sa / 100;
                total += M + totaldbCost;
            }
        }
        else {
            if (year === 0) return item.Cost; else {
                var C1 = item.Cost * (Math.pow((1 + (rate / 100)), year) - 1);
                total += C1 + item.Cost;
            }
        }
        return total;
    };
    //On_premise SA CostCalculation. 
    $scope.GetGrowthPriceWithAssurance1 = function (item, rate, year, data, Type) {
        var M = 0;
        if (sampleService.DiscountStatus != 1) {
            year = year - 1;
            var saPeriod = sampleService.saPeriod;
            var saCostPer = sampleService.sa;
            angular.forEach(data, function (value, key) {
                if ((Type === 'SQL' && value.Type === 'Sql License Cost') || (Type === 'Windows' && value.Type === 'Software (Windows)') || (Type === 'linux' && value.Type === 'Software (Linux)')) {
                    if (year < saPeriod) {
                        return 0;
                    }
                    else {
                        M = ((value.Cost * saCostPer / 100) * 3) / 2;
                    }
                }
                else if ((Type === 'Oracle' && value.Type === 'Oracle License')) {
                    M = value.Cost * 22 / 100;
                }
            });
        }
        else {
            M = 0;
        }
        return M;
    }
    //Get Total On-Premise and Azure Cost
    $scope.GetTotal = function (data, rate, year, type) {
        var total = 0;
        if (type == 'onPremises') {
            if (year == 0) {
                angular.forEach(data, function (value, key) {
                    total += value.onPremises;
                });
            }
            else {
                angular.forEach(data, function (value, key) {
                    if (value.Category != 'Compute') {
                        cost = $scope.GetGrowthPrice(value.onPremises, rate, year);
                    }
                    else {
                        cost = $scope.GetTotalGrowthPriceWithAssurance(value, rate, year);
                    }
                    total += cost;
                });
            }
        }
        else {
            if (year == 0) {
                angular.forEach(data, function (value, key) {
                    total += value.Azure;
                });
            }
            else {
                angular.forEach(data, function (value, key) {
                    if (value.Category != 'Compute') {
                        cost = $scope.GetGrowthPrice(value.Azure, rate, year);
                    }
                    else {
                        cost = $scope.GetTotalGrowthPriceWithAssuranceAZure(value, rate, year);
                    }
                    total += cost;
                });
            }
        }
        return total;
    };
    //Get Total 5 Year Cost On-Premise and Azure Cost
    $scope.GetTotalFiveYearCost = function (data, rate, year, type) {
        var totalFiveYearCost = 0;
        var i = 0;
        if (type == 'onPremises') {
            angular.forEach(data, function (value, key) {
                if (value.Category == "Compute") {
                    angular.forEach(value.SubItems, function (value12, key) {
                        if (value12.Type.toLowerCase().indexOf("license") !== -1) {
                            var C = 0;
                            for (i = 0; i < year; i++) {
                                    totalFiveYearCost += value12.Cost;
                            }
                        }
                        else {
                                var C = 0;
                                for (i = 0; i < year; i++) {
                                    C = value12.Cost * (Math.pow((1 + (rate / 100)), i) - 1);
                                        totalFiveYearCost += (value12.Cost + C);
                                }
                            }
                    });
                }
                else {
                    var total = 0;
                    var C = 0;
                    for (i = 0; i < year; i++) {
                        C = value.onPremises * (Math.pow((1 + (rate / 100)), i) - 1);
                        total += (value.onPremises + C);
                    }
                    totalFiveYearCost += total;
                }
                
            });
        }
        else {
            angular.forEach(data, function (value, key) {
                if (value.Category == "Compute") {
                    angular.forEach(value.SubItemsAzure, function (value12, key) {
                        if (value12.Type.toLowerCase().indexOf("license") !== -1) {
                            var C = 0;
                            for (i = 0; i < year; i++) {
                                totalFiveYearCost += value12.Cost;
                            }
                        }
                        else {
                            var C = 0;
                            for (i = 0; i < year; i++) {
                                C = value12.Cost * (Math.pow((1 + (rate / 100)), i) - 1);
                                totalFiveYearCost += (value12.Cost + C);
                            }
                        }
                    });
                }
                else {
                    var total = 0;
                    var C = 0;
                    for (i = 0; i < year; i++) {
                        C = value.Azure * (Math.pow((1 + (rate / 100)), i) - 1);
                        total += (value.Azure + C);
                    }
                    totalFiveYearCost += total;
                }
               
            });
        }
        return totalFiveYearCost;
    };
    //Get Total Onpremise Cost Except 1st Year(In Case Of Save Data).
    $scope.GetSavedTotal = function (data, serverGrowth, year, type) {
        var total = 0;
        if (sampleService.IsUserCostSavedStatus1 === true) {
            if (type === 'onPremises') {
                if (year === 0) {
                    angular.forEach(data, function (value, key) {
                        total += value.onPremises;
                    });
                }
                else {
                    angular.forEach(data, function (value, key) {
                        if (value.Category !== 'Compute') {
                            if ((value.Category === "Data Center" || value.Category === "Networking" || value.Category === "Storage")) {
                                cost = $scope.GetSavedTotalGrowthPrice(value.onPremises, serverGrowth, year, value.Category, value.SubItems);
                            }
                            else
                                cost = $scope.GetSavedTotalGrowthPrice(value.onPremises, serverGrowth, year, value.Category, value.SubItems);
                        }
                        else {
                            cost = $scope.GetSavedTotalCost(value, value.SubItems, serverGrowth, year);
                        }
                        total += cost;
                    });

                }

            }

            else {
                if (year === 0) {
                    angular.forEach(data, function (value, key) {
                        total += value.Azure;
                    });
                }
                else {
                    angular.forEach(data, function (value, key) {
                        if (value.Category !== 'Compute') {
                            if ((value.Category === "Data Center" || value.Category === "Networking" || value.Category === "Storage")) {
                                cost = $scope.GetSavedTotalGrowthPriceAzure(value.Azure, serverGrowth, year, value.Category, value.SubItemsAzure);
                            }
                            else
                                cost = $scope.GetSavedTotalGrowthPriceAzure(value.Azure, serverGrowth, year, value.Category, value.SubItemsAzure);
                        }
                        else {
                            cost = $scope.GetSavedTotalCostAzure(value, value.SubItems, serverGrowth, year);
                        }
                        total += cost;
                    });

                }
            }
        }
        return total;
    };

    //Get Total 5 Year Onpremise Cost Except 1st Year(In Case Of Save Data).
    $scope.GetSavedTotalFiveYearCost = function (data, serverGrowth, year, type) {
        var i = 0;
        var totalFiveYearCost = 0;
        if (sampleService.IsUserCostSavedStatus1 === true) {
            if (type === 'onPremises') {
                angular.forEach(sampleService.EditOnPrem, function (value, key) {
                    totalFiveYearCost += value.Price;
                });
            }
            else if (type === 'Azure') {

                angular.forEach(sampleService.EditAzure, function (value, key) {
                    totalFiveYearCost += value.Price;
                });
            }
        }
        return totalFiveYearCost;
    };
    // For Onpremise & Azure Total
    $scope.GetSavedTotalCost = function (item, subItems, growthrate, year) {
        var total = 0;
        if (sampleService.IsUserCostSavedStatus1 == true) {
            if (item.Category == "Compute") {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    angular.forEach(subItems, function (value1, key1) {
                        if ((value.Year.search(year) == 0) && ((value.Type.toLowerCase() == value1.Type.toLowerCase()))) {
                            total += value.OnPremise;
                        }
                    });
                });
            }
        }

        return total;
    };
    $scope.GetSavedTotalCostAzure = function (item, subItemsAzure, growthrate, year) {
        var total = 0;
        if (sampleService.IsUserCostSavedStatus1 == true) {
            if (item.Category == "Compute") {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    angular.forEach(subItemsAzure, function (value1, key1) {
                        if ((value.Year.search(year) == 0) && ((value.Type.toLowerCase() == value1.Type.toLowerCase()))) {
                            total += value.Azure;
                        }
                    });
                });
            }
        }

        return total;
    };
    // For Compute OnPremise Cost
    $scope.GetSavedTotalGrowthPrice = function (onPremises, serverGrowth, i, Category, subItems, type) {
        var total = 0;
        var NetworkingTotal = 0;
        var StorageTotal = 0;
        if (sampleService.IsUserCostSavedStatus1 == true) {
            if (Category == "Networking") {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    angular.forEach(subItems, function (value1, key1) {
                        if ((value.Year.search(i) == 0) && (value1.Type == "Network hardware and software cost") && (value.Type.toLowerCase() == "bandwidth")) {
                            NetworkingTotal += value.OnPremise;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Network maintenance cost") && (value.Type.toLowerCase() == "azure advisor")) {
                            NetworkingTotal += value.OnPremise;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Service provider cost") && (value.Type.toLowerCase() == "azure security center")) {
                            NetworkingTotal += value.OnPremise;
                        }
                    });
                });
                return NetworkingTotal;
            }
            else if (Category == "Storage") {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    angular.forEach(subItems, function (value1, key1) {
                        if ((value.Year.search(i) == 0) && (value1.Type == "Storage hardware cost") && (value.Type.toLowerCase() == "storage hardware cost")) {
                            StorageTotal += value.OnPremise;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Backup and Archive cost") && (value.Type.toLowerCase() == "backup and archive cost")) {
                            StorageTotal += value.OnPremise;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Storage Maintenance cost") && (value.Type.toLowerCase() == "storage maintenance cost")) {
                            StorageTotal += value.OnPremise;
                        }
                    });
                });
                return StorageTotal;
            }
            else {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    if ((value.Year.search(i) == 0) && (value.Type.toLowerCase() == Category.toLowerCase())) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "IT Labor") && (value.Type.toLowerCase() == "it labor")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Sa(SQL)") && (value.Type.toLowerCase() == "sa(sql)")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Sa(Windows License)") && (value.Type.toLowerCase() == "sa(windows license)")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Sa(Linux License)") && (value.Type.toLowerCase() == "sa(linux license)")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Sa(Oracle)") && (value.Type.toLowerCase() == "sa(oracle)")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Network hardware and software cost") && (value.Type.toLowerCase() == "bandwidth")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Network maintenance cost") && (value.Type.toLowerCase() == "azure advisor")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Service provider cost") && (value.Type.toLowerCase() == "azure security center")) {
                        total = value.OnPremise;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "DR Cost") && (value.Type.toLowerCase() == "dr cost")) {
                        total = value.OnPremise;
                    }
                });
                return total;
            }
        }
    }
    //Total Growth Price Of Azure in Case Of Save Data
    $scope.GetSavedTotalGrowthPriceAzure = function (Azure, serverGrowth, i, Category, subItemsAzure, type, item) {
        var total = 0;
        var NetworkingTotal = 0;
        var StorageTotal = 0;
        var computeTotal = 0;
        if (sampleService.IsUserCostSavedStatus1 == true) {
            if (Category == "Networking") {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    angular.forEach(subItemsAzure, function (value1, key1) {
                        if ((value.Year.search(i) == 0) && (value1.Type == "Bandwidth") && (value.Type.toLowerCase() == "bandwidth")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Advisor") && (value.Type.toLowerCase() == "azure advisor")) {
                            NetworkingTotal += value.Azure;
                        }
                        //else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Security Center") && (value.Type.toLowerCase() == "azure security center")) {
                        //    NetworkingTotal += value.Azure;
                        //}
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Active Directory") && (value.Type.toLowerCase() == "azure active directory")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Application Gateway") && (value.Type.toLowerCase() == "application gateway")) {
                            NetworkingTotal += value.Azure;
                        }
                        //else if ((value.Year.search(i) == 0) && (value1.Type == "Backup") && (value.Type.toLowerCase() == "backup")) {
                        //    NetworkingTotal += value.Azure;
                        //}
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Traffic Manager") && (value.Type.toLowerCase() == "traffic manager")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Network Watcher") && (value.Type.toLowerCase() == "network watcher")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Loadbalancer") && (value.Type.toLowerCase() == "loadbalancer")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Express Route") && (value.Type.toLowerCase() == "express route")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Virtual Network") && (value.Type.toLowerCase() == "virtual network")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "IP Addresses") && (value.Type.toLowerCase() == "ip addresses")) {
                            NetworkingTotal += value.Azure;
                        }
                        //else if ((value.Year.search(i) == 0) && (value1.Type == "VPN Gateway") && (value.Type.toLowerCase() == "vpn gateway")) {
                        //    NetworkingTotal += value.Azure;
                        //}
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Log Analytics") && (value.Type.toLowerCase() == "log analytics")) {
                            NetworkingTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Key Vault") && (value.Type.toLowerCase() == "key vault")) {
                            NetworkingTotal += value.Azure;
                        }
                    });
                });
                return NetworkingTotal;
            }
            else if (Category == "Storage") {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    angular.forEach(subItemsAzure, function (value1, key1) {
                        if ((value.Year.search(i) == 0) && (value1.Type == "Cost Of Managed Disk") && (value.Type.toLowerCase() == "storage hardware cost")) {
                            StorageTotal += value.Azure;
                        }
                        else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Backup") && (value.Type.toLowerCase() == "backup and archive cost")) {
                            StorageTotal += value.Azure;
                        }

                    });
                });
                return StorageTotal;
            }
            else {
                angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
                    if ((value.Year.search(i) == 0) && (value.Type.toLowerCase() == Category.toLowerCase())) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "IT Labor") && (value.Type.toLowerCase() == "it labor")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Cost Of Managed Disk") && (value.Type.toLowerCase() == "storage hardware cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure Backup") && (value.Type.toLowerCase() == "backup and archive cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure VM") && (value.Type.toLowerCase() == "hardware")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure SQL VM") && (value.Type.toLowerCase() == "hardware maintenance cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure SQL MI") && (value.Type.toLowerCase() == "hardware maintenance cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure SQL VCore") && (value.Type.toLowerCase() == "hardware maintenance cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure SQL Instance Pool") && (value.Type.toLowerCase() == "hardware maintenance cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure SQL Elastic Pool") && (value.Type.toLowerCase() == "hardware maintenance cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure Linux VM") && (value.Type.toLowerCase() == "software (linux)")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Biztalk") && (value.Type.toLowerCase() == "bizTalk")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "PostgreSQL(Oracle)") && (value.Type.toLowerCase() == "sql license cost")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Oracle License Cost") && (value.Type.toLowerCase() == "oracle license")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Oracle SA(License)") && (value.Type.toLowerCase() == "sa(oracle)")) {
                        total = value.Azure;
                    }
                    else if ((value.Year.search(i) == 0) && (Category == "Azure DR Cost") && (value.Type.toLowerCase() == "dr cost")) {
                        total = value.Azure;
                    }
                });
                return total;
            }
        }
        else if (sampleService.IsUserCostSavedStatus1 == true && sampleService.IsAzureCostSavedStatus == false) {
            var year = i;
            year = year - 1;
            var cost = item.Azure;
            var rate = serverGrowth;
            if (year == 0)
                return cost;
            var C = cost * (Math.pow((1 + (rate / 100)), year) - 1);
            var Total = (cost + C);
            return Total;
        }


    } // For Saved Azure Cost

    // Except Compute OnPremise Cost

    //$scope.GetSavedTotalGrowthPriceAzure = function (Azure, serverGrowth, i, Category, subItems, type) {
    //    var total = 0;
    //    var NetworkingTotal = 0;
    //    var StorageTotal = 0;
    //    if (sampleService.IsUserCostSavedStatus1 == true) {
    //        if (Category == "Networking") {
    //            angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
    //                angular.forEach(subItems, function (value1, key1) {
    //                    if ((value.Year.search(i) == 0) && (value1.Type == "Bandwidth") && (value.Type.toLowerCase() == "bandwidth")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Advisor") && (value.Type.toLowerCase() == "azure advisor")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Security Center") && (value.Type.toLowerCase() == "azure security center")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Azure Active Directory") && (value.Type.toLowerCase() == "azure active directory")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Application Gateway") && (value.Type.toLowerCase() == "application gateway")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Backup") && (value.Type.toLowerCase() == "backup")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Traffic Manager") && (value.Type.toLowerCase() == "traffic manager")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Network Watcher") && (value.Type.toLowerCase() == "network watcher")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Loadbalancer") && (value.Type.toLowerCase() == "loadbalancer")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Express Route") && (value.Type.toLowerCase() == "express route")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Virtual Network") && (value.Type.toLowerCase() == "virtual network")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "IP Addresses") && (value.Type.toLowerCase() == "ip addresses")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "VPN Gateway") && (value.Type.toLowerCase() == "vpn gateway")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Log Analytics") && (value.Type.toLowerCase() == "log analytics")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Key Vault") && (value.Type.toLowerCase() == "key vault")) {
    //                        NetworkingTotal += value.Azure;
    //                    }
    //                });
    //            });
    //            return NetworkingTotal;
    //        }
    //        else if (Category == "Storage") {
    //            angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
    //                angular.forEach(subItems, function (value1, key1) {
    //                    if ((value.Year.search(i) == 0) && (value1.Type == "Cost Of Managed Disk") && (value.Type.toLowerCase() == "storage hardware cost")) {
    //                        StorageTotal += value.Azure;
    //                    }
    //                    else if ((value.Year.search(i) == 0) && (value1.Type == "Page blob storage cost") && (value.Type.toLowerCase() == "backup and archive cost")) {
    //                        StorageTotal += value.Azure;
    //                    }

    //                });
    //            });
    //            return StorageTotal;
    //        }
    //        else {
    //            angular.forEach(sampleService.UserCostSavedInDb, function (value, key) {
    //                if ((value.Year.search(i) == 0) && (value.Type.toLowerCase() == Category.toLowerCase())) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "IT Labour") && (value.Type.toLowerCase() == "it labor")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Cost Of Managed Disk") && (value.Type.toLowerCase() == "storage hardware cost")) {
    //                    total = value.Azure;

    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Page blob storage cost") && (value.Type.toLowerCase() == "backup and archive cost")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Azure VM") && (value.Type.toLowerCase() == "hardware")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Azure SQL VM") && (value.Type.toLowerCase() == "hardware maintanence cost")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Azure Linux VM") && (value.Type.toLowerCase() == "software (linux)")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Biztalk") && (value.Type.toLowerCase() == "bizTalk")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Oracle License Cost") && (value.Type.toLowerCase() == "oracle license")) {
    //                    total = value.Azure;
    //                }
    //                else if ((value.Year.search(i) == 0) && (Category == "Oracle SA(License)") && (value.Type.toLowerCase() == "sa(oracle)")) {
    //                    total = value.Azure;
    //                }
    //            });
    //            return total;
    //        }
    //    }
    //} // Except Compute Azure  Cost


    //Check if cloud is costly or not
    $scope.GetVsCheck = function () {
        if (sampleService.IsUserCostSavedStatus1 === false) {
            var OnpremCost = $scope.GetTotalFiveYearCost($scope.TableData, $scope.serverGrowth, $scope.selectedYear, 'onPremises');
            var AzureCost = $scope.GetTotalFiveYearCost($scope.TableData, $scope.serverGrowth, $scope.selectedYear, 'Azure');
            if (OnpremCost / AzureCost > 1) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            var OnpremCost = $scope.GetSavedTotalFiveYearCost($scope.TableData, $scope.serverGrowth, $scope.selectedYear, 'onPremises');
            var AzureCost = $scope.GetSavedTotalFiveYearCost($scope.TableData, $scope.serverGrowth, $scope.selectedYear, 'Azure');
            if (OnpremCost / AzureCost > 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }
});
function GetGrowthPriceWithAssurance(sa, rate, year, data) {

    var M = 0;
    angular.forEach(data, function (value, key) {
        if (value.Type === 'Database') {
            var C = value.Cost * (Math.pow((1 + (rate / 100)), year) - 1);
            var totaldbCost = C + value.Cost;
            M = totaldbCost * sa / 100;
        }
    });
    return M;
}
//Calculate License Cost Of OnPrem.
function GetGrowthPriceWithAssurance1(sa, rate, year, data, Type, dis) {
    var M = 0;
    if (dis != 1) {
        angular.forEach(data, function (value, key) {
            if ((Type === 'Windows' && value.Type === 'Software (Windows)') || (Type === 'Software (Linux)' && value.Type === 'Software (Linux)')) {
                M = ((value.Cost * sa / 100));
            }
            else if (Type === 'Oracle' && value.Type === 'Oracle License') {
                M = value.Cost * 22 / 100;
            }
        });
    }
    else {
        M = 0;
    }
    return M;
}
//Calculate Sub-Items Value Compute(OnPremises and Azure).
function GetYearCost(cost, rate, year, type) {
    if (year == 0) {
        return cost;
    }
    else {
        if (type.toLowerCase().indexOf("license") !== -1) {
            return cost;
        }
        else {
            var C = cost * (Math.pow((1 + (rate / 100)), year) - 1);
            var Total = (cost + C);
            return Total;
        }
    }
};
//Calculate Sub-Items Value Computeonly(OnPremises and Azure).
function GetYearCostCompute(SubItems, rate, year, type) {
    var computeTotal = 0;
    angular.forEach(SubItems, function (value, key) {
            if (value.Type.toLowerCase().indexOf("license") !== -1) {
                computeTotal += value.Cost;
            }
            else {
                var C = value.Cost * (Math.pow((1 + (rate / 100)), year) - 1);
                computeTotal += (value.Cost + C);
            }
    });
    return computeTotal;
};
function GetYearDiscount(cost, rate, year, type) {

    if (year == 0)
        return cost;
    var C = cost * (Math.pow((1 + (rate / 100)), year) - 1);
    var Total = (C)

    return Total;
}
//Used for Total Cost of Azure and OnPremises.
function GetCost(Type, CostBreakDown) {
    var total = 0;
    if (Type == 'Azure') {
        angular.forEach(CostBreakDown, function (value, key) {
            total += value.Azure;
        });
    }
    else {
        angular.forEach(CostBreakDown, function (value, key) {
            total += value.onPremises;
        });
    }
    return total;
}
// Used for Bar Chart.
function GetYearChartObject(CostbreackDownObject, year, growth, sa, dis, IsUserCostSavedStatus, $scope) {

    var x = [];
    var OnpreCost = GetCost('OnPremises', CostbreackDownObject);
    var OnAzuCost = GetCost('Azure', CostbreackDownObject);
    if (IsUserCostSavedStatus == true) {
        for (var i = 1; i <= year; i++) {
            var item = {
                OnPremise: $scope.GetSavedTotal($scope.TableData, growth, i, 'onPremises'),
                Azure: $scope.GetSavedTotal($scope.TableData, growth, i, 'Azure'),
                Year: (i) + ' Year'
            };
            x.push(item);
        }
    }
    else {
        for (var i = 0; i < year; i++) {
            var item = {
                OnPremise: GetYearCost(OnpreCost, growth, i, 'OnPremises'),
                Azure: GetYearCost(OnAzuCost, growth, i, 'Azure'),
                Year: (i + 1) + ' Year'
            };
            x.push(item);
        }
    }
    return x;
}

//Used For Excel Sheet Executive Summary.
function GetCostCalculationObject(CostbreackDownObject, year, growth, sa, dis, DBID, $scope, sampleService) {
    var x = [];
    if (sampleService.IsUserCostSavedStatus1 == true && sampleService.IsAzureCostSavedStatus == true) {
        var OnpreCost = GetCost('OnPremises', CostbreackDownObject); var OnAzuCost = GetCost('Azure', CostbreackDownObject);
        for (var i = 0; i < year; i++) {
            var item = {
                OnPremise: $scope.GetSavedTotalCost($scope.TableData[0], $scope.TableData[0].SubItems, growth, i + 1), Azure: $scope.GetSavedTotalCostAzure($scope.TableData[0], $scope.TableData[0].SubItems, growth, i + 1)
            };
            x.push(item);
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[1].onPremises, growth, i + 1, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[1].Azure, growth, i + 1, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'Azure', $scope.TableData[1]), Year: (i + 1) + ' Year', Type: 'Data Center'
            };
            x.push(item);
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[2].onPremises, growth, i + 1, $scope.TableData[2].Category, $scope.TableData[2].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[2].Azure, growth, i + 1, $scope.TableData[2].Category, $scope.TableData[2].SubItemsAzure, 'Azure')             /*networking Azure*/
            };
            x.push(item);
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[3].onPremises, growth, i + 1, $scope.TableData[3].Category, $scope.TableData[3].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[3].Azure, growth, i + 1, $scope.TableData[3].Category, $scope.TableData[3].SubItemsAzure, 'Azure')          /*Storage Azure*/
            };
            x.push(item);
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[4].onPremises, growth, i + 1, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[4].Azure, growth, i + 1, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'Azure', $scope.TableData[4]), Year: (i + 1) + ' Year', Type: 'IT Labor'
            };
            x.push(item);
            var item = {
                OnPremise: GetYearCost(OnpreCost, growth, i + 1, 'onPremises'), Azure: GetYearCost(OnAzuCost, growth, i, 'Azure'), Year: (i + 1) + ' Year', Type: 'Total'
            };
            x.push(item);
        }
    }
    else if (sampleService.IsUserCostSavedStatus1 == true && sampleService.IsAzureCostSavedStatus == false) {
        var OnpreCost = GetCost('OnPremises', CostbreackDownObject); var OnAzuCost = GetCost('Azure', CostbreackDownObject);
        for (var i = 0; i < year; i++) {
            if (i == 0) {
                var item = { OnPremise: $scope.GetSavedTotalCost($scope.TableData[0], $scope.TableData[0].SubItems, growth, i+1), Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'), Year: (i + 1) + ' Year', Type: 'Compute' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[1].onPremises, growth, i + 1, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[2].onPremises, growth, i + 1, $scope.TableData[2].Category, $scope.TableData[2].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'), Year: (i + 1) + ' Year', Type: 'Networking' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[3].onPremises, growth, i + 1, $scope.TableData[3].Category, $scope.TableData[3].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'), Year: (i + 1) + ' Year', Type: 'Storage' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[4].onPremises, growth, i + 1, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'onPremises') , Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                x.push(item);
                var item = { OnPremise: GetYearCost(OnpreCost, growth, i+1, 'onPremises'), Azure: GetYearCost(OnAzuCost, growth, i, 'Azure'), Year: (i + 1) + ' Year', Type: 'Total' };
                x.push(item);
            }
            else {
                var item = { OnPremise: $scope.GetSavedTotalCost($scope.TableData[0], $scope.TableData[0].SubItems, growth, i + 1), Azure: GetYearCostCompute(CostbreackDownObject[0].SubItemsAzure, growth, i, 'Compute'), Year: (i + 1) + ' Year', Type: 'Compute' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[1].onPremises, growth, i + 1, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[2].onPremises, growth, i + 1, $scope.TableData[2].Category, $scope.TableData[2].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'), Year: (i + 1) + ' Year', Type: 'Networking' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[3].onPremises, growth, i + 1, $scope.TableData[3].Category, $scope.TableData[3].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'), Year: (i + 1) + ' Year', Type: 'Storage' };
                x.push(item);
                var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[4].onPremises, growth, i + 1, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                x.push(item);
                var item = { OnPremise: GetYearCost(OnpreCost, growth, i + 1, 'onPremises'), Azure: GetYearCost(OnAzuCost, growth, i, 'Azure'), Year: (i + 1) + ' Year', Type: 'Total' };
                x.push(item);
            }
        }
    }
    else {
        var OnpreCost = GetCost('OnPremises', CostbreackDownObject); var OnAzuCost = GetCost('Azure', CostbreackDownObject);
        for (var i = 0; i < year; i++) {
            if (i == 0) {
                var item = { OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'), Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'), Year: (i + 1) + ' Year', Type: 'Compute' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'), Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'), Year: (i + 1) + ' Year', Type: 'Networking' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'), Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'), Year: (i + 1) + ' Year', Type: 'Storage' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                x.push(item);
                var item = { OnPremise: GetYearCost(OnpreCost, growth, i, 'onPremises'), Azure: GetYearCost(OnAzuCost, growth, i, 'Azure'), Year: (i + 1) + ' Year', Type: 'Total' };
                x.push(item);
            }
            else {
                var item = { OnPremise: GetYearCostCompute(CostbreackDownObject[0].SubItems, growth, i, 'Compute'), Azure: GetYearCostCompute(CostbreackDownObject[0].SubItemsAzure, growth, i, 'Compute'), Year: (i + 1) + ' Year', Type: 'Compute' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'), Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'), Year: (i + 1) + ' Year', Type: 'Networking' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'), Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'), Year: (i + 1) + ' Year', Type: 'Storage' };
                x.push(item);
                var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                x.push(item);
                var item = { OnPremise: GetYearCost(OnpreCost, growth, i, 'onPremises'), Azure: GetYearCost(OnAzuCost, growth, i, 'Azure'), Year: (i + 1) + ' Year', Type: 'Total' };
                x.push(item);
            }
        }

    }
    return x;
}
//Used For Excel Sheet On-premise_Details & Azure Details.
function GetCostCalculationDetailsObject(CostbreackDownObject, year, growth, sa, dis, DBID, $scope, sampleService) {
    var x = [];
    if (sampleService.IsUserCostSavedStatus == true && sampleService.IsAzureCostSavedStatus == true) {
        for (var i = 1; i <= year; i++) {
            var item = {
                OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                Year: (i) + ' Year', Type: 'Compute',
                SubItems: [
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Hardware', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Hardware', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Hardware'
                    },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Hardware Maintenance Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Hardware Maintenance Cost', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Hardware Maintenance Cost' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Software (Linux)', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Software (Linux)', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Software (Linux)' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Software (Windows)', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Software (Windows)', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Software (Windows)' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'BizTalk', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'BizTalk', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'BizTalk' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Electricity', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Electricity', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Electricity' },
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Sql License Cost',
                            $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Sql License Cost', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Sql License Cost'
                    },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Sa(SQL)', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Sa(SQL)', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Sa(SQL)' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Sa(Windows License)', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Sa(Windows License)', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Sa(Windows License)' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Sa(Linux License)', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Sa(Linux License)', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Sa(Linux License)' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Oracle License', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Oracle License', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Oracle License' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Sa(Oracle)', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Sa(Oracle)', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Sa(Oracle)' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Virtualization Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i) + ' Year', Type: 'Virtualization Cost' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'DR Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, 'Azure DR Cost', $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'DR Cost' }
                ],
            };
            x.push(item);
            var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[1].onPremises, growth, i, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[1].Azure, growth, i, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'Azure', $scope.TableData[1]), Year: (i) + ' Year', Type: 'Data Center' };
            x.push(item);
            var item = {
                OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                Year: (i) + ' Year', Type: 'Networking',
                SubItems: [
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Network hardware and software cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[0].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Bandwidth' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Network maintenance cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[1].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Azure Advisor' },
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Service provider cost', $scope.TableData[0].SubItems, 'onPremises'),
                        //Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[2].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Azure Security Center'
                        Azure: 0.0, Type: 'Azure Security Center'
                    },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[2].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Azure Active Directory' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[3].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Application Gateway' },
                    //{ OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[5].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Backup' },

                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[4].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Traffic Manager' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[5].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Network Watcher' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[6].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Loadbalancer' },

                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[7].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Express Route' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[8].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Virtual Network' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[9].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'IP Addresses' },

                    //{ OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[12].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'VPN Gateway' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[10].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Log Analytics' },
                    { OnPremise: 0.0, Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[0].Azure, growth, i, sampleService.viewMoreDetail[11].Type, $scope.TableData[0].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Key Vault' },

                ],
            };
            x.push(item);
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[3].onPremises, growth, i, $scope.TableData[3].Category, $scope.TableData[3].SubItems, 'onPremises'),
                Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[3].Azure, growth, i, $scope.TableData[3].Category, $scope.TableData[3].SubItems, 'Azure', $scope.TableData[3]),
                Year: (i) + ' Year', Type: 'Storage',
                SubItems: [
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Storage hardware cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[3].Azure, growth, i, 'Storage hardware cost', $scope.TableData[3].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Storage hardware cost'
                    },
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Backup and Archive cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[3].Azure, growth, i, 'Backup and Archive cost', $scope.TableData[3].SubItems, 'Azure'), Year: (i) + ' Year', Type: 'Backup and Archive cost'
                    },
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i, 'Storage Maintenance cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i) + ' Year', Type: 'Storage Maintenance cost'
                    },
                ],
            };
            x.push(item);
            var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[4].onPremises, growth, i, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'onPremises'), Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[4].Azure, growth, i, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'Azure', $scope.TableData[4]), Year: (i) + ' Year', Type: 'IT Labor' };
            x.push(item);
        }
    }
    else if (sampleService.IsUserCostSavedStatus == true && sampleService.IsAzureCostSavedStatus == false) {
        for (var i = 0; i < year; i++) {
            if (i == 0) {
                var item = {
                    OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                    Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                    Year: (i + 1) + ' Year', Type: 'Compute',
                    SubItems: [
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Hardware', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Hardware Maintenance Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Software (Linux)', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Software (Windows)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'BizTalk', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalk'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Electricity', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                        {
                            OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sql License Cost', $scope.TableData[0].SubItems, 'onPremises'),
                            Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                        },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(SQL)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(Windows License)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(Linux License)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Oracle License', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(Oracle)', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Virtualization Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'DR Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                    ],
                };
                x.push(item);
            }
            else {
                var item = {
                    OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                    Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                    Year: (i + 1) + ' Year', Type: 'Compute',
                    SubItems: [
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Hardware', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Hardware Maintenance Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Software (Linux)', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Software (Windows)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'BizTalk', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Electricity', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                        {
                            OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sql License Cost', $scope.TableData[0].SubItems, 'onPremises'),
                            Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                        },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(SQL)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(Windows License)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(Linux License)', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Oracle License', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License', Year: (i + 1) + ' Year', Type: 'Oracle License' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Sa(Oracle)', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Sa(Oracle)', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Virtualization Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                        { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'DR Cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                    ],
                };
                x.push(item);
            }
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[1].onPremises, growth, i + 1, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'onPremises'),
                //Azure: $scope.GetSavedTotalGrowthPriceAzure($scope.TableData[1].Azure, growth, i, $scope.TableData[1].Category, $scope.TableData[1].SubItems, 'Azure', $scope.TableData[1]), Year: (i + 1) + ' Year', Type: 'Data Center'
                Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center'
            };
            x.push(item);
            var item = {
                OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                Year: (i + 1) + ' Year', Type: 'Networking',
                SubItems: [
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Network hardware and software cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Network maintenance cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                    {
                        OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Service provider cost', $scope.TableData[0].SubItems, 'onPremises'),
                       // Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center'
                        Azure: 0.0, Type: 'Azure Security Center'
                    },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                    //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                    //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                    { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                ],
            };
            x.push(item);
            var item = {
                OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[3].onPremises, growth, i + 1, $scope.TableData[3].Category, $scope.TableData[3].SubItems, 'onPremises'),
                Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                Year: (i + 1) + ' Year', Type: 'Storage',
                SubItems: [
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Storage hardware cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Backup and Archive cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                    { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[0].onPremises, growth, i + 1, 'Storage Maintenance cost', $scope.TableData[0].SubItems, 'onPremises'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                ],
            };
            x.push(item);
            var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[4].onPremises, growth, i + 1, $scope.TableData[4].Category, $scope.TableData[4].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
            x.push(item);
            //var item = { OnPremise: $scope.GetSavedTotalGrowthPrice($scope.TableData[5].onPremises, growth, i + 1, $scope.TableData[5].Category, $scope.TableData[5].SubItems, 'onPremises'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
            //x.push(item);
        }
    }
    else {
        if (dis != 1) {
            for (var i = 0; i < year; i++) {
                if (i == 0) {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, growth, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, growth, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, growth, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'), 
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center' 
                                Azure: 0.0, Type: 'Azure Security Center'
                            },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                    //var item = { OnPremise: GetYearCost(CostbreackDownObject[5].onPremises, growth, i, 'End Point'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
                    //x.push(item);
                }
                else {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, growth, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, growth, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, growth, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License Cost', Year: (i + 1) + ' Year', Type: 'Oracle License' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Sa(Oracle) Azure', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'), 
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center'
                                Azure: 0.0, Type: 'Azure Security Center'
                            },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                }
            }
        }
        else {
            for (var i = 0; i < year; i++) {
                if (i == 0) {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, growth, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, growth, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, growth, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License Cost', Year: (i + 1) + ' Year', Type: 'Oracle License'
                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Oracle SA(License)', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'), 
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center' 
                                Azure: 0.0, Type: 'Azure Security Center'
                            },
                            
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                    //var item = { OnPremise: GetYearCost(CostbreackDownObject[5].onPremises, growth, i, 'End Point'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
                    //x.push(item);

                }
                else {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, 0, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, 0, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, 0, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License Cost"', Year: (i + 1) + ' Year', Type: 'Oracle License' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Oracle SA(License)', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'), 
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center' 
                                Azure: 0.0, Type: 'Azure Security Center'
                            },
                            
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                    //var item = { OnPremise: GetYearCost(CostbreackDownObject[5].onPremises, growth, i, 'End Point'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
                    //x.push(item);
                }
            }
        }
    }
    return x;
}
function GetCostCalculationDetailsObject_HBC(CostbreackDownObject, year, growth, sa, dis, DBID, $scope, sampleService) {
    var x = [];
        if (dis != 1) {
            for (var i = 0; i < year; i++) {
                if (i == 0) {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, growth, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, growth, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, growth, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'),
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center' 
                                Azure: 0.0, Type: 'Azure Security Center'
                            },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                    //var item = { OnPremise: GetYearCost(CostbreackDownObject[5].onPremises, growth, i, 'End Point'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
                    //x.push(item);
                }
                else {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, growth, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, growth, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, growth, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License Cost', Year: (i + 1) + ' Year', Type: 'Oracle License' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Sa(Oracle) Azure', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'),
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center'
                                Azure: 0.0, Type: 'Azure Security Center'
                            },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                }
            }
        }
        else {
            for (var i = 0; i < year; i++) {
                if (i == 0) {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, growth, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, growth, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, growth, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License Cost', Year: (i + 1) + ' Year', Type: 'Oracle License'
                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Oracle SA(License)', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'),
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center' 
                                Azure: 0.0, Type: 'Azure Security Center'
                            },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                    //var item = { OnPremise: GetYearCost(CostbreackDownObject[5].onPremises, growth, i, 'End Point'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
                    //x.push(item);

                }
                else {
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[0].onPremises, growth, i, 'Compute'),
                        Azure: GetYearCost(CostbreackDownObject[0].Azure, growth, i, 'Compute'),
                        Year: (i + 1) + ' Year', Type: 'Compute',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[0].Cost, growth, i, 'Hardware'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[0].Cost, growth, i, 'Azure VM'), Year: (i + 1) + ' Year', Type: 'Hardware' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[1].Cost, growth, i, 'Hardware Maintenance Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[1].Cost, growth, i, 'Azure SQL'), Year: (i + 1) + ' Year', Type: 'Hardware Maintenance Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[2].Cost, 0, i, 'Software (Linux)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[2].Cost, growth, i, 'Azure Linux VM'), Year: (i + 1) + ' Year', Type: 'Software (Linux)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[3].Cost, 0, i, 'Software (Windows)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Software (Windows)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[4].Cost, growth, i, 'BizTalk'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[3].Cost, growth, i, 'BizTalkAzure'), Year: (i + 1) + ' Year', Type: 'BizTalk' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[5].Cost, growth, i, 'Electricity'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Electricity' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[6].Cost, 0, i, 'Sql License Cost'),
                                Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[4].Cost, growth, i, 'PostgreSQL(Oracle)'), Year: (i + 1) + ' Year', Type: 'Sql License Cost'

                            },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[7].Cost, growth, i, 'Sa(SQL)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(SQL)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[8].Cost, growth, i, 'Sa(Windows License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Windows License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[9].Cost, growth, i, 'Sa(Linux License)'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Sa(Linux License)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[10].Cost, growth, i, 'Oracle License'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[5].Cost, growth, i, 'Oracle License Cost'), Year: (i + 1) + ' Year', Type: 'Oracle License Cost"', Year: (i + 1) + ' Year', Type: 'Oracle License' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[11].Cost, growth, i, 'Sa(Oracle)'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[6].Cost, growth, i, 'Oracle SA(License)'), Year: (i + 1) + ' Year', Type: 'Oracle SA(License)', Year: (i + 1) + ' Year', Type: 'Sa(Oracle)' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[12].Cost, growth, i, 'Virtualization Cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Virtualization Cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[0].SubItems[13].Cost, growth, i, 'DR Cost'), Azure: GetYearCost(CostbreackDownObject[0].SubItemsAzure[7].Cost, growth, i, 'Azure DR Cost'), Year: (i + 1) + ' Year', Type: 'DR Cost' }
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[1].onPremises, growth, i, 'Data Center'), Azure: GetYearCost(CostbreackDownObject[1].Azure, growth, i, 'Data Center'), Year: (i + 1) + ' Year', Type: 'Data Center' };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[2].onPremises, growth, i, 'Networking'),
                        Azure: GetYearCost(CostbreackDownObject[2].Azure, growth, i, 'Networking'),
                        Year: (i + 1) + ' Year', Type: 'Networking',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[0].Cost, growth, i, 'Network hardware and software cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[0].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[0].Type), Year: (i + 1) + ' Year', Type: 'Bandwidth' },
                            { OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[1].Cost, growth, i, 'Network maintenance cost'), Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[1].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[1].Type), Year: (i + 1) + ' Year', Type: 'Azure Advisor' },
                            {
                                OnPremise: GetYearCost(CostbreackDownObject[2].SubItems[2].Cost, growth, i, 'Service provider cost'),
                                //Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Security Center' 
                                Azure: 0.0, Type: 'Azure Security Center'
                            },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[2].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[2].Type), Year: (i + 1) + ' Year', Type: 'Azure Active Directory' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[3].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[3].Type), Year: (i + 1) + ' Year', Type: 'Application Gateway' },
                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Backup' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[4].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[4].Type), Year: (i + 1) + ' Year', Type: 'Traffic Manager' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[5].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[5].Type), Year: (i + 1) + ' Year', Type: 'Network Watcher' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[6].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[6].Type), Year: (i + 1) + ' Year', Type: 'Loadbalancer' },

                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[7].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[7].Type), Year: (i + 1) + ' Year', Type: 'Express Route' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[8].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[8].Type), Year: (i + 1) + ' Year', Type: 'Virtual Network' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[9].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[9].Type), Year: (i + 1) + ' Year', Type: 'IP Addresses' },

                            //{ OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[12].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[12].Type), Year: (i + 1) + ' Year', Type: 'VPN Gateway' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[10].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[10].Type), Year: (i + 1) + ' Year', Type: 'Log Analytics' },
                            { OnPremise: 0.0, Azure: GetYearCost(CostbreackDownObject[2].SubItemsAzure[11].Cost, growth, i, CostbreackDownObject[2].SubItemsAzure[11].Type), Year: (i + 1) + ' Year', Type: 'Key Vault' },

                        ],
                    };
                    x.push(item);
                    var item = {
                        OnPremise: GetYearCost(CostbreackDownObject[3].onPremises, growth, i, 'Storage'),
                        Azure: GetYearCost(CostbreackDownObject[3].Azure, growth, i, 'Storage'),
                        Year: (i + 1) + ' Year', Type: 'Storage',
                        SubItems: [
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[0].Cost, growth, i, 'Storage hardware cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[0].Cost, growth, i, 'Cost Of Managed Disk'), Year: (i + 1) + ' Year', Type: 'Storage hardware cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[1].Cost, growth, i, 'Backup and Archive cost'), Azure: GetYearCost(CostbreackDownObject[3].SubItemsAzure[1].Cost, growth, i, 'Azure Backup'), Year: (i + 1) + ' Year', Type: 'Backup and Archive cost' },
                            { OnPremise: GetYearCost(CostbreackDownObject[3].SubItems[2].Cost, growth, i, 'Storage Maintenance cost'), Azure: 0.0, Year: (i + 1) + ' Year', Type: 'Storage Maintenance cost' },
                        ],
                    };
                    x.push(item);
                    var item = { OnPremise: GetYearCost(CostbreackDownObject[4].onPremises, growth, i, 'IT Labor'), Azure: GetYearCost(CostbreackDownObject[4].Azure, growth, i, 'IT Labor'), Year: (i + 1) + ' Year', Type: 'IT Labor' };
                    x.push(item);
                    //var item = { OnPremise: GetYearCost(CostbreackDownObject[5].onPremises, growth, i, 'End Point'), Azure: GetYearCost(CostbreackDownObject[5].Azure, growth, i, 'End Point'), Year: (i + 1) + ' Year', Type: 'End Point' };
                    //x.push(item);
                }
            }
        }
    return x;
}
