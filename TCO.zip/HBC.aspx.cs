﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UCCloudReconDAL;
using UCCloudReconDTO;
using UCCloudReconService;
using UCMAPService;
using Newtonsoft.Json;
using System.Web.Services;
using System.Net;
using PPTGeneration.HBC;

namespace UCCloudRecon
{
    public partial class HBC : System.Web.UI.Page
    {
        public static string _ServerName = "";
        public static string _ServerName1 = "";
        public static string _DBName = "";
        public static string InventoryName = "";
        public static string CurrencyMode = "";
        public static string Region = "";
        public static string CurrencyFormat = "";
        int DBID = 0;
        string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    DBID = Convert.ToInt32(HttpContext.Current.Session["DBID"]);

                    #region Display the Lic value in pop window
                    List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                    _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                    _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                    BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                    List<LicDistrubtion_Master> data = service.GetLicenseDistributionData();
                    if (data != null)
                    {
                        var SQLStd1 = data.Where(x => x.LicenseProductFamily == "SQL Server Standard Core" && x.Type == "SQLMI_AC" && x.LicenseType == "SQL_Lic").Select(a => new { a.SA_Cost }).ToList();
                        var SQLEnt1 = data.Where(x => x.LicenseProductFamily == "SQL Server Enterprise Core" && x.Type == "ISVSQL_RightSize" && x.LicenseType == "SQL_Lic").Select(a => new { a.SA_Cost }).ToList();
                        var WinDC1 = data.Where(x => x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core" && x.Type == "ISVSQL_ASIS" && x.LicenseType == "Win_Lic").Select(a => new { a.SA_Cost }).ToList();
                        var WinStd1 = data.Where(x => x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core" && x.Type == "ISVSQL_OnPrim" && x.LicenseType == "Win_Lic").Select(a => new { a.SA_Cost }).ToList();
                        SQLStd.Value = SQLStd1.Count == 0 ? "0" : SQLStd1[0].SA_Cost.ToString() == "" ? "0" : SQLStd1[0].SA_Cost.ToString();
                        SQLEnt.Value = SQLEnt1.Count == 0 ? "0" : SQLEnt1[0].SA_Cost.ToString() == "" ? "0" : SQLEnt1[0].SA_Cost.ToString();
                        WinDC.Value = WinDC1.Count == 0 ? "0" : WinDC1[0].SA_Cost.ToString() == "" ? "0" : WinDC1[0].SA_Cost.ToString();
                        WinStd.Value = WinStd1.Count == 0 ? "0" : WinStd1[0].SA_Cost.ToString() == "" ? "0" : WinStd1[0].SA_Cost.ToString();

                        //PPT
                        SQLStdPPT.Value = SQLStd1.Count == 0 ? "0" : SQLStd1[0].SA_Cost.ToString() == "" ? "0" : SQLStd1[0].SA_Cost.ToString();
                        SQLEntPPT.Value = SQLEnt1.Count == 0 ? "0" : SQLEnt1[0].SA_Cost.ToString() == "" ? "0" : SQLEnt1[0].SA_Cost.ToString();
                        WinDCPPT.Value = WinDC1.Count == 0 ? "0" : WinDC1[0].SA_Cost.ToString() == "" ? "0" : WinDC1[0].SA_Cost.ToString();
                        WinStdPPT.Value = WinStd1.Count == 0 ? "0" : WinStd1[0].SA_Cost.ToString() == "" ? "0" : WinStd1[0].SA_Cost.ToString();

                        disLicense.Disabled = true;
                        redisLicense.Disabled = false;
                        //LinkButtonWorkBook.Enabled = true;
                        //LinkButtonPPT.Enabled = true;

                        //ButtonWorkBook.Disabled = false;
                        //ButtonPPT.Disabled = false;
                    }
                    else
                    {
                        disLicense.Disabled = false;
                        redisLicense.Disabled = true;

                        //LinkButtonWorkBook.OnClientClick = null;
                        //LinkButtonWorkBook.Attributes.Add("disabled", "disabled");
                        //LinkButtonWorkBook.Enabled = false;
                        //
                        //LinkButtonPPT.OnClientClick = null;
                        //LinkButtonPPT.Attributes.Add("disabled", "disabled");
                        //LinkButtonPPT.Enabled = false;

                        //ButtonWorkBook.Disabled = true;
                        //ButtonPPT.Disabled = true;
                    }
                    #endregion
                }
                if (Session["UserMID"] != null)
                {
                    if (Session["DBID"] != null)
                    {
                        //int DBID = 0;
                        string _DBname = "";
                        string _serverName = "";
                        int UserID = 0;
                        bool? IsInventoryEncrypted = false;
                        List<TestFileDTO> TestFileDTOs;
                        DBID = Convert.ToInt32(Session["DBID"]);
                        UserID = (int)Session["UserMID"];

                        TestFileDTOs = new TestFileMasterService().GetFileByDBID(DBID);
                        if (TestFileDTOs.Count > 0)
                        {
                            _DBname = TestFileDTOs.Where(s => s.FileID == DBID).ToList()[0].DbName;
                            _serverName = Convert.ToString(Helper.SQLHelper.GetServerName());
                            IsInventoryEncrypted = TestFileDTOs.Where(s => s.FileID == DBID).ToList()[0].IsEncrcypted;
                            InventoryName = TestFileDTOs.Where(s => s.FileID == DBID).ToList()[0].FileName;
                            #region Set Currency and Region type on page load
                            if (HttpContext.Current.Session["Region"] != null)
                                Region = HttpContext.Current.Session["Region"].ToString();
                            else
                                Region = "US East";

                            if (HttpContext.Current.Session["Currency"] != null)
                                CurrencyMode = HttpContext.Current.Session["Currency"].ToString();
                            else
                                CurrencyMode = "USD";

                            if (CurrencyMode == "USD")
                                CurrencyMode = "US Dollar ($)";
                            else if (CurrencyMode == "EUR")
                                CurrencyMode = "Euro (€)";
                            else if (CurrencyMode == "GBP")
                                CurrencyMode = "British Pound (£)";
                            else if (CurrencyMode == "AUD")
                                CurrencyMode = "Australian Dollar ($)";
                            else if (CurrencyMode == "INR")
                                CurrencyMode = "Indian Rupee (₹)";
                            else if (CurrencyMode == "CAD")
                                CurrencyMode = "Canadian Dollar ($)";
                            else if (CurrencyMode == "MYR")
                                CurrencyMode = "Malaysian Ringgit (RM$)";
                            else if (CurrencyMode == "KRW")
                                CurrencyMode = "Korean Won (₩)";
                            else if (CurrencyMode == "IDR")
                                CurrencyMode = "Indonesian Rupiah (Rp)";
                            else if (CurrencyMode == "CNY")
                                CurrencyMode = "China";
                            else if (CurrencyMode == "NZD")
                                CurrencyMode = "New Zealand Dollar ($)";
                            else if (CurrencyMode == "ZAR")
                                CurrencyMode = "South African Rand (R)";
                            else if (CurrencyMode == "SAR")
                                CurrencyMode = "Saudi Riyal (SAR)";
                            else if (CurrencyMode == "JPY")
                                CurrencyMode = "Japanese Yen (¥)";
                            #endregion [Set Currency type on page load]

                            #region Set Currency Format
                            if (CurrencyMode == "US Dollar ($)" || CurrencyMode == "Australian Dollar ($)" || CurrencyMode == "Canadian Dollar ($)")
                            {
                                CurrencyFormat = "$#,##0.00";
                            }
                            else if (CurrencyMode == "Euro (€)")
                            {
                                CurrencyFormat = "€#,##0.00";
                            }
                            else if (CurrencyMode == "British Pound (£)")
                            {
                                CurrencyFormat = "£#,##0.00";
                            }
                            else if (CurrencyMode == "Australian Dollar ($)")
                            {
                                CurrencyFormat = "$#,##0.00";
                            }

                            else if (CurrencyMode == "Indian Rupee (₹)")
                            {
                                CurrencyFormat = "₹#,##0.00";
                            }
                            else if (CurrencyMode == "Canadian Dollar ($)")
                            {
                                CurrencyFormat = "$#,##0.00";
                            }
                            else if (CurrencyMode == "South African Rand (R)")
                            {
                                CurrencyFormat = "R#,##0.00";
                            }
                            else if (CurrencyMode == "Malaysian Ringgit (RM$)")
                            {
                                CurrencyFormat = "RM$#,##0.00";
                            }
                            else if (CurrencyMode == "Japanese Yen (¥)")
                            {
                                CurrencyFormat = "¥#,##0.00";
                            }
                            else if (CurrencyMode == "Korean Won (₩)")
                            {
                                CurrencyFormat = "₩#,##0.00";
                            }
                            else if (CurrencyMode == "Indonesian Rupiah (Rp)")
                            {
                                CurrencyFormat = "Rp#,##0.00";
                            }
                           
                            else if (CurrencyMode == "New Zealand Dollar ($)")
                            {
                                CurrencyFormat = "$#,##0.00";
                            }
                            else if (CurrencyMode == "Saudi Riyal (SAR)")
                            {
                                CurrencyFormat = "SAR#,##0.00";
                            }
                            else if (CurrencyMode == "Japanese Yen (¥)")
                            {
                                CurrencyFormat = "¥#,##0.00";
                            }

                            else
                            {
                                CurrencyFormat = "$#,##0.00";
                            }
                            #endregion

                            BoomRangReportService service = new BoomRangReportService(_serverName, _DBname, CurrencyMode, Region);
                            List<SQLMICustomFilter> listSQLMICustomFilter = service.GetSQLMICustomFilter();
                            if (listSQLMICustomFilter.Count == 0 || listSQLMICustomFilter[0].SelectFliter != "CustomMachine")
                            {
                                #region Set SQLMI for Custom Machines
                                SQLInstancePoolSizingDetails serviceSQLMI = new SQLInstancePoolSizingDetails(_serverName, _DBname);
                                serviceSQLMI.applyCustomFliter("CustomMachine", Region, CurrencyMode);
                                List<Recon_ReportingGetSqlServerComponent> listReportingGetSqlServerComponent = SQLMIWithInstancePool.ComponentServicesSummary(Region, CurrencyMode);
                                #endregion
                            }

                            List<LicDistrubtion_Master> data = service.GetLicenseDistributionData();
                            service = new BoomRangReportService(Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString()), _DBName, CurrencyMode, Region);
                            service.Sp_ResetLicDistrubtion_Master();
                            service.Sp_LicDistribution_Master();
                        }
                    }
                }
                else
                {
                    Session.Clear();
                    Session.Abandon();
                    Response.Redirect("LoginPopup.aspx");
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        [WebMethod(EnableSession = false)]
        public static void distributeLicense()
        {
            List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
            _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
            _ServerName = Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString());
            BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
            service.Sp_ResetLicDistrubtion_Master();
            service.Sp_LicDistribution_Master();
        }
        [WebMethod(EnableSession = false)]
        public static void redistributeLicense()
        {
            List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
            _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
            _ServerName = Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString());
            BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
            service.Sp_LicDistribution_Master();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                decimal SQLStandard = Convert.ToDecimal(SQLStd.Value);
                decimal SQLEnterprise = Convert.ToDecimal(SQLEnt.Value);
                decimal WindowsStandard = Convert.ToDecimal(WinStd.Value);
                decimal WindowsDatacenter = Convert.ToDecimal(WinDC.Value);
                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                service.SaveBoomrang(WindowsDatacenter, WindowsStandard, SQLStandard, SQLEnterprise);
                CreateExcelFile();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        void CreateExcelFile()
        {
            try
            {
                using (DataSet ds = GetExcelData())
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        #region DataTables
                        DataTable WindowsServerCount = new DataTable();
                        DataTable WindowsServerVersionInstanceCount = new DataTable();
                        DataTable LinuxServerCount = new DataTable();
                        DataTable LinuxServerVersionInstanceCount = new DataTable();
                        DataTable ApplicationAndWorkload = new DataTable();
                        DataTable DataEstateSQLServerCount = new DataTable();
                        DataTable DataEstateSQLServerVersionEditionInstanceCount = new DataTable();
                        DataTable DataEstateOracleCount = new DataTable();
                        DataTable DataEstateOracleVersionInstanceCount = new DataTable();
                        DataTable RightSizedIaaSEnvironment = new DataTable();
                        DataTable WindowsServerOverview_EndofServiceMachine = new DataTable();
                        DataTable WindowsServerOverview_CloudEconomicModeling = new DataTable();
                        DataTable WindowsServerOverview_1YearCost = new DataTable();
                        DataTable LinuxServerOverview_EndofServiceMachine = new DataTable();
                        DataTable LinuxServerOverview_CloudEconomicModeling = new DataTable();
                        DataTable LinuxServerOverview_1YearCost = new DataTable();
                        DataTable SQLServerOverview_EndofServiceMachine = new DataTable();
                        DataTable SQLServerOverview_CloudEconomicModeling = new DataTable();
                        DataTable SQLServerOverview_1YearCost = new DataTable();
                        DataTable ASRAndBackupCost_Summary = new DataTable();
                        DataTable ASRAndBackupCost_Breakdown = new DataTable();
                        DataTable StorageOverview_StorageSizeBreakdown = new DataTable();
                        DataTable StorageOverview_Summary = new DataTable();
                        DataTable ISVApplicationsWithSQLMigration_Summary = new DataTable();
                        DataTable ISVApplicationsWithSQLMigration_ApplicationServerCost = new DataTable();
                        DataTable ISVApplicationsWithSQLMigration_DatabaseCost = new DataTable();
                        DataTable SQLAnalytical_Summary = new DataTable();
                        DataTable SQLAnalytical_WorkloadCount = new DataTable();
                        DataTable SQLAnalytical_ComponentVMBreakdown = new DataTable();
                        DataTable CustomBuildApplicationsWithSQLDatabases_Summary = new DataTable();
                        DataTable CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost = new DataTable();
                        DataTable CustomBuildApplicationsWithSQLDatabases_DatabaseCost = new DataTable();
                        DataTable ReadinessAnalysedApplicationsWithSQLMigration_Summary = new DataTable();
                        DataTable ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost = new DataTable();
                        DataTable OracleToPostgreSQL_AnnualCost = new DataTable();
                        DataTable OracleToPostgreSQL_MonthlyCostBreakdown = new DataTable();
                        DataTable OracleToPostgreSQL_Summary = new DataTable();
                        DataTable SQLMICoreAndCostCalculation = new DataTable();
                        DataTable SQLServerCoreAndCostCalculation_Summary = new DataTable();
                        DataTable SQLServerCoreAndCostCalculation_RAMOptimization = new DataTable();
                        DataTable SQLServerCoreAndCostCalculation_DatabaseCost = new DataTable();
                        DataTable WindowsServerCoreAndCostCalculation_Summary = new DataTable();
                        DataTable WindowsServerCoreAndCostCalculation_RAMOptimization = new DataTable();
                        DataTable WindowsServerCoreAndCostCalculation_DatabaseCost = new DataTable();
                        DataTable SQLServerAssessmentSummary_3YearAsIsDatabaseCost = new DataTable();
                        DataTable SQLServerAssessmentSummary_Summary = new DataTable();
                        #endregion
                        foreach (DataTable dt in ds.Tables)
                        {
                            if (dt.TableName == "Slide 5_1")
                            {
                                WindowsServerCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_2")
                            {
                                WindowsServerVersionInstanceCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_3")
                            {
                                LinuxServerCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_4")
                            {
                                LinuxServerVersionInstanceCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 6")
                            {
                                ApplicationAndWorkload = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_1")
                            {
                                DataEstateSQLServerCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_2")
                            {
                                DataEstateSQLServerVersionEditionInstanceCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_3")
                            {
                                DataEstateOracleCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_4")
                            {
                                DataEstateOracleVersionInstanceCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 9")
                            {
                                RightSizedIaaSEnvironment = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 10_1")
                            {
                                WindowsServerOverview_EndofServiceMachine = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 10_2")
                            {
                                WindowsServerOverview_CloudEconomicModeling = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 10_3")
                            {
                                WindowsServerOverview_1YearCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 11_1")
                            {
                                LinuxServerOverview_EndofServiceMachine = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 11_2")
                            {
                                LinuxServerOverview_CloudEconomicModeling = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 11_3")
                            {
                                LinuxServerOverview_1YearCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 12_1")
                            {
                                SQLServerOverview_EndofServiceMachine = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 12_2")
                            {
                                SQLServerOverview_CloudEconomicModeling = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 12_3")
                            {
                                SQLServerOverview_1YearCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 13_1")
                            {
                                ASRAndBackupCost_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 13_2")
                            {
                                ASRAndBackupCost_Breakdown = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 14_1")
                            {
                                StorageOverview_StorageSizeBreakdown = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 14_2")
                            {
                                StorageOverview_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 19_1")
                            {
                                ISVApplicationsWithSQLMigration_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 19_2")
                            {
                                ISVApplicationsWithSQLMigration_ApplicationServerCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 19_3")
                            {
                                ISVApplicationsWithSQLMigration_DatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 21_1")
                            {
                                SQLAnalytical_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 21_2")
                            {
                                SQLAnalytical_WorkloadCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 21_3")
                            {
                                SQLAnalytical_ComponentVMBreakdown = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_1")
                            {
                                CustomBuildApplicationsWithSQLDatabases_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_2")
                            {
                                CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_3")
                            {
                                CustomBuildApplicationsWithSQLDatabases_DatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_4")
                            {
                                ReadinessAnalysedApplicationsWithSQLMigration_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_5")
                            {
                                ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 29_1")
                            {
                                OracleToPostgreSQL_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 29_2")
                            {
                                OracleToPostgreSQL_AnnualCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 29_3")
                            {
                                OracleToPostgreSQL_MonthlyCostBreakdown = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 55")
                            {
                                SQLMICoreAndCostCalculation = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 56_1")
                            {
                                SQLServerCoreAndCostCalculation_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 56_2")
                            {
                                SQLServerCoreAndCostCalculation_RAMOptimization = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 56_3")
                            {
                                SQLServerCoreAndCostCalculation_DatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 57_1")
                            {
                                WindowsServerCoreAndCostCalculation_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 57_2")
                            {
                                WindowsServerCoreAndCostCalculation_RAMOptimization = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 57_3")
                            {
                                WindowsServerCoreAndCostCalculation_DatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 32_1")
                            {
                                SQLServerAssessmentSummary_3YearAsIsDatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 32_2")
                            {
                                SQLServerAssessmentSummary_Summary = dt.Copy();
                            }
                        }
                        using (ExcelPackage xp = new ExcelPackage())
                        {
                            List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                            _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                            _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                            BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                            BoomRangReportService service1 = new BoomRangReportService(Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString()), _DBName, CurrencyMode, Region);
                            List<LicDistrubtion_Master> LicenseDistributionData = service.GetLicenseDistributionData();

                            ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Win & Linux Env");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (WindowsServerCount.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(WindowsServerCount, true);
                                ExcelDesign(ws, WindowsServerCount.Columns.Count, WindowsServerCount.Rows.Count, 3, 1);
                            }
                            if (WindowsServerVersionInstanceCount.Rows.Count != 0)
                            {
                                ws.Cells[11, 1].LoadFromDataTable(WindowsServerVersionInstanceCount, true);
                                ExcelDesign(ws, WindowsServerVersionInstanceCount.Columns.Count, WindowsServerVersionInstanceCount.Rows.Count, 11, 1);
                            }
                            if (LinuxServerCount.Rows.Count != 0)
                            {
                                ws.Cells[3, 4].LoadFromDataTable(LinuxServerCount, true);
                                ExcelDesign(ws, LinuxServerCount.Columns.Count, LinuxServerCount.Rows.Count, 3, 4);
                            }
                            if (LinuxServerVersionInstanceCount.Rows.Count != 0)
                            {
                                ws.Cells[11, 4].LoadFromDataTable(LinuxServerVersionInstanceCount, true);
                                ExcelDesign(ws, LinuxServerVersionInstanceCount.Columns.Count, LinuxServerVersionInstanceCount.Rows.Count, 11, 4);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 9, 2, 17].Merge = true;
                            ws.Cells[1, 9, 2, 17].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 17].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 17].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide5", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide5.png"))).SetPosition(2, 0, 6, 0);

                            ws = xp.Workbook.Worksheets.Add("Apps & Workloads");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (ApplicationAndWorkload.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(ApplicationAndWorkload, true);
                                ExcelDesign(ws, ApplicationAndWorkload.Columns.Count, ApplicationAndWorkload.Rows.Count, 3, 1);
                                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                                ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            }
                            ws.Cells[1, 9, 2, 18].Merge = true;
                            ws.Cells[1, 9, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide6", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide6.png"))).SetPosition(2, 0, 6, 0);

                            ws = xp.Workbook.Worksheets.Add("Data Estate Summary");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (DataEstateSQLServerCount.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(DataEstateSQLServerCount, true);
                                ExcelDesign(ws, DataEstateSQLServerCount.Columns.Count, DataEstateSQLServerCount.Rows.Count, 3, 1);
                            }
                            if (DataEstateSQLServerVersionEditionInstanceCount.Rows.Count != 0)
                            {
                                ws.Cells[11, 1].LoadFromDataTable(DataEstateSQLServerVersionEditionInstanceCount, true);
                                ExcelDesign(ws, DataEstateSQLServerVersionEditionInstanceCount.Columns.Count, DataEstateSQLServerVersionEditionInstanceCount.Rows.Count, 11, 1);

                            }
                            if (DataEstateOracleCount.Rows.Count != 0)
                            {
                                ws.Cells[3, 5].LoadFromDataTable(DataEstateOracleCount, true);
                                ExcelDesign(ws, DataEstateOracleCount.Columns.Count, DataEstateOracleCount.Rows.Count, 3, 5);
                            }
                            if (DataEstateOracleVersionInstanceCount.Rows.Count != 0)
                            {
                                ws.Cells[11, 5].LoadFromDataTable(DataEstateOracleVersionInstanceCount, true);
                                ExcelDesign(ws, DataEstateOracleVersionInstanceCount.Columns.Count, DataEstateOracleVersionInstanceCount.Rows.Count, 11, 5);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 10, 2, 19].Merge = true;
                            ws.Cells[1, 10, 2, 19].Value = "Reference Slide";
                            ws.Cells[1, 10, 2, 19].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 10, 2, 19].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide7", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide7.png"))).SetPosition(2, 0, 7, 0);

                            ws = xp.Workbook.Worksheets.Add("RSized IaaS Env");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (RightSizedIaaSEnvironment.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(RightSizedIaaSEnvironment, true);
                                ExcelDesign(ws, RightSizedIaaSEnvironment.Columns.Count, RightSizedIaaSEnvironment.Rows.Count, 3, 1);
                                CurrencyFormatDesign(ws, RightSizedIaaSEnvironment.Columns.Count, RightSizedIaaSEnvironment.Rows.Count, 4, 3);

                                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                                ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            }
                            ws.Cells[1, 9, 2, 19].Merge = true;
                            ws.Cells[1, 9, 2, 19].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 19].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 19].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide9", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide9.png"))).SetPosition(2, 0, 7, 0);

                            ws = xp.Workbook.Worksheets.Add("Win Server Overview");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (WindowsServerOverview_EndofServiceMachine.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(WindowsServerOverview_EndofServiceMachine, true);
                                ExcelDesign(ws, WindowsServerOverview_EndofServiceMachine.Columns.Count, WindowsServerOverview_EndofServiceMachine.Rows.Count, 2, 2);
                            }
                            if (WindowsServerOverview_CloudEconomicModeling.Rows.Count != 0)
                            {
                                ws.Cells[2, 6].LoadFromDataTable(WindowsServerOverview_CloudEconomicModeling, true);
                                ExcelDesign(ws, WindowsServerOverview_CloudEconomicModeling.Columns.Count, WindowsServerOverview_CloudEconomicModeling.Rows.Count, 2, 6);
                                CurrencyFormatDesign(ws, WindowsServerOverview_CloudEconomicModeling.Columns.Count, WindowsServerOverview_CloudEconomicModeling.Rows.Count, 3, 7);
                            }

                            if (WindowsServerOverview_1YearCost.Rows.Count != 0)
                            {
                                ws.Cells[5, 6].LoadFromDataTable(WindowsServerOverview_1YearCost, true);
                                ExcelDesign(ws, WindowsServerOverview_1YearCost.Columns.Count, WindowsServerOverview_1YearCost.Rows.Count, 5, 6);
                                CurrencyFormatDesign(ws, WindowsServerOverview_1YearCost.Columns.Count, WindowsServerOverview_1YearCost.Rows.Count, 6, 7);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[8, 7, 8, 14].Merge = true;
                            ws.Cells[8, 7, 8, 14].Value = "Reference Slide";
                            ws.Cells[8, 7, 8, 14].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[8, 7, 8, 14].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide10", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide10.png"))).SetPosition(8, 0, 5, 0);

                            ws = xp.Workbook.Worksheets.Add("Linux Server Overview");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));

                            if (LinuxServerOverview_EndofServiceMachine.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(LinuxServerOverview_EndofServiceMachine, true);
                                ExcelDesign(ws, LinuxServerOverview_EndofServiceMachine.Columns.Count, LinuxServerOverview_EndofServiceMachine.Rows.Count, 2, 2);
                            }
                            if (LinuxServerOverview_CloudEconomicModeling.Rows.Count != 0)
                            {
                                ws.Cells[2, 6].LoadFromDataTable(LinuxServerOverview_CloudEconomicModeling, true);
                                ExcelDesign(ws, LinuxServerOverview_CloudEconomicModeling.Columns.Count, LinuxServerOverview_CloudEconomicModeling.Rows.Count, 2, 6);
                                CurrencyFormatDesign(ws, LinuxServerOverview_CloudEconomicModeling.Columns.Count, LinuxServerOverview_CloudEconomicModeling.Rows.Count, 3, 7);
                            }
                            if (LinuxServerOverview_1YearCost.Rows.Count != 0)
                            {
                                ws.Cells[5, 6].LoadFromDataTable(LinuxServerOverview_1YearCost, true);
                                ExcelDesign(ws, LinuxServerOverview_1YearCost.Columns.Count, LinuxServerOverview_1YearCost.Rows.Count, 5, 6);
                                CurrencyFormatDesign(ws, LinuxServerOverview_1YearCost.Columns.Count, LinuxServerOverview_1YearCost.Rows.Count, 6, 7);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[8, 7, 8, 14].Merge = true;
                            ws.Cells[8, 7, 8, 14].Value = "Reference Slide";
                            ws.Cells[8, 7, 8, 14].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[8, 7, 8, 14].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide11", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide11.png"))).SetPosition(8, 0, 5, 0);

                            ws = xp.Workbook.Worksheets.Add("SQL Server Overview");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (SQLServerOverview_EndofServiceMachine.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(SQLServerOverview_EndofServiceMachine, true);
                                ExcelDesign(ws, SQLServerOverview_EndofServiceMachine.Columns.Count, SQLServerOverview_EndofServiceMachine.Rows.Count, 2, 2);
                            }
                            if (SQLServerOverview_CloudEconomicModeling.Rows.Count != 0)
                            {
                                ws.Cells[2, 6].LoadFromDataTable(SQLServerOverview_CloudEconomicModeling, true);
                                ExcelDesign(ws, SQLServerOverview_CloudEconomicModeling.Columns.Count, SQLServerOverview_CloudEconomicModeling.Rows.Count, 2, 6);
                                CurrencyFormatDesign(ws, SQLServerOverview_CloudEconomicModeling.Columns.Count, SQLServerOverview_CloudEconomicModeling.Rows.Count, 3, 7);
                            }
                            if (SQLServerOverview_1YearCost.Rows.Count != 0)
                            {
                                ws.Cells[5, 6].LoadFromDataTable(SQLServerOverview_1YearCost, true);
                                ExcelDesign(ws, SQLServerOverview_1YearCost.Columns.Count, SQLServerOverview_1YearCost.Rows.Count, 5, 6);
                                CurrencyFormatDesign(ws, SQLServerOverview_1YearCost.Columns.Count, SQLServerOverview_1YearCost.Rows.Count, 6, 7);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[8, 7, 8, 14].Merge = true;
                            ws.Cells[8, 7, 8, 14].Value = "Reference Slide";
                            ws.Cells[8, 7, 8, 14].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[8, 7, 8, 14].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide12", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide12.png"))).SetPosition(8, 0, 5, 0);

                            ws = xp.Workbook.Worksheets.Add("ASR & Backup DR");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (ASRAndBackupCost_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(ASRAndBackupCost_Summary, true);
                                ExcelDesign(ws, ASRAndBackupCost_Summary.Columns.Count, ASRAndBackupCost_Summary.Rows.Count, 1, 1);
                                CurrencyFormatDesign(ws, ASRAndBackupCost_Summary.Columns.Count, ASRAndBackupCost_Summary.Rows.Count, 2, 1);
                            }
                            if (ASRAndBackupCost_Breakdown.Rows.Count != 0)
                            {
                                ws.Cells[7, 1].LoadFromDataTable(ASRAndBackupCost_Breakdown, true);
                                ExcelDesign(ws, ASRAndBackupCost_Breakdown.Columns.Count, ASRAndBackupCost_Breakdown.Rows.Count, 7, 1);
                                CurrencyFormatDesign(ws, ASRAndBackupCost_Breakdown.Columns.Count, ASRAndBackupCost_Breakdown.Rows.Count, 8, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 9, 2, 18].Merge = true;
                            ws.Cells[1, 9, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide13", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide13.png"))).SetPosition(2, 0, 6, 0);

                            ws = xp.Workbook.Worksheets.Add("Storage Overview");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (StorageOverview_StorageSizeBreakdown.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(StorageOverview_StorageSizeBreakdown, true);
                                ExcelDesign(ws, StorageOverview_StorageSizeBreakdown.Columns.Count, StorageOverview_StorageSizeBreakdown.Rows.Count, 2, 2);
                            }
                            if (StorageOverview_Summary.Rows.Count != 0)
                            {
                                ws.Cells[2, 7].LoadFromDataTable(StorageOverview_Summary, true);
                                ExcelDesign(ws, StorageOverview_Summary.Columns.Count, StorageOverview_Summary.Rows.Count, 2, 7);
                                CurrencyFormatDesign(ws, StorageOverview_Summary.Columns.Count, StorageOverview_Summary.Rows.Count, 3, 8);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[7, 8, 8, 17].Merge = true;
                            ws.Cells[7, 8, 8, 17].Value = "Reference Slide";
                            ws.Cells[7, 8, 8, 17].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[7, 8, 8, 17].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide14", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide14.png"))).SetPosition(8, 0, 5, 0);

                            ws = xp.Workbook.Worksheets.Add("ISV Apps");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (ISVApplicationsWithSQLMigration_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(ISVApplicationsWithSQLMigration_Summary, true);
                                ExcelDesign(ws, ISVApplicationsWithSQLMigration_Summary.Columns.Count, ISVApplicationsWithSQLMigration_Summary.Rows.Count, 1, 1);
                            }
                            if (ISVApplicationsWithSQLMigration_ApplicationServerCost.Rows.Count != 0)
                            {
                                ws.Cells[8, 1].LoadFromDataTable(ISVApplicationsWithSQLMigration_ApplicationServerCost, true);
                                ExcelDesign(ws, ISVApplicationsWithSQLMigration_ApplicationServerCost.Columns.Count, ISVApplicationsWithSQLMigration_ApplicationServerCost.Rows.Count, 8, 1);
                                CurrencyFormatDesign(ws, ISVApplicationsWithSQLMigration_ApplicationServerCost.Columns.Count, ISVApplicationsWithSQLMigration_ApplicationServerCost.Rows.Count, 9, 2);
                            }
                            if (ISVApplicationsWithSQLMigration_DatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[14, 1].LoadFromDataTable(ISVApplicationsWithSQLMigration_DatabaseCost, true);
                                ExcelDesign(ws, ISVApplicationsWithSQLMigration_DatabaseCost.Columns.Count, ISVApplicationsWithSQLMigration_DatabaseCost.Rows.Count, 14, 1);
                                CurrencyFormatDesign(ws, ISVApplicationsWithSQLMigration_DatabaseCost.Columns.Count, ISVApplicationsWithSQLMigration_DatabaseCost.Rows.Count, 15, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 10, 2, 20].Merge = true;
                            ws.Cells[1, 10, 2, 20].Value = "Reference Slide";
                            ws.Cells[1, 10, 2, 20].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 10, 2, 20].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide19", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide19.png"))).SetPosition(2, 0, 7, 0);

                            ws = xp.Workbook.Worksheets.Add("Component Services");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (SQLAnalytical_Summary.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(SQLAnalytical_Summary, true);
                                ExcelDesign(ws, SQLAnalytical_Summary.Columns.Count, SQLAnalytical_Summary.Rows.Count, 2, 2);
                            }
                            if (SQLAnalytical_WorkloadCount.Rows.Count != 0)
                            {
                                ws.Cells[8, 2].LoadFromDataTable(SQLAnalytical_WorkloadCount, true);
                                ExcelDesign(ws, SQLAnalytical_WorkloadCount.Columns.Count, SQLAnalytical_WorkloadCount.Rows.Count, 8, 2);
                            }
                            if (SQLAnalytical_ComponentVMBreakdown.Rows.Count != 0)
                            {
                                ws.Cells[2, 5].LoadFromDataTable(SQLAnalytical_ComponentVMBreakdown, true);
                                ExcelDesign(ws, SQLAnalytical_ComponentVMBreakdown.Columns.Count, SQLAnalytical_ComponentVMBreakdown.Rows.Count, 2, 5);
                                CurrencyFormatDesign(ws, SQLAnalytical_ComponentVMBreakdown.Columns.Count, SQLAnalytical_ComponentVMBreakdown.Rows.Count, 3, 6);
                            }
                            ws.Cells[8, 5].Value = "Type"; ws.Cells[8, 6].Value = "Cost";
                            ws.Cells[9, 5].Value = "Analysis Services"; ws.Cells[9, 6].Formula = "=SUM(F3:F6)";
                            ws.Cells[10, 5].Value = "Azure Data Factory"; ws.Cells[10, 6].Formula = "=SUM(F3:F6)";
                            ws.Cells[11, 5].Value = "SSRS"; ws.Cells[11, 6].Formula = "=SUM(F3:F6)";
                            ExcelDesign(ws, 2, 3, 8, 5);
                            CurrencyFormatDesign(ws, 2, 3, 9, 6);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 9, 2, 18].Merge = true;
                            ws.Cells[1, 9, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide21", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide21.png"))).SetPosition(2, 0, 7, 0);

                            ws = xp.Workbook.Worksheets.Add("Custom Apps");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (CustomBuildApplicationsWithSQLDatabases_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(CustomBuildApplicationsWithSQLDatabases_Summary, true);
                                ExcelDesign(ws, CustomBuildApplicationsWithSQLDatabases_Summary.Columns.Count, CustomBuildApplicationsWithSQLDatabases_Summary.Rows.Count, 1, 1);
                            }
                            if (ReadinessAnalysedApplicationsWithSQLMigration_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 4].LoadFromDataTable(ReadinessAnalysedApplicationsWithSQLMigration_Summary, true);
                                ExcelDesign(ws, ReadinessAnalysedApplicationsWithSQLMigration_Summary.Columns.Count, ReadinessAnalysedApplicationsWithSQLMigration_Summary.Rows.Count, 1, 4);
                            }
                            if (CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost.Rows.Count != 0)
                            {
                                ws.Cells[8, 1].LoadFromDataTable(CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost, true);
                                ExcelDesign(ws, CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost.Columns.Count, CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost.Rows.Count, 8, 1);
                                CurrencyFormatDesign(ws, CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost.Columns.Count, CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost.Rows.Count, 9, 2);
                            }
                            if (CustomBuildApplicationsWithSQLDatabases_DatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[14, 1].LoadFromDataTable(CustomBuildApplicationsWithSQLDatabases_DatabaseCost, true);
                                ExcelDesign(ws, CustomBuildApplicationsWithSQLDatabases_DatabaseCost.Columns.Count, CustomBuildApplicationsWithSQLDatabases_DatabaseCost.Rows.Count, 14, 1);
                                CurrencyFormatDesign(ws, CustomBuildApplicationsWithSQLDatabases_DatabaseCost.Columns.Count, CustomBuildApplicationsWithSQLDatabases_DatabaseCost.Rows.Count, 15, 2);
                            }
                            if (ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[20, 1].LoadFromDataTable(ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost, true);
                                ExcelDesign(ws, ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost.Columns.Count, ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost.Rows.Count, 20, 1);
                                CurrencyFormatDesign(ws, ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost.Columns.Count, ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost.Rows.Count, 21, 2);
                            }

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 10, 2, 20].Merge = true;
                            ws.Cells[1, 10, 2, 20].Value = "Reference Slide";
                            ws.Cells[1, 10, 2, 20].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 10, 2, 20].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide25", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide25.png"))).SetPosition(2, 0, 7, 0);

                            ws = xp.Workbook.Worksheets.Add("Oracle Database");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (OracleToPostgreSQL_Summary.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(OracleToPostgreSQL_Summary, true);
                                ExcelDesign(ws, OracleToPostgreSQL_Summary.Columns.Count, OracleToPostgreSQL_Summary.Rows.Count, 2, 2);
                            }
                            if (OracleToPostgreSQL_AnnualCost.Rows.Count != 0)
                            {
                                ws.Cells[10, 2].LoadFromDataTable(OracleToPostgreSQL_AnnualCost, true);
                                ExcelDesign(ws, OracleToPostgreSQL_AnnualCost.Columns.Count, OracleToPostgreSQL_AnnualCost.Rows.Count, 10, 2);
                                CurrencyFormatDesign(ws, OracleToPostgreSQL_AnnualCost.Columns.Count, OracleToPostgreSQL_AnnualCost.Rows.Count, 11, 3);
                            }
                            if (OracleToPostgreSQL_MonthlyCostBreakdown.Rows.Count != 0)
                            {
                                ws.Cells[13, 2].LoadFromDataTable(OracleToPostgreSQL_MonthlyCostBreakdown, true);
                                ExcelDesign(ws, OracleToPostgreSQL_MonthlyCostBreakdown.Columns.Count, OracleToPostgreSQL_MonthlyCostBreakdown.Rows.Count, 13, 2);
                                CurrencyFormatDesign(ws, OracleToPostgreSQL_MonthlyCostBreakdown.Columns.Count, OracleToPostgreSQL_MonthlyCostBreakdown.Rows.Count, 14, 3);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 21].Merge = true;
                            ws.Cells[1, 11, 2, 21].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 21].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 21].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide29", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide29.png"))).SetPosition(2, 0, 11, 0);

                            ws = xp.Workbook.Worksheets.Add("Lic Dist ISV & Custom Apps");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 2].Value = "ISV APP"; ws.Cells[2, 3].Value = "Onprem"; ws.Cells[2, 4].Value = "As-Is"; ws.Cells[2, 5].Value = "Right-Sized";
                            ws.Cells[3, 2].Value = "Core Infrastructure Server Suite Datacenter Core";
                            ws.Cells[3, 3].Value = LicenseDistributionData.Where(x => x.Type == "ISVAPP_OnPrim" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[3, 4].Value = LicenseDistributionData.Where(x => x.Type == "ISVAPP_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[3, 5].Value = LicenseDistributionData.Where(x => x.Type == "ISVAPP_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[4, 2].Value = "Core Infrastructure Server Suite Standard Core";
                            ws.Cells[4, 3].Value = LicenseDistributionData.Where(x => x.Type == "ISVAPP_OnPrim" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[4, 4].Value = LicenseDistributionData.Where(x => x.Type == "ISVAPP_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[4, 5].Value = LicenseDistributionData.Where(x => x.Type == "ISVAPP_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 4, 2, 2, 2);
                            ws.Cells[7, 2].Value = "CUSTOM APP"; ws.Cells[7, 3].Value = "Onprem"; ws.Cells[7, 4].Value = "As-Is"; ws.Cells[7, 5].Value = "Right-Sized";
                            ws.Cells[8, 2].Value = "Core Infrastructure Server Suite Datacenter Core";
                            ws.Cells[8, 3].Value = LicenseDistributionData.Where(x => x.Type == "SQLAPP_OnPrim" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[8, 4].Value = LicenseDistributionData.Where(x => x.Type == "SQLAPP_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[8, 5].Value = LicenseDistributionData.Where(x => x.Type == "SQLAPP_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[9, 2].Value = "Core Infrastructure Server Suite Standard Core";
                            ws.Cells[9, 3].Value = LicenseDistributionData.Where(x => x.Type == "SQLAPP_OnPrim" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[9, 4].Value = LicenseDistributionData.Where(x => x.Type == "SQLAPP_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[9, 5].Value = LicenseDistributionData.Where(x => x.Type == "SQLAPP_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 4, 2, 7, 2);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 9, 2, 17].Merge = true;
                            ws.Cells[1, 9, 2, 17].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 17].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 17].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide53", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide53.png"))).SetPosition(2, 0, 6, 0);

                            ws = xp.Workbook.Worksheets.Add("Lic Dist ISV & Custom Database");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 2].Value = "Custom SQL"; ws.Cells[2, 3].Value = "Before Consolidation"; ws.Cells[2, 4].Value = "After Consolidation";
                            ws.Cells[3, 2].Value = "General Purpose";
                            ws.Cells[3, 3].Value = LicenseDistributionData.Where(x => x.Type == "SQLMI_BC" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[3, 4].Value = LicenseDistributionData.Where(x => x.Type == "SQLMI_AC" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[4, 2].Value = "Business Critical";
                            ws.Cells[4, 3].Value = LicenseDistributionData.Where(x => x.Type == "SQLMI_BC" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[4, 4].Value = LicenseDistributionData.Where(x => x.Type == "SQLMI_AC" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 3, 2, 2, 2);
                            ws.Cells[7, 2].Value = "ISV SQL"; ws.Cells[7, 3].Value = "Onprem"; ws.Cells[7, 4].Value = "Right-Sized"; ws.Cells[7, 5].Value = "As-Is";
                            ws.Cells[8, 2].Value = "SQL Server Enterprise Core";
                            ws.Cells[8, 3].Value = LicenseDistributionData.Where(x => x.Type == "ISVSQL_OnPrim" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[8, 4].Value = LicenseDistributionData.Where(x => x.Type == "ISVSQL_RightSize" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[8, 5].Value = LicenseDistributionData.Where(x => x.Type == "ISVSQL_ASIS" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[9, 2].Value = "SQL Server Standard Core";
                            ws.Cells[9, 3].Value = LicenseDistributionData.Where(x => x.Type == "ISVSQL_OnPrim" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[9, 4].Value = LicenseDistributionData.Where(x => x.Type == "ISVSQL_RightSize" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[9, 5].Value = LicenseDistributionData.Where(x => x.Type == "ISVSQL_ASIS" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 4, 2, 7, 2);
                            ws.Cells[12, 2].Value = "Readiness Analysed SQL"; ws.Cells[12, 3].Value = "Onprem"; ws.Cells[12, 4].Value = "Right-Sized"; ws.Cells[12, 5].Value = "As-Is";
                            ws.Cells[13, 2].Value = "SQL Server Enterprise Core";
                            ws.Cells[13, 3].Value = LicenseDistributionData.Where(x => x.Type == "Readiness_OnPrim" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[13, 4].Value = LicenseDistributionData.Where(x => x.Type == "Readiness_RightSize" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[13, 5].Value = LicenseDistributionData.Where(x => x.Type == "Readiness_ASIS" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[14, 2].Value = "SQL Server Standard Core";
                            ws.Cells[14, 3].Value = LicenseDistributionData.Where(x => x.Type == "Readiness_OnPrim" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[14, 4].Value = LicenseDistributionData.Where(x => x.Type == "Readiness_RightSize" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[14, 5].Value = LicenseDistributionData.Where(x => x.Type == "Readiness_ASIS" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 4, 2, 12, 2);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 9, 2, 17].Merge = true;
                            ws.Cells[1, 9, 2, 17].Value = "Reference Slide";
                            ws.Cells[1, 9, 2, 17].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 9, 2, 17].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide54", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide54.png"))).SetPosition(2, 0, 7, 0);

                            ws = xp.Workbook.Worksheets.Add("SQL MI");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (SQLMICoreAndCostCalculation.Rows.Count != 0)
                            {
                                ws.Cells[3, 2].LoadFromDataTable(SQLMICoreAndCostCalculation, true);
                                ExcelDesign(ws, SQLMICoreAndCostCalculation.Columns.Count, SQLMICoreAndCostCalculation.Rows.Count, 3, 2);
                                CurrencyFormatDesign(ws, SQLMICoreAndCostCalculation.Columns.Count, SQLMICoreAndCostCalculation.Rows.Count, 4, 6);
                                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                                ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            }
                            ws.Cells[1, 13, 2, 23].Merge = true;
                            ws.Cells[1, 13, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 13, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 13, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide55", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide55.png"))).SetPosition(2, 0, 11, 0);

                            ws = xp.Workbook.Worksheets.Add("All SQL VM");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (SQLServerCoreAndCostCalculation_Summary.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(SQLServerCoreAndCostCalculation_Summary, true);
                                ExcelDesign(ws, SQLServerCoreAndCostCalculation_Summary.Columns.Count, SQLServerCoreAndCostCalculation_Summary.Rows.Count, 3, 1);
                            }
                            if (SQLServerCoreAndCostCalculation_RAMOptimization.Rows.Count != 0)
                            {
                                ws.Cells[11, 1].LoadFromDataTable(SQLServerCoreAndCostCalculation_RAMOptimization, true);
                                ExcelDesign(ws, SQLServerCoreAndCostCalculation_RAMOptimization.Columns.Count, SQLServerCoreAndCostCalculation_RAMOptimization.Rows.Count, 11, 1);
                            }
                            if (SQLServerCoreAndCostCalculation_DatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[3, 4].LoadFromDataTable(SQLServerCoreAndCostCalculation_DatabaseCost, true);
                                ExcelDesign(ws, SQLServerCoreAndCostCalculation_DatabaseCost.Columns.Count, SQLServerCoreAndCostCalculation_DatabaseCost.Rows.Count, 3, 4);
                                CurrencyFormatDesign(ws, SQLServerCoreAndCostCalculation_DatabaseCost.Columns.Count, SQLServerCoreAndCostCalculation_DatabaseCost.Rows.Count, 4, 5);
                            }
                            ws.Cells[11, 4].Value = "LicenseProductFamily"; ws.Cells[11, 5].Value = "AsIs"; ws.Cells[11, 6].Value = "RightSized";
                            ws.Cells[12, 4].Value = "Core Infrastructure Server Suite Datacenter Core";
                            ws.Cells[12, 5].Value = LicenseDistributionData.Where(x => x.Type == "SQL_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[12, 6].Value = LicenseDistributionData.Where(x => x.Type == "SQL_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[13, 4].Value = "Core Infrastructure Server Suite Standard Core";
                            ws.Cells[13, 5].Value = LicenseDistributionData.Where(x => x.Type == "SQL_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[13, 6].Value = LicenseDistributionData.Where(x => x.Type == "SQL_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 3, 2, 11, 4);
                            ws.Cells[16, 4].Value = "LicenseProductFamily"; ws.Cells[16, 5].Value = "AsIs"; ws.Cells[16, 6].Value = "RightSized";
                            ws.Cells[17, 4].Value = "SQL Server Enterprise Core";
                            ws.Cells[17, 5].Value = LicenseDistributionData.Where(x => x.Type == "SQL_ASIS" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[17, 6].Value = LicenseDistributionData.Where(x => x.Type == "SQL_RightSize" && x.LicenseProductFamily == "SQL Server Enterprise Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[18, 4].Value = "SQL Server Standard Core";
                            ws.Cells[18, 5].Value = LicenseDistributionData.Where(x => x.Type == "SQL_ASIS" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[18, 6].Value = LicenseDistributionData.Where(x => x.Type == "SQL_RightSize" && x.LicenseProductFamily == "SQL Server Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 3, 2, 16, 4);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 12, 2, 23].Merge = true;
                            ws.Cells[1, 12, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 12, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 12, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide56", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide56.png"))).SetPosition(2, 0, 10, 0);

                            ws = xp.Workbook.Worksheets.Add("All Win VM");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (WindowsServerCoreAndCostCalculation_Summary.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(WindowsServerCoreAndCostCalculation_Summary, true);
                                ExcelDesign(ws, WindowsServerCoreAndCostCalculation_Summary.Columns.Count, WindowsServerCoreAndCostCalculation_Summary.Rows.Count, 3, 1);
                            }
                            if (WindowsServerCoreAndCostCalculation_RAMOptimization.Rows.Count != 0)
                            {
                                ws.Cells[11, 1].LoadFromDataTable(WindowsServerCoreAndCostCalculation_RAMOptimization, true);
                                ExcelDesign(ws, WindowsServerCoreAndCostCalculation_RAMOptimization.Columns.Count, WindowsServerCoreAndCostCalculation_RAMOptimization.Rows.Count, 11, 1);
                            }
                            if (WindowsServerCoreAndCostCalculation_DatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[3, 4].LoadFromDataTable(WindowsServerCoreAndCostCalculation_DatabaseCost, true);
                                ExcelDesign(ws, WindowsServerCoreAndCostCalculation_DatabaseCost.Columns.Count, WindowsServerCoreAndCostCalculation_DatabaseCost.Rows.Count, 3, 4);
                                CurrencyFormatDesign(ws, WindowsServerCoreAndCostCalculation_DatabaseCost.Columns.Count, WindowsServerCoreAndCostCalculation_DatabaseCost.Rows.Count, 4, 5);
                            }
                            ws.Cells[11, 4].Value = "LicenseProductFamily"; ws.Cells[11, 5].Value = "AsIs"; ws.Cells[11, 6].Value = "RightSized";
                            ws.Cells[12, 4].Value = "Core Infrastructure Server Suite Datacenter Core";
                            ws.Cells[12, 5].Value = LicenseDistributionData.Where(x => x.Type == "WINALL_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[12, 6].Value = LicenseDistributionData.Where(x => x.Type == "WINALL_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Datacenter Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[13, 4].Value = "Core Infrastructure Server Suite Standard Core";
                            ws.Cells[13, 5].Value = LicenseDistributionData.Where(x => x.Type == "WINALL_ASIS" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ws.Cells[13, 6].Value = LicenseDistributionData.Where(x => x.Type == "WINALL_RightSize" && x.LicenseProductFamily == "Core Infrastructure Server Suite Standard Core").Select(x => new { x.Licsense_Count }).ToList()[0].Licsense_Count;
                            ExcelDesign(ws, 3, 2, 11, 4);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 12, 2, 23].Merge = true;
                            ws.Cells[1, 12, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 12, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 12, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide57", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide57.png"))).SetPosition(2, 0, 10, 0);

                            ws = xp.Workbook.Worksheets.Add("Migration Option Summary");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[1, 1].Value = "Options"; ws.Cells[1, 2].Value = "Cost";
                            ws.Cells[2, 1].Value = "CUSTOM WIN"; ws.Cells[2, 2].Formula = "=SUM('Custom Apps'!F9:F12)";
                            ws.Cells[3, 1].Value = "ISV WIN"; ws.Cells[3, 2].Formula = "=SUM('ISV Apps'!F9:F12)";
                            ws.Cells[4, 1].Value = "CUSTOM SQL"; ws.Cells[4, 2].Formula = "=SUM('Custom Apps'!F15:F18)+SUM('Custom Apps'!F21:F25)";
                            ws.Cells[5, 1].Value = "ISV SQL"; ws.Cells[5, 2].Formula = "=SUM('ISV Apps'!F15:F19)";
                            ws.Cells[6, 1].Value = "LIFT AND SHIFT (SQL VM + WIN VM)"; ws.Cells[6, 2].Formula = "=SUM('All SQL VM'!I4:I8)+SUM('All Win VM'!I4:I7)";
                            ws.Cells[7, 1].Value = "SQL MI (MI + SSRS VM + ISV SQLVM + Readiness SQL VM + WIN VM)"; ws.Cells[7, 2].Formula = "=SUM('Custom Apps'!F15:F18)+SUM('ISV Apps'!F15:F19)+SUM('Component Services'!F11)+SUM('All Win VM'!I4:I7)+SUM('Custom Apps'!F21:F25)";
                            ExcelDesign(ws, 2, 6, 1, 1);
                            CurrencyFormatDesign(ws, 2, 6, 2, 2);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 8, 2, 16].Merge = true;
                            ws.Cells[1, 8, 2, 16].Value = "Reference Slide";
                            ws.Cells[1, 8, 2, 16].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 8, 2, 16].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide31", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide31.png"))).SetPosition(2, 0, 5, 0);

                            ws = xp.Workbook.Worksheets.Add("SQL Server Summary");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (SQLServerAssessmentSummary_3YearAsIsDatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[2, 2].LoadFromDataTable(SQLServerAssessmentSummary_3YearAsIsDatabaseCost, true);
                                ExcelDesign(ws, SQLServerAssessmentSummary_3YearAsIsDatabaseCost.Columns.Count, SQLServerAssessmentSummary_3YearAsIsDatabaseCost.Rows.Count, 2, 2);
                                CurrencyFormatDesign(ws, SQLServerAssessmentSummary_3YearAsIsDatabaseCost.Columns.Count, SQLServerAssessmentSummary_3YearAsIsDatabaseCost.Rows.Count, 3, 3);
                            }
                            if (SQLServerAssessmentSummary_Summary.Rows.Count != 0)
                            {
                                ws.Cells[10, 2].LoadFromDataTable(SQLServerAssessmentSummary_Summary, true);
                            }
                            ws.Cells[13, 2].Value = "Total Cost (3Y RI + AHUB)";
                            ws.Cells[13, 4].Formula = "=SUM(C3:C7)";
                            ws.Cells[13, 5].Formula = "=SUM('All SQL VM'!I4:I8)";
                            ws.Cells[13, 6].Formula = "=SUM('Custom Apps'!F15:F18)+SUM('ISV Apps'!F15:F19)+SUM('Component Services'!F3:F6)+SUM('Custom Apps'!F21:F25)";
                            ExcelDesign(ws, SQLServerAssessmentSummary_Summary.Columns.Count, SQLServerAssessmentSummary_Summary.Rows.Count + 1, 10, 2);
                            CurrencyFormatDesign(ws, SQLServerAssessmentSummary_Summary.Columns.Count, SQLServerAssessmentSummary_Summary.Rows.Count, 13, 4);
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 10, 2, 18].Merge = true;
                            ws.Cells[1, 10, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 10, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 10, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("Slide32", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Slide32.png"))).SetPosition(2, 0, 7, 0);

                            List<Tbl_Save_OnPremises_data_HBC> Tbl_Save_OnPremises_data_HBC = service.GetTbl_Save_OnPremises_data_HBC().ToList();
                            if (includeCashflow.Checked && Tbl_Save_OnPremises_data_HBC != null && Tbl_Save_OnPremises_data_HBC.Count() > 0)
                            {
                                #region Cashflow
                                ws = xp.Workbook.Worksheets.Add("Cashflow");
                                ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                                ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                                List<Sp_RightSizedIaaSEnvironmentResult> MigrationCost = service1.Sp_RightSizedIaaSEnvironment().ToList();

                                ws.Cells[8, 2].Value = "Retail Pricing without Discount";
                                ws.Cells[8, 2].Style.Font.Bold = true;
                                ws.Cells[8, 2].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                ws.Cells[8, 2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                ws.Cells[8, 2].Style.Fill.BackgroundColor.SetColor(Color.Black);
                                ws.Cells[8, 2].Style.Font.Color.SetColor(Color.White);
                                ws.Cells[10, 2].Value = "Future State Azure Cost";
                                ws.Cells[10, 2].Style.Font.Bold = true;
                                ws.Cells[11, 2].Value = "SQL SA";
                                ws.Cells[12, 2].Value = "Win SA";
                                ws.Cells[13, 2].Value = "Compute";
                                ws.Cells[14, 2].Value = "Datacenter";
                                ws.Cells[15, 2].Value = "Networking";
                                ws.Cells[16, 2].Value = "Storage";
                                ws.Cells[17, 2].Value = "IT Labor";
                                ws.Cells[18, 2].Value = "On-Premise";
                                ws.Cells[18, 2].Style.Font.Bold = true;
                                ws.Cells[19, 2].Value = "SQL SA";
                                ws.Cells[20, 2].Value = "Win SA";
                                ws.Cells[21, 2].Value = "Compute";
                                ws.Cells[22, 2].Value = "Datacenter";
                                ws.Cells[23, 2].Value = "Networking";
                                ws.Cells[24, 2].Value = "Storage";
                                ws.Cells[25, 2].Value = "IT Labor";
                                ws.Cells[26, 2].Value = "Additional Future State Costs";
                                ws.Cells[26, 2].Style.Font.Bold = true;
                                ws.Cells[27, 2].Value = "IT Labor";
                                ws.Cells[28, 2].Value = "Backup";
                                ws.Cells[29, 2].Value = "Azure Monitoring";
                                ws.Cells[30, 2].Value = "Migration Cost";
                                ws.Cells[31, 2].Value = "Modernization education";
                                ws.Cells[32, 2].Value = "Cash In";
                                ws.Cells[33, 2].Value = "Cash Out";
                                ws.Cells[34, 2].Value = "Benefit";

                                ws.Cells[9, 3].Value = "Year 1";
                                ws.Cells[10, 3].Formula = "=SUM(C11:C17)";
                                ws.Cells[11, 3].Formula = "='ISV Apps'!F16+'Component Services'!F4+'Custom Apps'!F15+'Custom Apps'!F22";
                                ws.Cells[12, 3].Formula = "='ISV Apps'!F15+'Component Services'!F3+'All Win VM'!I4+'Custom Apps'!F21";
                                //ws.Cells[13, 3].Formula = "='ISV Apps'!F17+'Component Services'!F5+'Custom Apps'!F16+'All Win VM'!I5+'Linux Server Overview'!K3+'Oracle Database'!C11+'Custom Apps'!F23";
                                ws.Cells[13, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "Compute").Select(x => x.Azure).Sum()) / 1000;
                                ws.Cells[14, 3].Value = 0;
                                ws.Cells[15, 3].Formula = "='ISV Apps'!F18+'Custom Apps'!F17+'All Win VM'!I6+'Custom Apps'!F24";
                                ws.Cells[16, 3].Formula = "='ISV Apps'!F19+'Component Services'!F6+'Custom Apps'!F18+'All Win VM'!I7+'Storage Overview'!I5+'Oracle Database'!D11+'Custom Apps'!F25";
                                ws.Cells[17, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "IT Labor").Select(x => x.Azure).Sum()) / 1000;
                                ws.Cells[18, 3].Formula = "=SUM(C19:C25)";
                                ws.Cells[19, 3].Value = LicenseDistributionData.Where(x => x.Type == "SQL_OnPrim" && x.LicenseType == "SQL_Lic").Select(x => x.Price).Sum() / 1000;
                                ws.Cells[20, 3].Value = (LicenseDistributionData.Where(x => x.Type == "SQL_OnPrim" && x.LicenseType == "Win_Lic").Select(x => x.Price).Sum() +
                                    LicenseDistributionData.Where(x => x.Type == "WINALL_OnPrim" && x.LicenseType == "Win_Lic").Select(x => x.Price).Sum()) / 1000;
                                ws.Cells[21, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "Compute").Select(x => x.OnPremise).Sum()) / 1000;
                                ws.Cells[22, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "Data Center").Select(x => x.OnPremise).Sum()) / 1000;
                                ws.Cells[23, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "Networking").Select(x => x.OnPremise).Sum()) / 1000;
                                ws.Cells[24, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "Storage").Select(x => x.OnPremise).Sum()) / 1000;
                                ws.Cells[25, 3].Value = Convert.ToDecimal(Tbl_Save_OnPremises_data_HBC.Where(x => x.SubItems == "IT Labor").Select(x => x.OnPremise).Sum()) / 1000;
                                ws.Cells[26, 3].Value = "";
                                ws.Cells[27, 3].Value = 0;
                                ws.Cells[28, 3].Value = 0;
                                ws.Cells[29, 3].Formula = "=C10*0.2"; ;
                                ws.Cells[30, 3].Value = (Convert.ToInt32(MigrationCost[0].Quantity + MigrationCost[1].Quantity +
                                    MigrationCost[2].Quantity + MigrationCost[3].Quantity) * (1000 * service.GetCurrencyRate(HttpContext.Current.Session["Currency"].ToString())[0].Rate)) / 1000;
                                ws.Cells[31, 3].Formula = "=C10*0.15";
                                ws.Cells[32, 3].Formula = "=C18";
                                ws.Cells[33, 3].Formula = "=C10+SUM(C29:C31)";
                                ws.Cells[34, 3].Formula = "=C32-C33";

                                ws.Cells[9, 4].Value = "Year 2";
                                ws.Cells[10, 4].Formula = "=SUM(D11:D17)";
                                ws.Cells[11, 4].Formula = "=C11";
                                ws.Cells[12, 4].Formula = "=C12";
                                ws.Cells[13, 4].Formula = "=C13";
                                ws.Cells[14, 4].Formula = "=C14";
                                ws.Cells[15, 4].Formula = "=C15";
                                ws.Cells[16, 4].Formula = "=C16";
                                ws.Cells[17, 4].Formula = "=C17";
                                ws.Cells[18, 4].Formula = "=SUM(D19:D25)";
                                ws.Cells[19, 4].Formula = "=C19";
                                ws.Cells[20, 4].Formula = "=C20";
                                ws.Cells[21, 4].Formula = "=C21";
                                ws.Cells[22, 4].Formula = "=C22";
                                ws.Cells[23, 4].Formula = "=C23";
                                ws.Cells[24, 4].Formula = "=C24";
                                ws.Cells[25, 4].Formula = "=C25";
                                ws.Cells[26, 4].Value = "";
                                ws.Cells[27, 4].Formula = "=C27";
                                ws.Cells[28, 4].Formula = "=C28";
                                ws.Cells[29, 4].Formula = "=D10*0.2";
                                ws.Cells[30, 4].Value = 0;
                                ws.Cells[31, 4].Value = 0;
                                ws.Cells[32, 4].Formula = "=D18";
                                ws.Cells[33, 4].Formula = "=D10+SUM(D29:D31)";
                                ws.Cells[34, 4].Formula = "=D32-D33";

                                ws.Cells[9, 5].Value = "Year 3";
                                ws.Cells[10, 5].Formula = "=SUM(E11:E17)";
                                ws.Cells[11, 5].Formula = "=C11";
                                ws.Cells[12, 5].Formula = "=C12";
                                ws.Cells[13, 5].Formula = "=C13";
                                ws.Cells[14, 5].Formula = "=C14";
                                ws.Cells[15, 5].Formula = "=C15";
                                ws.Cells[16, 5].Formula = "=C16";
                                ws.Cells[17, 5].Formula = "=C17";
                                ws.Cells[18, 5].Formula = "=SUM(E19:E25)";
                                ws.Cells[19, 5].Formula = "=C19";
                                ws.Cells[20, 5].Formula = "=C20";
                                ws.Cells[21, 5].Formula = "=C21";
                                ws.Cells[22, 5].Formula = "=C22";
                                ws.Cells[23, 5].Formula = "=C23";
                                ws.Cells[24, 5].Formula = "=C24";
                                ws.Cells[25, 5].Formula = "=C25";
                                ws.Cells[26, 5].Value = "";
                                ws.Cells[27, 5].Formula = "=C27";
                                ws.Cells[28, 5].Formula = "=C28";
                                ws.Cells[29, 5].Formula = "=E10*0.2";
                                ws.Cells[30, 5].Value = 0;
                                ws.Cells[31, 5].Value = 0;
                                ws.Cells[32, 5].Formula = "=E18";
                                ws.Cells[33, 5].Formula = "=E10+SUM(E29:E31)";
                                ws.Cells[34, 5].Formula = "=E32-E33";

                                ws.Cells[9, 6].Value = "Year 4";
                                ws.Cells[10, 6].Formula = "=SUM(F11:F17)";
                                ws.Cells[11, 6].Formula = "=C11";
                                ws.Cells[12, 6].Formula = "=C12";
                                ws.Cells[13, 6].Formula = "=C13";
                                ws.Cells[14, 6].Formula = "=C14";
                                ws.Cells[15, 6].Formula = "=C15";
                                ws.Cells[16, 6].Formula = "=C16";
                                ws.Cells[17, 6].Formula = "=C17";
                                ws.Cells[18, 6].Formula = "=SUM(F19:F25)";
                                ws.Cells[19, 6].Formula = "=C19";
                                ws.Cells[20, 6].Formula = "=C20";
                                ws.Cells[21, 6].Formula = "=C21";
                                ws.Cells[22, 6].Formula = "=C22";
                                ws.Cells[23, 6].Formula = "=C23";
                                ws.Cells[24, 6].Formula = "=C24";
                                ws.Cells[25, 6].Formula = "=C25";
                                ws.Cells[26, 6].Value = "";
                                ws.Cells[27, 6].Formula = "=C27";
                                ws.Cells[28, 6].Formula = "=C28";
                                ws.Cells[29, 6].Formula = "=F10*0.2";
                                ws.Cells[30, 6].Value = 0;
                                ws.Cells[31, 6].Value = 0;
                                ws.Cells[32, 6].Formula = "=F18";
                                ws.Cells[33, 6].Formula = "=F10+SUM(F29:F31)";
                                ws.Cells[34, 6].Formula = "=F32-F33";

                                ws.Cells[9, 7].Value = "Year 5";
                                ws.Cells[10, 7].Formula = "=SUM(G11:G17)";
                                ws.Cells[11, 7].Formula = "=C11";
                                ws.Cells[12, 7].Formula = "=C12";
                                ws.Cells[13, 7].Formula = "=C13";
                                ws.Cells[14, 7].Formula = "=C14";
                                ws.Cells[15, 7].Formula = "=C15";
                                ws.Cells[16, 7].Formula = "=C16";
                                ws.Cells[17, 7].Formula = "=C17";
                                ws.Cells[18, 7].Formula = "=SUM(G19:G25)";
                                ws.Cells[19, 7].Formula = "=C19";
                                ws.Cells[20, 7].Formula = "=C20";
                                ws.Cells[21, 7].Formula = "=C21";
                                ws.Cells[22, 7].Formula = "=C22";
                                ws.Cells[23, 7].Formula = "=C23";
                                ws.Cells[24, 7].Formula = "=C24";
                                ws.Cells[25, 7].Formula = "=C25";
                                ws.Cells[26, 7].Value = "";
                                ws.Cells[27, 7].Formula = "=C27";
                                ws.Cells[28, 7].Formula = "=C28";
                                ws.Cells[29, 7].Formula = "=G10*0.2";
                                ws.Cells[30, 7].Value = 0;
                                ws.Cells[31, 7].Value = 0;
                                ws.Cells[32, 7].Formula = "=G18";
                                ws.Cells[33, 7].Formula = "=G10+SUM(G29:G31)";
                                ws.Cells[34, 7].Formula = "=G32-G33";

                                ws.Cells[9, 8].Value = "Total";
                                ws.Cells[10, 8].Formula = "=SUM(C10:G10)";
                                ws.Cells[11, 8].Formula = "=SUM(C11:G11)";
                                ws.Cells[12, 8].Formula = "=SUM(C12:G12)";
                                ws.Cells[13, 8].Formula = "=SUM(C13:G13)";
                                ws.Cells[14, 8].Formula = "=SUM(C14:G14)";
                                ws.Cells[15, 8].Formula = "=SUM(C15:G15)";
                                ws.Cells[16, 8].Formula = "=SUM(C16:G16)";
                                ws.Cells[17, 8].Formula = "=SUM(C17:G17)";
                                ws.Cells[18, 8].Formula = "=SUM(C18:G18)";
                                ws.Cells[19, 8].Formula = "=SUM(C19:G19)";
                                ws.Cells[20, 8].Formula = "=SUM(C20:G20)";
                                ws.Cells[21, 8].Formula = "=SUM(C21:G21)";
                                ws.Cells[22, 8].Formula = "=SUM(C22:G22)";
                                ws.Cells[23, 8].Formula = "=SUM(C23:G23)";
                                ws.Cells[24, 8].Formula = "=SUM(C24:G24)";
                                ws.Cells[25, 8].Formula = "=SUM(C25:G25)";
                                ws.Cells[26, 8].Value = "";
                                ws.Cells[27, 8].Formula = "=SUM(C27:G27)";
                                ws.Cells[28, 8].Formula = "=SUM(C28:G28)";
                                ws.Cells[29, 8].Formula = "=SUM(C29:G29)";
                                ws.Cells[30, 8].Formula = "=SUM(C30:G30)";
                                ws.Cells[31, 8].Formula = "=SUM(C31:G31)";
                                ws.Cells[32, 8].Formula = "=SUM(C32:G32)";
                                ws.Cells[33, 8].Formula = "=SUM(C33:G33)";
                                ws.Cells[34, 8].Formula = "=SUM(C34:G34)";
                                ExcelDesign(ws, 7, 25, 9, 2);
                                CurrencyFormatDesign(ws, 6, 25, 10, 3);

                                ws.Cells[2, 2].Value = "Retail Pricing without Discount";
                                ws.Cells[2, 2].Style.Font.Bold = true;
                                ws.Cells[2, 2].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                ws.Cells[2, 2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                ws.Cells[2, 2].Style.Fill.BackgroundColor.SetColor(Color.Black);
                                ws.Cells[2, 2].Style.Font.Color.SetColor(Color.White);
                                ws.Cells[4, 2].Value = "Cash Flow In (Savings)";
                                ws.Cells[5, 2].Value = "Cash Flow Out (Costs)";
                                ws.Cells[6, 2].Value = "Benefit";

                                ws.Cells[3, 3].Value = "Year 1";
                                ws.Cells[4, 3].Formula = "=C32";
                                ws.Cells[5, 3].Formula = "=C33*-1";
                                ws.Cells[6, 3].Formula = "=C34";
                                ws.Cells[3, 4].Value = "Year 2";
                                ws.Cells[4, 4].Formula = "=D32";
                                ws.Cells[5, 4].Formula = "=D33*-1";
                                ws.Cells[6, 4].Formula = "=D34";
                                ws.Cells[3, 5].Value = "Year 3";
                                ws.Cells[4, 5].Formula = "=E32";
                                ws.Cells[5, 5].Formula = "=E33*-1";
                                ws.Cells[6, 5].Formula = "=E34";
                                ws.Cells[3, 6].Value = "Year 4";
                                ws.Cells[4, 6].Formula = "=F32";
                                ws.Cells[5, 6].Formula = "=F33*-1";
                                ws.Cells[6, 6].Formula = "=F34";
                                ws.Cells[3, 7].Value = "Year 5";
                                ws.Cells[4, 7].Formula = "=G32";
                                ws.Cells[5, 7].Formula = "=G33*-1";
                                ws.Cells[6, 7].Formula = "=G34";
                                ExcelDesign(ws, 6, 3, 3, 2);
                                CurrencyFormatDesign(ws, 5, 3, 4, 3);

                                ws.Cells[37, 2].Value = "Component";
                                ws.Cells[38, 2].Value = "Total spend in the future state (Cash Flow Out)";
                                ws.Cells[39, 2].Value = "Total cost savings due to transformation (Cash Flow In)";
                                ws.Cells[40, 2].Value = "Benefit";
                                ws.Cells[41, 2].Value = "Cash Flow Positive";
                                ws.Cells[37, 3].Value = "Value*";
                                ws.Cells[38, 3].Formula = "=H33";
                                ws.Cells[39, 3].Formula = "=H32";
                                ws.Cells[40, 3].Formula = "=H34";
                                ws.Cells[41, 3].Formula = "=IF(C34>0,\"Year 1\",IF(D34>0,\"Year 2\",IF(E34>0,\"Year 3\",IF(F34>0,\"Year 4\",\"Year 5\"))))";
                                ExcelDesign(ws, 2, 4, 37, 2);
                                CurrencyFormatDesign(ws, 1, 3, 38, 3);

                                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                                ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                                ws.Cells[1, 13, 2, 21].Merge = true;
                                ws.Cells[1, 13, 2, 21].Value = "Reference Slide";
                                ws.Cells[1, 13, 2, 21].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                ws.Cells[1, 13, 2, 21].Style.Font.Bold = true;
                                ws.Cells.Worksheet.Drawings.AddPicture("Cashflow", System.Drawing.Image.
                                    FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/Cashflow.png"))).SetPosition(2, 0, 10, 0);
                                #endregion
                            }

                            Response.AddHeader("content-disposition", "attachment;filename=" + InventoryName + "_" + "HBCWorkbook [" + CurrencyMode + "].xlsx");
                            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            Response.BinaryWrite(xp.GetAsByteArray());
                            HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                            HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                            HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                            //Response.End();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        public DataSet GetExcelData()
        {
            DataSet ds = new DataSet("BoomRang");
            try
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString());

                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);

                #region Scope of Assessment
                List<Sp_ScopeOfAssessment_WindowsServerCountResult> ScopeOfAssessment_WindowsServerCount = service.Sp_ScopeOfAssessment_WindowsServerCount().ToList();
                if (ScopeOfAssessment_WindowsServerCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_WindowsServerCount));
                    dt.TableName = "Slide 5_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_ScopeOfAssessment_WindowsServerVersionInstanceCountResult> ScopeOfAssessment_WindowsServerVersionInstanceCount = service.Sp_ScopeOfAssessment_WindowsServerVersionInstanceCount().ToList();
                if (ScopeOfAssessment_WindowsServerVersionInstanceCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_WindowsServerVersionInstanceCount));
                    dt.TableName = "Slide 5_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_ScopeOfAssessment_LinuxServerCountResult> ScopeOfAssessment_LinuxServerCount = service.Sp_ScopeOfAssessment_LinuxServerCount().ToList();
                if (ScopeOfAssessment_LinuxServerCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_LinuxServerCount));
                    dt.TableName = "Slide 5_3";
                    ds.Tables.Add(dt);
                }
                List<Sp_ScopeOfAssessment_LinuxServerVersionInstanceCountResult> ScopeOfAssessment_LinuxServerVersionInstanceCount = service.Sp_ScopeOfAssessment_LinuxServerVersionInstanceCount().ToList();
                if (ScopeOfAssessment_LinuxServerVersionInstanceCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_LinuxServerVersionInstanceCount));
                    dt.TableName = "Slide 5_4";
                    ds.Tables.Add(dt);
                }

                List<Sp_ScopeOfAssessment_ApplicationAndWorkloadResult> ScopeOfAssessment_ApplicationAndWorkload = service.Sp_ScopeOfAssessment_ApplicationAndWorkload().ToList();
                if (ScopeOfAssessment_ApplicationAndWorkload.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_ApplicationAndWorkload));
                    dt.TableName = "Slide 6";
                    ds.Tables.Add(dt);
                }

                List<Sp_ScopeOfAssessment_DataEstateSQLServerCountResult> ScopeOfAssessment_DataEstateSQLServerCount = service.Sp_ScopeOfAssessment_DataEstateSQLServerCount().ToList();
                if (ScopeOfAssessment_DataEstateSQLServerCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_DataEstateSQLServerCount));
                    dt.TableName = "Slide 7_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_ScopeOfAssessment_DataEstateSQLServerVersionEditionInstanceCountResult> ScopeOfAssessment_DataEstateSQLServerVersionEditionInstanceCount = service.Sp_ScopeOfAssessment_DataEstateSQLServerVersionEditionInstanceCount().ToList();
                if (ScopeOfAssessment_DataEstateSQLServerVersionEditionInstanceCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_DataEstateSQLServerVersionEditionInstanceCount));
                    dt.TableName = "Slide 7_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_ScopeOfAssessment_DataEstateOracleCountResult> ScopeOfAssessment_DataEstateOracleCount = service.Sp_ScopeOfAssessment_DataEstateOracleCount().ToList();
                if (ScopeOfAssessment_DataEstateOracleCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_DataEstateOracleCount));
                    dt.TableName = "Slide 7_3";
                    ds.Tables.Add(dt);
                }
                List<Sp_ScopeOfAssessment_DataEstateOracleVersionInstanceCountResult> ScopeOfAssessment_DataEstateOracleVersionInstanceCount = service.Sp_ScopeOfAssessment_DataEstateOracleVersionInstanceCount().ToList();
                if (ScopeOfAssessment_DataEstateOracleVersionInstanceCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ScopeOfAssessment_DataEstateOracleVersionInstanceCount));
                    dt.TableName = "Slide 7_4";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region RightSizedIaaSEnvironment
                List<Sp_RightSizedIaaSEnvironmentResult> RightSizedIaaSEnvironment = service.Sp_RightSizedIaaSEnvironment().ToList();
                if (RightSizedIaaSEnvironment.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(RightSizedIaaSEnvironment));
                    dt.TableName = "Slide 9";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region WindowsServerOverview
                List<Sp_WindowsServerOverview_EndofServiceMachineResult> WindowsServerOverview_EndofServiceMachine = service.Sp_WindowsServerOverview_EndofServiceMachine().ToList();
                if (WindowsServerOverview_EndofServiceMachine.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(WindowsServerOverview_EndofServiceMachine));
                    dt.TableName = "Slide 10_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_WindowsServerOverview_CloudEconomicModelingResult> WindowsServerOverview_CloudEconomicModeling = service.Sp_WindowsServerOverview_CloudEconomicModeling().ToList();
                if (WindowsServerOverview_CloudEconomicModeling.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(WindowsServerOverview_CloudEconomicModeling));
                    dt.TableName = "Slide 10_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_WindowsServerOverview_1YearCostResult> WindowsServerOverview_1YearCost = service.Sp_WindowsServerOverview_1YearCost().ToList();
                if (WindowsServerOverview_1YearCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(WindowsServerOverview_1YearCost));
                    dt.TableName = "Slide 10_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region LinuxServerOverview
                List<Sp_LinuxServerOverview_EndofServiceMachineResult> LinuxServerOverview_EndofServiceMachine = service.Sp_LinuxServerOverview_EndofServiceMachine().ToList();
                if (LinuxServerOverview_EndofServiceMachine.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(LinuxServerOverview_EndofServiceMachine));
                    dt.TableName = "Slide 11_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_LinuxServerOverview_CloudEconomicModelingResult> LinuxServerOverview_CloudEconomicModeling = service.Sp_LinuxServerOverview_CloudEconomicModeling().ToList();
                if (LinuxServerOverview_CloudEconomicModeling.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(LinuxServerOverview_CloudEconomicModeling));
                    dt.TableName = "Slide 11_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_LinuxServerOverview_1YearCostResult> LinuxServerOverview_1YearCost = service.Sp_LinuxServerOverview_1YearCost().ToList();
                if (LinuxServerOverview_1YearCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(LinuxServerOverview_1YearCost));
                    dt.TableName = "Slide 11_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQLServerOverview
                List<Sp_SQLServerOverview_EndofServiceMachineResult> SQLServerOverview_EndofServiceMachine = service.Sp_SQLServerOverview_EndofServiceMachine().ToList();
                if (SQLServerOverview_EndofServiceMachine.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerOverview_EndofServiceMachine));
                    dt.TableName = "Slide 12_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLServerOverview_CloudEconomicModelingResult> SQLServerOverview_CloudEconomicModeling = service.Sp_SQLServerOverview_CloudEconomicModeling().ToList();
                if (SQLServerOverview_CloudEconomicModeling.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerOverview_CloudEconomicModeling));
                    dt.TableName = "Slide 12_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLServerOverview_1YearCostResult> SQLServerOverview_1YearCost = service.Sp_SQLServerOverview_1YearCost().ToList();
                if (SQLServerOverview_1YearCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerOverview_1YearCost));
                    dt.TableName = "Slide 12_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region ASRAndBackupCost
                List<Sp_ASRAndBackupCost_SummaryResult> ASRAndBackupCost_Summary = service.Sp_ASRAndBackupCost_Summary().ToList();
                if (ASRAndBackupCost_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ASRAndBackupCost_Summary));
                    dt.TableName = "Slide 13_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_ASRAndBackupCost_BreakdownResult> ASRAndBackupCost_Breakdown = service.Sp_ASRAndBackupCost_Breakdown().ToList();
                if (ASRAndBackupCost_Breakdown.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ASRAndBackupCost_Breakdown));
                    dt.TableName = "Slide 13_2";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region StorageOverview
                List<Sp_StorageOverview_StorageSizeBreakdownResult> StorageOverview_StorageSizeBreakdown = service.Sp_StorageOverview_StorageSizeBreakdown().ToList();
                if (StorageOverview_StorageSizeBreakdown.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(StorageOverview_StorageSizeBreakdown));
                    dt.TableName = "Slide 14_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_StorageOverview_SummaryResult> StorageOverview_Summary = service.Sp_StorageOverview_Summary().ToList();
                if (StorageOverview_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(StorageOverview_Summary));
                    dt.TableName = "Slide 14_2";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region ISVApplicationsWithSQLMigration
                List<Sp_ISVApplicationsWithSQLMigration_SummaryResult> ISVApplicationsWithSQLMigration_Summary = service.Sp_ISVApplicationsWithSQLMigration_Summary().ToList();
                if (ISVApplicationsWithSQLMigration_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ISVApplicationsWithSQLMigration_Summary));
                    dt.TableName = "Slide 19_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_ISVApplicationsWithSQLMigration_ApplicationServerCostResult> ISVApplicationsWithSQLMigration_ApplicationServerCost = service.Sp_ISVApplicationsWithSQLMigration_ApplicationServerCost().ToList();
                if (ISVApplicationsWithSQLMigration_ApplicationServerCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ISVApplicationsWithSQLMigration_ApplicationServerCost));
                    dt.TableName = "Slide 19_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_ISVApplicationsWithSQLMigration_DatabaseCostResult> ISVApplicationsWithSQLMigration_DatabaseCost = service.Sp_ISVApplicationsWithSQLMigration_DatabaseCost().ToList();
                if (ISVApplicationsWithSQLMigration_DatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ISVApplicationsWithSQLMigration_DatabaseCost));
                    dt.TableName = "Slide 19_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQLAnalytical
                List<Sp_SQLAnalytical_SummaryResult> SQLAnalytical_Summary = service.Sp_SQLAnalytical_Summary().ToList();
                if (SQLAnalytical_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLAnalytical_Summary));
                    dt.TableName = "Slide 21_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLAnalytical_WorkloadCountResult> SQLAnalytical_WorkloadCount = service.Sp_SQLAnalytical_WorkloadCount().ToList();
                if (SQLAnalytical_WorkloadCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLAnalytical_WorkloadCount));
                    dt.TableName = "Slide 21_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLAnalytical_ComponentVMBreakdownResult> SQLAnalytical_ComponentVMBreakdown = service.Sp_SQLAnalytical_ComponentVMBreakdown().ToList();
                if (SQLAnalytical_ComponentVMBreakdown.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLAnalytical_ComponentVMBreakdown));
                    dt.TableName = "Slide 21_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region CustomBuildApplicationsWithSQLDatabases
                List<Sp_CustomBuildApplicationsWithSQLDatabases_SummaryResult> CustomBuildApplicationsWithSQLDatabases_Summary = service.Sp_CustomBuildApplicationsWithSQLDatabases_Summary().ToList();
                if (CustomBuildApplicationsWithSQLDatabases_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(CustomBuildApplicationsWithSQLDatabases_Summary));
                    dt.TableName = "Slide 25_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_CustomBuildApplicationsWithSQLDatabases_ApplicationServerCostResult> CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost = service.Sp_CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost().ToList();
                if (CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(CustomBuildApplicationsWithSQLDatabases_ApplicationServerCost));
                    dt.TableName = "Slide 25_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_CustomBuildApplicationsWithSQLDatabases_DatabaseCostResult> CustomBuildApplicationsWithSQLDatabases_DatabaseCost = service.Sp_CustomBuildApplicationsWithSQLDatabases_DatabaseCost().ToList();
                if (CustomBuildApplicationsWithSQLDatabases_DatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(CustomBuildApplicationsWithSQLDatabases_DatabaseCost));
                    dt.TableName = "Slide 25_3";
                    ds.Tables.Add(dt);
                }
                List<Sp_ReadinessAnalysedApplicationsWithSQLMigration_SummaryResult> ReadinessAnalysedApplicationsWithSQLMigration_Summary = service.Sp_ReadinessAnalysedApplicationsWithSQLMigration_Summary().ToList();
                if (ReadinessAnalysedApplicationsWithSQLMigration_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ReadinessAnalysedApplicationsWithSQLMigration_Summary));
                    dt.TableName = "Slide 25_4";
                    ds.Tables.Add(dt);
                }
                List<Sp_ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCostResult> ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost = service.Sp_ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost().ToList();
                if (ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(ReadinessAnalysedApplicationsWithSQLMigration_DatabaseCost));
                    dt.TableName = "Slide 25_5";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region OracleToPostgreSQL
                List<Sp_OracleToPostgreSQL_SummaryResult> OracleToPostgreSQL_Summary = service.Sp_OracleToPostgreSQL_Summary().ToList();
                if (OracleToPostgreSQL_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(OracleToPostgreSQL_Summary));
                    dt.TableName = "Slide 29_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_OracleToPostgreSQL_AnnualCostResult> OracleToPostgreSQL_AnnualCost = service.Sp_OracleToPostgreSQL_AnnualCost().ToList();
                if (OracleToPostgreSQL_AnnualCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(OracleToPostgreSQL_AnnualCost));
                    dt.TableName = "Slide 29_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_OracleToPostgreSQL_MonthlyCostBreakdownResult> OracleToPostgreSQL_MonthlyCostBreakdown = service.Sp_OracleToPostgreSQL_MonthlyCostBreakdown().ToList();
                if (OracleToPostgreSQL_MonthlyCostBreakdown.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(OracleToPostgreSQL_MonthlyCostBreakdown));
                    dt.TableName = "Slide 29_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQLMICoreAndCostCalculation
                List<Sp_SQLMICoreAndCostCalculationResult> SQLMICoreAndCostCalculation = service.Sp_SQLMICoreAndCostCalculation().ToList();
                if (SQLMICoreAndCostCalculation.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLMICoreAndCostCalculation));
                    dt.TableName = "Slide 55";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQLServerCoreAndCostCalculation
                List<Sp_SQLServerCoreAndCostCalculation_SummaryResult> SQLServerCoreAndCostCalculation_Summary = service.Sp_SQLServerCoreAndCostCalculation_Summary().ToList();
                if (SQLServerCoreAndCostCalculation_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerCoreAndCostCalculation_Summary));
                    dt.TableName = "Slide 56_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLServerCoreAndCostCalculation_RAMOptimizationResult> SQLServerCoreAndCostCalculation_RAMOptimization = service.Sp_SQLServerCoreAndCostCalculation_RAMOptimization().ToList();
                if (SQLServerCoreAndCostCalculation_RAMOptimization.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerCoreAndCostCalculation_RAMOptimization));
                    dt.TableName = "Slide 56_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLServerCoreAndCostCalculation_DatabaseCostResult> SQLServerCoreAndCostCalculation_DatabaseCost = service.Sp_SQLServerCoreAndCostCalculation_DatabaseCost().ToList();
                if (SQLServerCoreAndCostCalculation_DatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerCoreAndCostCalculation_DatabaseCost));
                    dt.TableName = "Slide 56_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region WindowsServerCoreAndCostCalculation
                List<Sp_WindowsServerCoreAndCostCalculation_SummaryResult> WindowsServerCoreAndCostCalculation_Summary = service.Sp_WindowsServerCoreAndCostCalculation_Summary().ToList();
                if (WindowsServerCoreAndCostCalculation_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(WindowsServerCoreAndCostCalculation_Summary));
                    dt.TableName = "Slide 57_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_WindowsServerCoreAndCostCalculation_RAMOptimizationResult> WindowsServerCoreAndCostCalculation_RAMOptimization = service.Sp_WindowsServerCoreAndCostCalculation_RAMOptimization().ToList();
                if (WindowsServerCoreAndCostCalculation_RAMOptimization.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(WindowsServerCoreAndCostCalculation_RAMOptimization));
                    dt.TableName = "Slide 57_2";
                    ds.Tables.Add(dt);
                }
                List<Sp_WindowsServerCoreAndCostCalculation_DatabaseCostResult> WindowsServerCoreAndCostCalculation_DatabaseCost = service.Sp_WindowsServerCoreAndCostCalculation_DatabaseCost().ToList();
                if (WindowsServerCoreAndCostCalculation_DatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(WindowsServerCoreAndCostCalculation_DatabaseCost));
                    dt.TableName = "Slide 57_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQLServerAssessmentSummary
                List<Sp_SQLServerAssessmentSummary_3YearAsIsDatabaseCostResult> SQLServerAssessmentSummary_3YearAsIsDatabaseCost = service.Sp_SQLServerAssessmentSummary_3YearAsIsDatabaseCost().ToList();
                if (SQLServerAssessmentSummary_3YearAsIsDatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerAssessmentSummary_3YearAsIsDatabaseCost));
                    dt.TableName = "Slide 32_1";
                    ds.Tables.Add(dt);
                }
                List<Sp_SQLServerAssessmentSummary_SummaryResult> SQLServerAssessmentSummary_Summary = service.Sp_SQLServerAssessmentSummary_Summary().ToList();
                if (SQLServerAssessmentSummary_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(SQLServerAssessmentSummary_Summary));
                    dt.TableName = "Slide 32_2";
                    ds.Tables.Add(dt);
                }
                #endregion
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return ds;
        }
        public static void ExcelDesign(ExcelWorksheet Slide, int sp_ColsCount, int sp_RowsCount, int Row, int Cols)
        {
            for (int i = 0; i < sp_ColsCount; i++)
            {
                Slide.Cells[Row, Cols + i].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                Slide.Cells[Row, Cols + i].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                Slide.Cells[Row, Cols + i].Style.Fill.BackgroundColor.SetColor(Color.Black);
                Slide.Cells[Row, Cols + i].Style.Font.Color.SetColor(Color.White);
            }
            for (int i = 0; i <= sp_RowsCount; i++)
            {
                for (int j = 0; j < sp_ColsCount; j++)
                {
                    Slide.Cells[Row + i, Cols + j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                }
            }
        }
        public static void simpleExcelDesign(ExcelWorksheet Slide, int sp_ColsCount, int sp_RowsCount, int Row, int Cols)
        {
            for (int i = 0; i < sp_ColsCount; i++)
            {
                Slide.Cells[Row, Cols + i].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                Slide.Cells[Row, Cols + i].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                Slide.Cells[Row, Cols + i].Style.Font.Color.SetColor(Color.White);
            }
            for (int i = 0; i <= sp_RowsCount; i++)
            {
                for (int j = 0; j < sp_ColsCount; j++)
                {
                    Slide.Cells[Row + i, Cols + j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                }
            }
        }
        public static void CurrencyFormatDesign(ExcelWorksheet Slide, int sp_ColsCount, int sp_RowsCount, int Row, int Cols)
        {
            for (int i = 0; i <= sp_RowsCount; i++)
            {
                for (int j = 0; j < sp_ColsCount; j++)
                {
                    Slide.Cells[Row + i, Cols + j].Style.Numberformat.Format = CurrencyFormat;
                }
            }
        }
        protected void GeneratePPT(object sender, EventArgs e)
        {
            try
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                decimal SQLStandard = Convert.ToDecimal(SQLStdPPT.Value);
                decimal SQLEnterprise = Convert.ToDecimal(SQLEntPPT.Value);
                decimal WindowsStandard = Convert.ToDecimal(WinStdPPT.Value);
                decimal WindowsDatacenter = Convert.ToDecimal(WinDCPPT.Value);
                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                service.SaveBoomrang(WindowsDatacenter, WindowsStandard, SQLStandard, SQLEnterprise);
                CreateExcelFileForPPT();
                CreateHBCReport();
                DownloadPPT();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        public void DownloadPPT()
        {
            string fileName = InventoryName + "_" + "HBCPPT [" + CurrencyMode + "].pptx";
            string strURL = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + fileName);
            WebClient req = new WebClient();
            HttpResponse response = HttpContext.Current.Response;
            response.Clear();
            response.ClearContent();
            response.ClearHeaders();
            response.Buffer = true;
            response.ContentType = "application/msword";
            response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
            byte[] data = req.DownloadData(strURL);
            response.BinaryWrite(data);
            response.End();
            response.Flush();
        }
        public void CreateHBCReport()
        {
            string fileName = InventoryName + "_" + "HBCPPT [" + CurrencyMode + "].pptx";
            GenerateHBCPPT ppt = new GenerateHBCPPT();
            string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
            if (Directory.Exists(docfilepath) == false)
            {
                Directory.CreateDirectory(docfilepath);
            }
            string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + fileName);
            if (File.Exists(path))
            {
                File.Delete(path);
            }
            ppt.CreatePackage(path);
        }
        void CreateExcelFileForPPT()
        {
            try
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString());
                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);

                #region Input Data Into List
                List<Sp_WindowsServerOverview_EndofServiceMachineResult> WindowsServerOverview_EndofServiceMachineResult = service.Sp_WindowsServerOverview_EndofServiceMachine().ToList();
                List<Sp_WindowsServerOverview_CloudEconomicModelingResult> WindowsServerOverview_CloudEconomicModelingResult = service.Sp_WindowsServerOverview_CloudEconomicModeling().ToList();
                List<Sp_LinuxServerOverview_EndofServiceMachineResult> LinuxServerOverview_EndofServiceMachineResult = service.Sp_LinuxServerOverview_EndofServiceMachine().ToList();
                List<Sp_LinuxServerOverview_CloudEconomicModelingResult> LinuxServerOverview_CloudEconomicModelingResult = service.Sp_LinuxServerOverview_CloudEconomicModeling().ToList();
                List<Sp_SQLServerOverview_EndofServiceMachineResult> SQLServerOverview_EndofServiceMachineResult = service.Sp_SQLServerOverview_EndofServiceMachine().ToList();
                List<Sp_SQLServerOverview_CloudEconomicModelingResult> SQLServerOverview_CloudEconomicModelingResult = service.Sp_SQLServerOverview_CloudEconomicModeling().ToList();
                List<Sp_ASRAndBackupCost_BreakdownResult> ASRAndBackupCost_BreakdownResult = service.Sp_ASRAndBackupCost_Breakdown().ToList();
                List<Sp_StorageOverview_StorageSizeBreakdownResult> StorageOverview_StorageSizeBreakdownResult = service.Sp_StorageOverview_StorageSizeBreakdown().ToList();
                #endregion

                #region Save Excel Files
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(WindowsServerOverview_EndofServiceMachine, true);
                    ws.Cells[1, 1].Value = "CurrentOperatingSystem"; ws.Cells[1, 2].Value = "Count";
                    for (int i = 0; i < WindowsServerOverview_EndofServiceMachineResult.Count; i++)
                    {
                        ws.Cells[2 + i, 1].Value = WindowsServerOverview_EndofServiceMachineResult[i].CurrentOperatingSystem;
                        ws.Cells[2 + i, 2].Value = WindowsServerOverview_EndofServiceMachineResult[i].Count;
                    }

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "Win_Server_EOS.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(WindowsServerOverview_CloudEconomicModeling, true);
                    ws.Cells[1, 1].Value = ""; ws.Cells[1, 2].Value = "Series 1";
                    ws.Cells[2, 1].Value = "AS-IS"; ws.Cells[2, 2].Value = WindowsServerOverview_CloudEconomicModelingResult[0].AS_IS;
                    ws.Cells[3, 1].Value = "PAY G AHUB"; ws.Cells[3, 2].Value = WindowsServerOverview_CloudEconomicModelingResult[0].PAYG_AHUB;
                    ws.Cells[4, 1].Value = "1 Y RI AHUB"; ws.Cells[4, 2].Value = WindowsServerOverview_CloudEconomicModelingResult[0]._1Y_RI_AHUB;
                    ws.Cells[5, 1].Value = "3 Y RI AHUB"; ws.Cells[5, 2].Value = WindowsServerOverview_CloudEconomicModelingResult[0]._3Y_RI_AHUB;

                    ws.Cells[2, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[3, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[4, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[5, 2].Style.Numberformat.Format = CurrencyFormat;

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "Win_Server_CEM.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(LinuxServerOverview_EndofServiceMachine, true);
                    ws.Cells[1, 1].Value = "CurrentOperatingSystem"; ws.Cells[1, 2].Value = "Count";
                    for (int i = 0; i < LinuxServerOverview_EndofServiceMachineResult.Count; i++)
                    {
                        ws.Cells[2 + i, 1].Value = LinuxServerOverview_EndofServiceMachineResult[i].CurrentOperatingSystem;
                        ws.Cells[2 + i, 2].Value = LinuxServerOverview_EndofServiceMachineResult[i].Count;
                    }

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "Linux_Server_EOS.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(LinuxServerOverview_CloudEconomicModeling, true);
                    ws.Cells[1, 1].Value = ""; ws.Cells[1, 2].Value = "Series 1";
                    ws.Cells[2, 1].Value = "AS-IS"; ws.Cells[2, 2].Value = LinuxServerOverview_CloudEconomicModelingResult[0].AS_IS;
                    ws.Cells[3, 1].Value = "PAY G AHUB"; ws.Cells[3, 2].Value = LinuxServerOverview_CloudEconomicModelingResult[0].PAYG_AHUB;
                    ws.Cells[4, 1].Value = "1 Y RI AHUB"; ws.Cells[4, 2].Value = LinuxServerOverview_CloudEconomicModelingResult[0]._1Y_RI_AHUB;
                    ws.Cells[5, 1].Value = "3 Y RI AHUB"; ws.Cells[5, 2].Value = LinuxServerOverview_CloudEconomicModelingResult[0]._3Y_RI_AHUB;

                    ws.Cells[2, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[3, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[4, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[5, 2].Style.Numberformat.Format = CurrencyFormat;

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "Linux_Server_CEM.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(SQLServerOverview_EndofServiceMachine, true);
                    ws.Cells[1, 1].Value = "CurrentOperatingSystem"; ws.Cells[1, 2].Value = "Count";
                    for (int i = 0; i < SQLServerOverview_EndofServiceMachineResult.Count; i++)
                    {
                        ws.Cells[2 + i, 1].Value = SQLServerOverview_EndofServiceMachineResult[i].CurrentOperatingSystem;
                        ws.Cells[2 + i, 2].Value = SQLServerOverview_EndofServiceMachineResult[i].Count;
                    }

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "SQL_Server_EOS.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(SQLServerOverview_CloudEconomicModeling, true);
                    ws.Cells[1, 1].Value = ""; ws.Cells[1, 2].Value = "Series 1";
                    ws.Cells[2, 1].Value = "AS-IS"; ws.Cells[2, 2].Value = SQLServerOverview_CloudEconomicModelingResult[0].AS_IS;
                    ws.Cells[3, 1].Value = "PAY G AHUB"; ws.Cells[3, 2].Value = SQLServerOverview_CloudEconomicModelingResult[0].PAYG_AHUB;
                    ws.Cells[4, 1].Value = "1 Y RI AHUB"; ws.Cells[4, 2].Value = SQLServerOverview_CloudEconomicModelingResult[0]._1Y_RI_AHUB;
                    ws.Cells[5, 1].Value = "3 Y RI AHUB"; ws.Cells[5, 2].Value = SQLServerOverview_CloudEconomicModelingResult[0]._3Y_RI_AHUB;

                    ws.Cells[2, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[3, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[4, 2].Style.Numberformat.Format = CurrencyFormat;
                    ws.Cells[5, 2].Style.Numberformat.Format = CurrencyFormat;

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "SQL_Server_CEM.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(ASRAndBackupCost_Breakdown, true);
                    ws.Cells[1, 1].Value = ""; ws.Cells[1, 2].Value = "ASR & DR Cost"; ws.Cells[1, 3].Value = "Azure Backup Cost";
                    for (int i = 0; i < ASRAndBackupCost_BreakdownResult.Count; i++)
                    {
                        ws.Cells[2 + i, 1].Value = ASRAndBackupCost_BreakdownResult[i].Type;
                        ws.Cells[2 + i, 2].Value = ASRAndBackupCost_BreakdownResult[i].ASR___DR_Cost;
                        ws.Cells[2 + i, 2].Style.Numberformat.Format = CurrencyFormat;
                        ws.Cells[2 + i, 3].Value = ASRAndBackupCost_BreakdownResult[i].Azure_Backup_Cost;
                        ws.Cells[2 + i, 3].Style.Numberformat.Format = CurrencyFormat;
                    }

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "ASR_DR.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                using (ExcelPackage xp = new ExcelPackage())
                {
                    ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Sheet 1");
                    //ws.Cells[1, 1].LoadFromDataTable(StorageOverview_StorageSizeBreakdown, true);
                    ws.Cells[1, 1].Value = "Storage Size"; ws.Cells[1, 2].Value = "As-Is"; ws.Cells[1, 3].Value = "Right-Sized";
                    for (int i = 0; i < StorageOverview_StorageSizeBreakdownResult.Count; i++)
                    {
                        ws.Cells[2 + i, 1].Value = StorageOverview_StorageSizeBreakdownResult[i].Storage_Size;
                        ws.Cells[2 + i, 2].Value = StorageOverview_StorageSizeBreakdownResult[i].As_Is;
                        ws.Cells[2 + i, 3].Value = StorageOverview_StorageSizeBreakdownResult[i].Right_Sized;
                    }

                    string docfilepath = Server.MapPath("~/HBC/HBCPPT/" + DBID);
                    if (Directory.Exists(docfilepath) == false)
                    {
                        Directory.CreateDirectory(docfilepath);
                    }
                    string path = Server.MapPath("~/HBC/HBCPPT/" + DBID + "/" + "Storage_Overview.xlsx");
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    File.WriteAllBytes(path, xp.GetAsByteArray());
                }
                #endregion
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        protected void LinkButtonWorkBook_Click(object sender, EventArgs e)
        {
            try
            {

                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                decimal SQLStandard = 0;
                decimal SQLEnterprise = 0;
                decimal WindowsStandard = 0;
                decimal WindowsDatacenter = 0;
                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                service.SaveBoomrang(WindowsDatacenter, WindowsStandard, SQLStandard, SQLEnterprise);
                CreateExcelFile();

            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        protected void LinkButtonPPT_Click(object sender, EventArgs e)
        {
            try
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                decimal SQLStandard = 0;
                decimal SQLEnterprise = 0;
                decimal WindowsStandard = 0;
                decimal WindowsDatacenter = 0;
                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                service.SaveBoomrang(WindowsDatacenter, WindowsStandard, SQLStandard, SQLEnterprise);
                CreateExcelFileForPPT();
                CreateHBCReport();
                DownloadPPT();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        protected void LinkButtonDataCollection_Click(object sender, EventArgs e)
        {
            try
            {
                WebClient req = new WebClient();
                HttpResponse response = HttpContext.Current.Response;
                response.Clear();
                response.ClearContent();
                response.ClearHeaders();
                response.Buffer = true;
                response.AddHeader("Content-Disposition", "attachment;filename=\"" + "Holistic_Business_Case_Data_Collection_Checklist.pdf");
                byte[] data = req.DownloadData(Server.MapPath("~/Download/Holistic_Business_Case_Data_Collection_Checklist.pdf"));
                response.BinaryWrite(data);
                response.End();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        protected void LinkButtonSampleReport_Click(object sender, EventArgs e)
        {
            try
            {
                WebClient req = new WebClient();
                HttpResponse response = HttpContext.Current.Response;
                response.Clear();
                response.ClearContent();
                response.ClearHeaders();
                response.Buffer = true;
                response.AddHeader("Content-Disposition", "attachment;filename=\"" + "Holistic_Business_Case_Final_Report_Sample.pptx");
                byte[] data = req.DownloadData(Server.MapPath("~/Download/Holistic_Business_Case_Final_Report_Sample.pptx"));
                response.BinaryWrite(data);
                response.End();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        protected void LinkButtonDBDetails_Click(object sender, EventArgs e)
        {
            try
            {
                CreateExcelFileDB();

            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        void CreateExcelFileDB()
        {
            try
            {

                #region DataTables
                DataTable DatabaseDetailsISV_sqlMI = new DataTable();
                DataTable DatabaseDetailsISV_sqlVM = new DataTable();
                DataTable DatabaseDetailsOracle = new DataTable();
                DataTable DatabaseDetailsWin = new DataTable();
                DataTable DatabaseDetailsAll = new DataTable();
                DataTable Device_Oracle_Database = new DataTable();
                #endregion

                using (ExcelPackage xp = new ExcelPackage())
                {
                    List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                    _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                    _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                    BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);
                    BoomRangReportService service1 = new BoomRangReportService(Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString()), _DBName, CurrencyMode, Region);

                    List<Proc_DataBaseDetailsResult> DatabaseDetailsISV_sqlMIList = service1.Proc_DataBaseDetails("ISV_sqlMI");
                    List<Proc_DataBaseDetailsResult> DatabaseDetailsISV_sqlVMList = service1.Proc_DataBaseDetails("ISV_sqlVM");
                    List<Proc_DataBaseDetailsResult> DatabaseDetailsOracleList = service1.Proc_DataBaseDetails("Oracle");
                    List<Proc_DataBaseDetailsResult> DatabaseDetailsWinList = service1.Proc_DataBaseDetails("Win");
                    List<Proc_DataBaseDetailsResult> DatabaseDetailsAllList = service1.Proc_DataBaseDetails("All");
                    List<Device_Oracle_DatabaseList> DeviceOracleDatabaseList = service.GetOracleDeviceDatabaseData();

                    if (DatabaseDetailsISV_sqlMIList != null && DatabaseDetailsISV_sqlMIList.Count > 0)
                    {
                        DatabaseDetailsISV_sqlMI = Proc_DataBaseDetailsResultDataTable(DatabaseDetailsISV_sqlMIList);
                    }
                    if (DatabaseDetailsISV_sqlVMList != null && DatabaseDetailsISV_sqlVMList.Count > 0)
                    {
                        DatabaseDetailsISV_sqlVM = Proc_DataBaseDetailsResultDataTable(DatabaseDetailsISV_sqlVMList);
                    }
                    if (DatabaseDetailsOracleList != null && DatabaseDetailsOracleList.Count > 0)
                    {
                        DatabaseDetailsOracle = Proc_DataBaseDetailsResultDataTable(DatabaseDetailsOracleList);
                    }
                    if (DatabaseDetailsWinList != null && DatabaseDetailsWinList.Count > 0)
                    {
                        DatabaseDetailsWin = Proc_DataBaseDetailsResultDataTable(DatabaseDetailsWinList);
                    }
                    if (DatabaseDetailsAllList != null && DatabaseDetailsAllList.Count > 0)
                    {
                        DatabaseDetailsAll = Proc_DataBaseDetailsResultDataTable(DatabaseDetailsAllList);
                    }
                    if (DeviceOracleDatabaseList != null && DeviceOracleDatabaseList.Count > 0)
                    {
                        Device_Oracle_Database = Device_Oracle_DatabaseListDataTable(DeviceOracleDatabaseList);
                    }

                    ExcelWorksheet ws;
                    bool isDataAvailable = false;
                    if (Device_Oracle_Database.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("Oracle Databases");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(Device_Oracle_Database, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, Device_Oracle_Database.Columns.Count, Device_Oracle_Database.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }
                    if (DatabaseDetailsISV_sqlMI.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("Custom SQL Databases");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(DatabaseDetailsISV_sqlMI, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, DatabaseDetailsISV_sqlMI.Columns.Count, DatabaseDetailsISV_sqlMI.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }
                    if (DatabaseDetailsISV_sqlVM.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("ISV SQL Databases");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(DatabaseDetailsISV_sqlVM, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, DatabaseDetailsISV_sqlVM.Columns.Count, DatabaseDetailsISV_sqlVM.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }
                    if (DatabaseDetailsOracle.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("SQL Databases on Oracle");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(DatabaseDetailsOracle, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, DatabaseDetailsOracle.Columns.Count, DatabaseDetailsOracle.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }
                    if (DatabaseDetailsWin.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("SQL Databases on Windows");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(DatabaseDetailsWin, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, DatabaseDetailsWin.Columns.Count, DatabaseDetailsWin.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }
                    if (DatabaseDetailsAll.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("Total Databases");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(DatabaseDetailsAll, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, DatabaseDetailsAll.Columns.Count, DatabaseDetailsAll.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }

                    if (!isDataAvailable) ws = xp.Workbook.Worksheets.Add("No SQL Databases");

                    Response.AddHeader("content-disposition", "attachment;filename=" + InventoryName + "_" + "HBCDatabaseDetails.xlsx");
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.BinaryWrite(xp.GetAsByteArray());
                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                                                                               //Response.End();
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        public DataTable Proc_DataBaseDetailsResultDataTable(List<Proc_DataBaseDetailsResult> Proc_DataBaseDetailsResult)
        {
            #region Datatable
            DataTable dt = new DataTable();
            dt.Columns.Add("Server Name", typeof(string));
            dt.Columns.Add("OSFamily", typeof(string));
            dt.Columns.Add("Edition", typeof(string));
            dt.Columns.Add("SQL Server Database Engine Instance Name", typeof(string));
            dt.Columns.Add("Sql Server Product Name", typeof(string));
            dt.Columns.Add("Database Name", typeof(string));
            dt.Columns.Add("Database Size (MB)", typeof(double));
            dt.Columns.Add("Data Files Size (MB)", typeof(double));
            dt.Columns.Add("Log Files Size (MB)", typeof(double));
            dt.Columns.Add("Log Files Used Size (MB)", typeof(double));
            dt.Columns.Add("Log Files Used Percentage (%)", typeof(double));
            dt.Columns.Add("SQL Connection Status", typeof(string));
            dt.Columns.Add("ID", typeof(int));

            #endregion
            foreach (var item in Proc_DataBaseDetailsResult)
            {
                dt.Rows.Add(
                    item.Server_Name,
                    item.OSFamily,
                    item.Edition,
                    item.SQL_Server_Database_Engine_Instance_Name,
                    item.SQL_Server_Product_Name,
                    item.Database_Name,
                    string.IsNullOrEmpty(item.Database_Size__MB_) ? 0 : Convert.ToDouble(item.Database_Size__MB_),
                    item.Data_Files_Size__MB_ ?? 0,
                    item.Log_Files_Size__MB_ ?? 0,
                    item.Log_Files_Used_Size__MB_ ?? 0,
                    item.Log_Files_Used_Percentage____ ?? 0,
                    string.IsNullOrEmpty(item.SQL_Connection_Status) ? "-" : item.SQL_Connection_Status,
                    item.ID
                    );
            }

            return dt;
        }
        public DataTable Device_Oracle_DatabaseListDataTable(List<Device_Oracle_DatabaseList> Device_Oracle_DatabaseList)
        {
            #region Datatable
            DataTable dt = new DataTable();
            dt.Columns.Add("Device State", typeof(string));
            dt.Columns.Add("Device Name", typeof(string));
            dt.Columns.Add("Operating System", typeof(string));
            dt.Columns.Add("Type", typeof(string));
            dt.Columns.Add("Platform", typeof(string));
            dt.Columns.Add("Current VM Cluster", typeof(string));
            dt.Columns.Add("Current VM Host", typeof(string));
            dt.Columns.Add("Database Name", typeof(string));
            dt.Columns.Add("State", typeof(string));
            dt.Columns.Add("Version", typeof(string));
            dt.Columns.Add("Tags", typeof(string));

            #endregion
            foreach (var item in Device_Oracle_DatabaseList)
            {
                dt.Rows.Add(
                    item.Device_State,
                    item.Device_Name,
                    item.Operating_System,
                    item.Type,
                    item.Platform,
                    item.Current_VM_Cluster,
                    item.Current_VM_Host,
                    item.Database_Name,
                    item.State,
                    item.Version,
                    item.Tags
                     );
            }

            return dt;
        }
        public static void ExcelDesignDB(ExcelWorksheet Slide, int sp_ColsCount, int sp_RowsCount, int Row, int Cols)
        {
            for (int i = 0; i < sp_ColsCount; i++)
            {
                Slide.Cells[Row, Cols + i].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                Slide.Cells[Row, Cols + i].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                Slide.Cells[Row, Cols + i].Style.Fill.BackgroundColor.SetColor(Color.LightGreen);
                Slide.Cells[Row, Cols + i].Style.Font.Color.SetColor(Color.Black);
                Slide.Cells[Row, Cols + i].Style.Font.Bold = true;
            }
            for (int i = 0; i <= sp_RowsCount; i++)
            {
                for (int j = 0; j < sp_ColsCount; j++)
                {
                    Slide.Cells[Row + i, Cols + j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                }
            }
        }

        //New HBC Format
        protected void GenerateHBCWorkbook(object sender, EventArgs e)
        {
            try
            {
                CreateNewHBCFormatExcelFile();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        void CreateNewHBCFormatExcelFile()
        {
            try
            {
                using (DataSet ds = GetNewHBCFormatExcelData())
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        #region DataTables
                        DataTable Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryWindowsServer_DBCount = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount = new DataTable();
                        DataTable Proc_EnvironmentDiscoveryLinuxServer_DBCount = new DataTable();
                        DataTable Proc_ISVApplications_WindowsBasedSummary = new DataTable();
                        DataTable Proc_ISVApplications_WindowsBasedVendorList = new DataTable();
                        DataTable Proc_ISVApplications_WindowsBasedApplicationVendorCountList = new DataTable();
                        DataTable Proc_ISVApplications_LinuxBasedSummary = new DataTable();
                        DataTable Proc_ISVApplications_LinuxBasedVendorList = new DataTable();
                        DataTable Proc_ISVApplications_LinuxBasedApplicationVendorCountList = new DataTable();
                        DataTable Proc_InfrastructureOptimization = new DataTable();
                        DataTable Proc_RightSizedIaaSEnvironment = new DataTable();
                        DataTable Proc_WindowsServerOverview_Summary = new DataTable();
                        DataTable Proc_WindowsServerOverview_WindowsEditionCount = new DataTable();
                        DataTable Proc_WindowsServerOverview_NetstatData = new DataTable();
                        DataTable Proc_SQLServerOverview_Summary = new DataTable();
                        DataTable Proc_SQLServerOverview_WindowsEditionCount = new DataTable();
                        DataTable Proc_SQLServerOverview_SQLEditionCount = new DataTable();
                        DataTable Proc_SQLServerOverview_NetstatData = new DataTable();
                        DataTable Proc_LinuxServerOverview_Summary = new DataTable();
                        DataTable Proc_LinuxServerOverview_LinuxEditionCount = new DataTable();
                        DataTable Proc_LinuxServerOverview_NetstatData = new DataTable();
                        DataTable Proc_AzureBackupAndDR_WindowsServer = new DataTable();
                        DataTable Proc_AzureBackupAndDR_SQLServer = new DataTable();
                        DataTable Proc_AzureBackupAndDR_LinuxServer = new DataTable();
                        DataTable Proc_StorageCostOverview_Summary = new DataTable();
                        DataTable Proc_StorageCostOverview_WindowsServer = new DataTable();
                        DataTable Proc_StorageCostOverview_SQLServer = new DataTable();
                        DataTable Proc_StorageCostOverview_LinuxServer = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWindowsAppServers_Summary = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing = new DataTable();
                        DataTable Proc_CustomBuildApplicationsSQLDatabases_Summary = new DataTable();
                        DataTable Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing = new DataTable();
                        DataTable Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing = new DataTable();
                        DataTable Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary = new DataTable();
                        DataTable Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing = new DataTable();
                        DataTable Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWithSQLDatabases_Summary = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer = new DataTable();
                        DataTable Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase = new DataTable();
                        DataTable Proc_WindowsApplicationServersForISVApps_Summary = new DataTable();
                        DataTable Proc_WindowsApplicationServersForISVApps_AsIsPricing = new DataTable();
                        DataTable Proc_WindowsApplicationServersForISVApps_RightSizedPricing = new DataTable();
                        DataTable Proc_ISVApplicationsWithSQLDatabases_Summary = new DataTable();
                        DataTable Proc_ISVApplicationsWithSQLDatabases_AsIsPricing = new DataTable();
                        DataTable Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing = new DataTable();
                        DataTable Proc_ISVApplicationsWithSQLDatabases_ISVSummary = new DataTable();
                        DataTable Proc_ISVApplicationsWithSQLDatabases_ApplicationServer = new DataTable();
                        DataTable Proc_ISVApplicationsWithSQLDatabases_SQLServer = new DataTable();
                        DataTable Proc_SQLAnalytical_WorkloadCount = new DataTable();
                        DataTable Proc_SQLAnalytical_Summary = new DataTable();
                        DataTable Proc_SQLAnalytical_ComponentVMPrice = new DataTable();
                        DataTable Proc_SustainabilityReport_Summary = new DataTable();
                        DataTable Proc_SustainabilityReport_CarbonEmissionByVMType = new DataTable();
                        DataTable Proc_SustainabilityReport_CarbonEmissionByScope = new DataTable();
                        DataTable Proc_SustainabilityReport_CarbonReduction = new DataTable();
                        //DataTable Proc_SustainabilityReport_CarbonFootprintLow = new DataTable();
                        DataTable Proc_SustainabilityReport_CarbonFootprintMedium = new DataTable();
                        //DataTable Proc_SustainabilityReport_CarbonFootprintHigh = new DataTable();
                        DataTable Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense = new DataTable();
                        DataTable Proc_SQLServerCoreAndCostCalculations_SQLServerLicense = new DataTable();
                        DataTable Proc_SQLServerCoreAndCostCalculations_DatabaseCost = new DataTable();
                        DataTable Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense = new DataTable();
                        DataTable Proc_WindowsServerCoreAndCostCalculation_WindowsCost = new DataTable();
                        #endregion
                        foreach (DataTable dt in ds.Tables)
                        {
                            if (dt.TableName == "Slide 4_1")
                            {
                                Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 4_2")
                            {
                                Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 4_3")
                            {
                                Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 4_4")
                            {
                                Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 4_5")
                            {
                                Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 4_6")
                            {
                                Proc_EnvironmentDiscoveryWindowsServer_DBCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_1")
                            {
                                Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_2")
                            {
                                Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_3")
                            {
                                Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 5_4")
                            {
                                Proc_EnvironmentDiscoveryLinuxServer_DBCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 6_1")
                            {
                                Proc_ISVApplications_WindowsBasedSummary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 6_2")
                            {
                                Proc_ISVApplications_WindowsBasedVendorList = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 6_3")
                            {
                                Proc_ISVApplications_WindowsBasedApplicationVendorCountList = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_1")
                            {
                                Proc_ISVApplications_LinuxBasedSummary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_2")
                            {
                                Proc_ISVApplications_LinuxBasedVendorList = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 7_3")
                            {
                                Proc_ISVApplications_LinuxBasedApplicationVendorCountList = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 11")
                            {
                                Proc_InfrastructureOptimization = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 12")
                            {
                                Proc_RightSizedIaaSEnvironment = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 13_1")
                            {
                                Proc_WindowsServerOverview_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 13_2")
                            {
                                Proc_WindowsServerOverview_WindowsEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 13_3")
                            {
                                Proc_WindowsServerOverview_NetstatData = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 14_1")
                            {
                                Proc_SQLServerOverview_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 14_2")
                            {
                                Proc_SQLServerOverview_WindowsEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 14_3")
                            {
                                Proc_SQLServerOverview_SQLEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 14_4")
                            {
                                Proc_SQLServerOverview_NetstatData = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 15_1")
                            {
                                Proc_LinuxServerOverview_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 15_2")
                            {
                                Proc_LinuxServerOverview_LinuxEditionCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 15_3")
                            {
                                Proc_LinuxServerOverview_NetstatData = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 16_1")
                            {
                                Proc_AzureBackupAndDR_WindowsServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 16_2")
                            {
                                Proc_AzureBackupAndDR_SQLServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 16_3")
                            {
                                Proc_AzureBackupAndDR_LinuxServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 17_1")
                            {
                                Proc_StorageCostOverview_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 17_2")
                            {
                                Proc_StorageCostOverview_WindowsServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 17_3")
                            {
                                Proc_StorageCostOverview_SQLServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 17_4")
                            {
                                Proc_StorageCostOverview_LinuxServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 23_1")
                            {
                                Proc_CustomBuildApplicationsWindowsAppServers_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 23_2")
                            {
                                Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 23_3")
                            {
                                Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 24_1")
                            {
                                Proc_CustomBuildApplicationsSQLDatabases_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 24_2")
                            {
                                Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 24_3")
                            {
                                Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_1")
                            {
                                Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_2")
                            {
                                Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 25_3")
                            {
                                Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 28_1")
                            {
                                Proc_CustomBuildApplicationsWithSQLDatabases_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 28_2")
                            {
                                Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 28_3")
                            {
                                Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 28_4")
                            {
                                Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 30_1")
                            {
                                Proc_WindowsApplicationServersForISVApps_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 30_2")
                            {
                                Proc_WindowsApplicationServersForISVApps_AsIsPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 30_3")
                            {
                                Proc_WindowsApplicationServersForISVApps_RightSizedPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 31_1")
                            {
                                Proc_ISVApplicationsWithSQLDatabases_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 31_2")
                            {
                                Proc_ISVApplicationsWithSQLDatabases_AsIsPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 31_3")
                            {
                                Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 32_1")
                            {
                                Proc_ISVApplicationsWithSQLDatabases_ISVSummary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 32_2")
                            {
                                Proc_ISVApplicationsWithSQLDatabases_ApplicationServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 32_3")
                            {
                                Proc_ISVApplicationsWithSQLDatabases_SQLServer = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 34_1")
                            {
                                Proc_SQLAnalytical_WorkloadCount = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 34_2")
                            {
                                Proc_SQLAnalytical_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 34_3")
                            {
                                Proc_SQLAnalytical_ComponentVMPrice = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 43_1")
                            {
                                Proc_SustainabilityReport_Summary = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 43_2")
                            {
                                Proc_SustainabilityReport_CarbonEmissionByVMType = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 43_3")
                            {
                                Proc_SustainabilityReport_CarbonEmissionByScope = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 43_4")
                            {
                                Proc_SustainabilityReport_CarbonReduction = dt.Copy();
                            }
                            //else if (dt.TableName == "Slide 44_1")
                            //{
                            //    Proc_SustainabilityReport_CarbonFootprintLow = dt.Copy();
                            //}
                            else if (dt.TableName == "Slide 44_2")
                            {
                                Proc_SustainabilityReport_CarbonFootprintMedium = dt.Copy();
                            }
                            //else if (dt.TableName == "Slide 44_3")
                            //{
                            //    Proc_SustainabilityReport_CarbonFootprintHigh = dt.Copy();
                            //}
                            else if (dt.TableName == "Slide 61_1")
                            {
                                Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 61_2")
                            {
                                Proc_SQLServerCoreAndCostCalculations_SQLServerLicense = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 61_3")
                            {
                                Proc_SQLServerCoreAndCostCalculations_DatabaseCost = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 62_1")
                            {
                                Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense = dt.Copy();
                            }
                            else if (dt.TableName == "Slide 62_2")
                            {
                                Proc_WindowsServerCoreAndCostCalculation_WindowsCost = dt.Copy();
                            }
                        }
                        using (ExcelPackage xp = new ExcelPackage())
                        {
                            ExcelWorksheet ws = xp.Workbook.Worksheets.Add("Slide 4");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary.Columns.Count, Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary.Rows.Count, 3, 1);
                            }
                            if (Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[13, 1].LoadFromDataTable(Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount.Columns.Count, Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount.Rows.Count, 13, 1);
                            }
                            if (Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary.Rows.Count != 0)
                            {
                                ws.Cells[3, 4].LoadFromDataTable(Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary.Columns.Count, Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary.Rows.Count, 3, 4);
                            }
                            if (Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[13, 4].LoadFromDataTable(Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount.Columns.Count, Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount.Rows.Count, 13, 4);
                            }
                            if (Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount.Rows.Count != 0)
                            {
                                ws.Cells[3, 7].LoadFromDataTable(Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount.Columns.Count, Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount.Rows.Count, 3, 7);
                            }
                            if (Proc_EnvironmentDiscoveryWindowsServer_DBCount.Rows.Count != 0)
                            {
                                ws.Cells[13, 7].LoadFromDataTable(Proc_EnvironmentDiscoveryWindowsServer_DBCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryWindowsServer_DBCount.Columns.Count, Proc_EnvironmentDiscoveryWindowsServer_DBCount.Rows.Count, 13, 7);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide4", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide4.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 5");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary.Rows.Count != 0)
                            {
                                ws.Cells[3, 1].LoadFromDataTable(Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary.Columns.Count, Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary.Rows.Count, 3, 1);
                            }
                            if (Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[13, 1].LoadFromDataTable(Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount.Columns.Count, Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount.Rows.Count, 13, 1);
                            }
                            if (Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount.Rows.Count != 0)
                            {
                                ws.Cells[3, 4].LoadFromDataTable(Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount.Columns.Count, Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount.Rows.Count, 3, 4);
                            }
                            if (Proc_EnvironmentDiscoveryLinuxServer_DBCount.Rows.Count != 0)
                            {
                                ws.Cells[13, 4].LoadFromDataTable(Proc_EnvironmentDiscoveryLinuxServer_DBCount, true);
                                ExcelDesign(ws, Proc_EnvironmentDiscoveryLinuxServer_DBCount.Columns.Count, Proc_EnvironmentDiscoveryLinuxServer_DBCount.Rows.Count, 13, 4);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide5", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide5.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 6");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_ISVApplications_WindowsBasedSummary.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_ISVApplications_WindowsBasedSummary, true);
                                ExcelDesign(ws, Proc_ISVApplications_WindowsBasedSummary.Columns.Count, Proc_ISVApplications_WindowsBasedSummary.Rows.Count, 4, 1);
                            }
                            if (Proc_ISVApplications_WindowsBasedVendorList.Rows.Count != 0)
                            {
                                ws.Cells[4, 4].LoadFromDataTable(Proc_ISVApplications_WindowsBasedVendorList, true);
                                ExcelDesign(ws, Proc_ISVApplications_WindowsBasedVendorList.Columns.Count, Proc_ISVApplications_WindowsBasedVendorList.Rows.Count, 4, 4);
                            }
                            if (Proc_ISVApplications_WindowsBasedApplicationVendorCountList.Rows.Count != 0)
                            {
                                ws.Cells[4, 6].LoadFromDataTable(Proc_ISVApplications_WindowsBasedApplicationVendorCountList, true);
                                ExcelDesign(ws, Proc_ISVApplications_WindowsBasedApplicationVendorCountList.Columns.Count, Proc_ISVApplications_WindowsBasedApplicationVendorCountList.Rows.Count, 4, 6);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            //ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide6", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide6.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 7");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_ISVApplications_LinuxBasedSummary.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_ISVApplications_LinuxBasedSummary, true);
                                ExcelDesign(ws, Proc_ISVApplications_LinuxBasedSummary.Columns.Count, Proc_ISVApplications_LinuxBasedSummary.Rows.Count, 4, 1);
                            }
                            if (Proc_ISVApplications_LinuxBasedVendorList.Rows.Count != 0)
                            {
                                ws.Cells[4, 4].LoadFromDataTable(Proc_ISVApplications_LinuxBasedVendorList, true);
                                ExcelDesign(ws, Proc_ISVApplications_LinuxBasedVendorList.Columns.Count, Proc_ISVApplications_LinuxBasedVendorList.Rows.Count, 4, 4);
                            }
                            if (Proc_ISVApplications_LinuxBasedApplicationVendorCountList.Rows.Count != 0)
                            {
                                ws.Cells[4, 6].LoadFromDataTable(Proc_ISVApplications_LinuxBasedApplicationVendorCountList, true);
                                ExcelDesign(ws, Proc_ISVApplications_LinuxBasedApplicationVendorCountList.Columns.Count, Proc_ISVApplications_LinuxBasedApplicationVendorCountList.Rows.Count, 4, 6);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            //ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide7", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide7.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 11");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[3, 1, 3, 2].Merge = true;
                            ws.Cells[3, 1, 3, 2].Value = "At a Glance (details on next slide)";
                            ws.Cells[3, 1, 3, 2].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[3, 1, 3, 2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[3, 1, 3, 2].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[3, 1, 3, 2].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[3, 1, 3, 2].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            if (Proc_InfrastructureOptimization.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_InfrastructureOptimization, true);
                                ExcelDesign(ws, Proc_InfrastructureOptimization.Columns.Count, Proc_InfrastructureOptimization.Rows.Count, 4, 1);
                                CurrencyFormatDesign(ws, Proc_InfrastructureOptimization.Columns.Count, Proc_InfrastructureOptimization.Rows.Count, 5, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide11", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide11.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 12");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_RightSizedIaaSEnvironment.Rows.Count != 0)
                            {
                                ws.Cells[16, 1].LoadFromDataTable(Proc_RightSizedIaaSEnvironment, true);
                                ExcelDesign(ws, Proc_RightSizedIaaSEnvironment.Columns.Count, Proc_RightSizedIaaSEnvironment.Rows.Count, 16, 1);
                                CurrencyFormatDesign(ws, Proc_RightSizedIaaSEnvironment.Columns.Count, Proc_RightSizedIaaSEnvironment.Rows.Count, 17, 3);
                            }

                            ws.Cells[2, 1].Value = "Azure_Service"; ws.Cells[2, 2].Value = "Quantity"; ws.Cells[2, 3].Value = "ASIS_PAYG"; ws.Cells[2, 4].Value = "ASIS_3Y_RI_AHUB";
                            ws.Cells[2, 5].Value = "RS_PAYG"; ws.Cells[2, 6].Value = "RS_PAYG_AHUB"; ws.Cells[2, 7].Value = "RS_1Y_RI_AHUB"; ws.Cells[2, 8].Value = "RS_3Y_RI_AHUB";

                            ws.Cells[3, 1].Value = "Windows Servers"; ws.Cells[3, 2].Formula = "=B17"; ws.Cells[3, 3].Formula = "=C17"; ws.Cells[3, 4].Formula = "=D17";
                            ws.Cells[3, 5].Formula = "=E17"; ws.Cells[3, 6].Formula = "=F17"; ws.Cells[3, 7].Formula = "=G17"; ws.Cells[3, 8].Formula = "=H17";

                            ws.Cells[4, 1].Value = "Linux Servers"; ws.Cells[4, 2].Formula = "=B18"; ws.Cells[4, 3].Formula = "=C18"; ws.Cells[4, 4].Formula = "=D18";
                            ws.Cells[4, 5].Formula = "=E18"; ws.Cells[4, 6].Formula = "=F18"; ws.Cells[4, 7].Formula = "=G18"; ws.Cells[4, 8].Formula = "=H18";

                            ws.Cells[5, 1].Value = "SQL Servers"; ws.Cells[5, 2].Formula = "=B19"; ws.Cells[5, 3].Formula = "=C19"; ws.Cells[5, 4].Formula = "=D19";
                            ws.Cells[5, 5].Formula = "=E19"; ws.Cells[5, 6].Formula = "=F19"; ws.Cells[5, 7].Formula = "=G19"; ws.Cells[5, 8].Formula = "=H19";

                            ws.Cells[6, 1].Value = "Storage (TB)"; ws.Cells[6, 2].Formula = "=SUM(B20:B22)"; ws.Cells[6, 3].Formula = "=SUM(C20:C22)"; ws.Cells[6, 4].Formula = "=SUM(D20:D22)";
                            ws.Cells[6, 5].Formula = "=SUM(E20:E22)"; ws.Cells[6, 6].Formula = "=SUM(F20:F22)"; ws.Cells[6, 7].Formula = "=SUM(G20:G22)"; ws.Cells[6, 8].Formula = "=SUM(H20:H22)";
                            ExcelDesign(ws, 8, 4, 2, 1);
                            CurrencyFormatDesign(ws, 8, 4, 3, 3);

                            ws.Cells[9, 1].Value = "Landing Zone"; ws.Cells[9, 1].Style.Font.Bold = true; ws.Cells[9, 2].Formula = "=SUM(E3:E6)*0.15";
                            ws.Cells[10, 1].Value = "Azure Backup"; ws.Cells[10, 1].Style.Font.Bold = true; ws.Cells[10, 2].Formula = "=SUM('Slide 16'!B7:B8)+SUM('Slide 16'!E7:E8)+SUM('Slide 16'!H7:H8)";
                            ws.Cells[11, 1].Value = "DR Azure Site Recovery"; ws.Cells[11, 1].Style.Font.Bold = true; ws.Cells[11, 2].Formula = "=SUM('Slide 16'!B9:B10)+SUM('Slide 16'!E9:E10)+SUM('Slide 16'!H9:H10)";
                            for (int i = 9; i <= 11; i++)
                            {
                                for (int j = 1; j <= 2; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            CurrencyFormatDesign(ws, 1, 3, 9, 2);

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 13, 2, 20].Merge = true;
                            ws.Cells[1, 13, 2, 20].Value = "Reference Slide";
                            ws.Cells[1, 13, 2, 20].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 13, 2, 20].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide12", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide12.png"))).SetPosition(2, 0, 10, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 13");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 1].Value = "Windows Machines:";
                            ws.Cells[2, 1].Style.Font.Bold = true;
                            ws.Cells[2, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 1].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 1].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[2, 2].Formula = "=B5+B6";
                            ws.Cells[2, 2].Style.Font.Bold = true;
                            ws.Cells[2, 2].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 2].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 2].Style.Font.Color.SetColor(Color.White);
                            for (int i = 3; i <= 10; i++)
                            {
                                ws.Cells[2, i].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            }
                            if (Proc_WindowsServerOverview_Summary.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_WindowsServerOverview_Summary, true);
                                ExcelDesign(ws, Proc_WindowsServerOverview_Summary.Columns.Count, Proc_WindowsServerOverview_Summary.Rows.Count, 4, 1);
                            }
                            if (Proc_WindowsServerOverview_WindowsEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[16, 1].LoadFromDataTable(Proc_WindowsServerOverview_WindowsEditionCount, true);
                                ExcelDesign(ws, Proc_WindowsServerOverview_WindowsEditionCount.Columns.Count, Proc_WindowsServerOverview_WindowsEditionCount.Rows.Count, 16, 1);
                            }
                            if (Proc_WindowsServerOverview_NetstatData.Rows.Count != 0)
                            {
                                ws.Cells[4, 4].LoadFromDataTable(Proc_WindowsServerOverview_NetstatData, true);
                                ExcelDesign(ws, Proc_WindowsServerOverview_NetstatData.Columns.Count, Proc_WindowsServerOverview_NetstatData.Rows.Count, 4, 4);
                            }

                            ws.Cells[4, 8, 4, 9].Merge = true;
                            ws.Cells[4, 8, 4, 9].Value = "Annual Cost";
                            ws.Cells[4, 8, 4, 9].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[4, 8, 4, 9].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[4, 8, 4, 9].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[4, 8, 4, 9].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[4, 8, 4, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[5, 8, 5, 9].Merge = true;
                            ws.Cells[5, 8, 5, 9].Value = "(Compute + Storage)";
                            ws.Cells[5, 8, 5, 9].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[5, 8, 5, 9].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[5, 8, 5, 9].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[5, 8, 5, 9].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[5, 8, 5, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);

                            ws.Cells[6, 8].Value = "As-Is Config"; ws.Cells[6, 9].Value = "PAY G";
                            ws.Cells[6, 8].Style.Font.Bold = true; ws.Cells[6, 9].Style.Font.Bold = true;
                            ws.Cells[7, 8].Formula = "='Slide 12'!C17+'Slide 12'!C19+'Slide 12'!C20+'Slide 12'!C21"; ws.Cells[7, 9].Formula = "='Slide 12'!E17+'Slide 12'!E19+'Slide 12'!E20+'Slide 12'!E21";
                            ws.Cells[7, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[7, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[8, 8].Value = "Savings is "; ws.Cells[8, 9].Formula = "=(H7-I7)/H7*100"; ws.Cells[8, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[8, 9].Style.Font.Bold = true;
                            for (int i = 6; i <= 8; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[10, 8].Value = "PAY G"; ws.Cells[10, 9].Value = "PAY G AHB";
                            ws.Cells[10, 8].Style.Font.Bold = true; ws.Cells[10, 9].Style.Font.Bold = true;
                            ws.Cells[11, 8].Formula = "='Slide 12'!E17+'Slide 12'!E19+'Slide 12'!E20+'Slide 12'!E21"; ws.Cells[11, 9].Formula = "='Slide 12'!F17+'Slide 12'!F19+'Slide 12'!F20+'Slide 12'!F21";
                            ws.Cells[11, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[11, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[12, 8].Value = "Savings is "; ws.Cells[12, 9].Formula = "=(H11-I11)/H11*100"; ws.Cells[12, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[12, 9].Style.Font.Bold = true;
                            for (int i = 10; i <= 12; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[14, 8].Value = "PAY G AHB"; ws.Cells[14, 9].Value = "1 Y RI AHB";
                            ws.Cells[14, 8].Style.Font.Bold = true; ws.Cells[14, 9].Style.Font.Bold = true;
                            ws.Cells[15, 8].Formula = "='Slide 12'!F17+'Slide 12'!F19+'Slide 12'!F20+'Slide 12'!F21"; ws.Cells[15, 9].Formula = "='Slide 12'!G17+'Slide 12'!G19+'Slide 12'!G20+'Slide 12'!G21";
                            ws.Cells[15, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[15, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[16, 8].Value = "Savings is "; ws.Cells[16, 9].Formula = "=(H15-I15)/H15*100"; ws.Cells[16, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[16, 9].Style.Font.Bold = true;
                            for (int i = 14; i <= 16; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[18, 8].Value = "1 Y RI AHB"; ws.Cells[18, 9].Value = "3 Y RI AHB";
                            ws.Cells[18, 8].Style.Font.Bold = true; ws.Cells[18, 9].Style.Font.Bold = true;
                            ws.Cells[19, 8].Formula = "='Slide 12'!G17+'Slide 12'!G19+'Slide 12'!G20+'Slide 12'!G21"; ws.Cells[19, 9].Formula = "='Slide 12'!H17+'Slide 12'!H19+'Slide 12'!H20+'Slide 12'!H21";
                            ws.Cells[19, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[19, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[20, 8].Value = "Savings is "; ws.Cells[20, 9].Formula = "=(H19-I19)/H19*100"; ws.Cells[20, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[20, 9].Style.Font.Bold = true;
                            ws.Cells[18, 8, 20, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            for (int i = 18; i <= 20; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide13", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide13.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 14");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 1].Value = "SQL Machines:";
                            ws.Cells[2, 1].Style.Font.Bold = true;
                            ws.Cells[2, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 1].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 1].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[2, 2].Formula = "='Slide 13'!B6";
                            ws.Cells[2, 2].Style.Font.Bold = true;
                            ws.Cells[2, 2].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 2].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 2].Style.Font.Color.SetColor(Color.White);
                            for (int i = 3; i <= 10; i++)
                            {
                                ws.Cells[2, i].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            }
                            if (Proc_SQLServerOverview_Summary.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_SQLServerOverview_Summary, true);
                                ExcelDesign(ws, Proc_SQLServerOverview_Summary.Columns.Count, Proc_SQLServerOverview_Summary.Rows.Count, 4, 1);
                            }
                            if (Proc_SQLServerOverview_WindowsEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[17, 1].LoadFromDataTable(Proc_SQLServerOverview_WindowsEditionCount, true);
                                ExcelDesign(ws, Proc_SQLServerOverview_WindowsEditionCount.Columns.Count, Proc_SQLServerOverview_WindowsEditionCount.Rows.Count, 17, 1);
                            }
                            if (Proc_SQLServerOverview_SQLEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[17, 4].LoadFromDataTable(Proc_SQLServerOverview_SQLEditionCount, true);
                                ExcelDesign(ws, Proc_SQLServerOverview_SQLEditionCount.Columns.Count, Proc_SQLServerOverview_SQLEditionCount.Rows.Count, 17, 4);
                            }
                            if (Proc_SQLServerOverview_NetstatData.Rows.Count != 0)
                            {
                                ws.Cells[4, 4].LoadFromDataTable(Proc_SQLServerOverview_NetstatData, true);
                                ExcelDesign(ws, Proc_SQLServerOverview_NetstatData.Columns.Count, Proc_SQLServerOverview_NetstatData.Rows.Count, 4, 4);
                            }

                            ws.Cells[4, 8, 4, 9].Merge = true;
                            ws.Cells[4, 8, 4, 9].Value = "Annual Cost";
                            ws.Cells[4, 8, 4, 9].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[4, 8, 4, 9].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[4, 8, 4, 9].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[4, 8, 4, 9].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[4, 8, 4, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[5, 8, 5, 9].Merge = true;
                            ws.Cells[5, 8, 5, 9].Value = "(Compute + Storage)";
                            ws.Cells[5, 8, 5, 9].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[5, 8, 5, 9].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[5, 8, 5, 9].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[5, 8, 5, 9].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[5, 8, 5, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[6, 8].Value = "As-Is Config"; ws.Cells[6, 9].Value = "PAY G";
                            ws.Cells[6, 8].Style.Font.Bold = true; ws.Cells[6, 9].Style.Font.Bold = true;
                            ws.Cells[7, 8].Formula = "='Slide 12'!C19+'Slide 12'!C21"; ws.Cells[7, 9].Formula = "='Slide 12'!E19+'Slide 12'!E21";
                            ws.Cells[7, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[7, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[8, 8].Value = "Savings is "; ws.Cells[8, 9].Formula = "=(H7-I7)/H7*100"; ws.Cells[8, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[8, 9].Style.Font.Bold = true;
                            for (int i = 6; i <= 8; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[10, 8].Value = "PAY G"; ws.Cells[10, 9].Value = "PAY G AHB";
                            ws.Cells[10, 8].Style.Font.Bold = true; ws.Cells[10, 9].Style.Font.Bold = true;
                            ws.Cells[11, 8].Formula = "='Slide 12'!E19+'Slide 12'!E21"; ws.Cells[11, 9].Formula = "='Slide 12'!F19+'Slide 12'!F21";
                            ws.Cells[11, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[11, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[12, 8].Value = "Savings is "; ws.Cells[12, 9].Formula = "=(H11-I11)/H11*100"; ws.Cells[12, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[12, 9].Style.Font.Bold = true;
                            for (int i = 10; i <= 12; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[14, 8].Value = "PAY G AHB"; ws.Cells[14, 9].Value = "1 Y RI AHB";
                            ws.Cells[14, 8].Style.Font.Bold = true; ws.Cells[14, 9].Style.Font.Bold = true;
                            ws.Cells[15, 8].Formula = "='Slide 12'!F19+'Slide 12'!F21"; ws.Cells[15, 9].Formula = "='Slide 12'!G19+'Slide 12'!G21";
                            ws.Cells[15, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[15, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[16, 8].Value = "Savings is "; ws.Cells[16, 9].Formula = "=(H15-I15)/H15*100"; ws.Cells[16, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[16, 9].Style.Font.Bold = true;
                            for (int i = 14; i <= 16; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[18, 8].Value = "1 Y RI AHB"; ws.Cells[18, 9].Value = "3 Y RI AHB";
                            ws.Cells[18, 8].Style.Font.Bold = true; ws.Cells[18, 9].Style.Font.Bold = true;
                            ws.Cells[19, 8].Formula = "='Slide 12'!G19+'Slide 12'!G21"; ws.Cells[19, 9].Formula = "='Slide 12'!H19+'Slide 12'!H21";
                            ws.Cells[19, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[19, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[20, 8].Value = "Savings is "; ws.Cells[20, 9].Formula = "=(H19-I19)/H19*100"; ws.Cells[20, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[20, 9].Style.Font.Bold = true;
                            for (int i = 18; i <= 20; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide14", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide14.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 15");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 1].Value = "Linux Machines:";
                            ws.Cells[2, 1].Style.Font.Bold = true;
                            ws.Cells[2, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 1].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 1].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[2, 2].Formula = "=B5";
                            ws.Cells[2, 2].Style.Font.Bold = true;
                            ws.Cells[2, 2].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 2].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 2].Style.Font.Color.SetColor(Color.White);
                            for (int i = 3; i <= 10; i++)
                            {
                                ws.Cells[2, i].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            }
                            if (Proc_LinuxServerOverview_Summary.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_LinuxServerOverview_Summary, true);
                                ExcelDesign(ws, Proc_LinuxServerOverview_Summary.Columns.Count, Proc_LinuxServerOverview_Summary.Rows.Count, 4, 1);
                            }
                            if (Proc_LinuxServerOverview_LinuxEditionCount.Rows.Count != 0)
                            {
                                ws.Cells[16, 1].LoadFromDataTable(Proc_LinuxServerOverview_LinuxEditionCount, true);
                                ExcelDesign(ws, Proc_LinuxServerOverview_LinuxEditionCount.Columns.Count, Proc_LinuxServerOverview_LinuxEditionCount.Rows.Count, 16, 1);
                            }
                            if (Proc_LinuxServerOverview_NetstatData.Rows.Count != 0)
                            {
                                ws.Cells[4, 4].LoadFromDataTable(Proc_LinuxServerOverview_NetstatData, true);
                                ExcelDesign(ws, Proc_LinuxServerOverview_NetstatData.Columns.Count, Proc_LinuxServerOverview_NetstatData.Rows.Count, 4, 4);
                            }

                            ws.Cells[4, 8, 4, 9].Merge = true;
                            ws.Cells[4, 8, 4, 9].Value = "Annual Cost";
                            ws.Cells[4, 8, 4, 9].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[4, 8, 4, 9].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[4, 8, 4, 9].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[4, 8, 4, 9].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[4, 8, 4, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[5, 8, 5, 9].Merge = true;
                            ws.Cells[5, 8, 5, 9].Value = "(Compute + Storage)";
                            ws.Cells[5, 8, 5, 9].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[5, 8, 5, 9].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[5, 8, 5, 9].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[5, 8, 5, 9].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[5, 8, 5, 9].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[6, 8].Value = "As-Is Config"; ws.Cells[6, 9].Value = "PAY G";
                            ws.Cells[6, 8].Style.Font.Bold = true; ws.Cells[6, 9].Style.Font.Bold = true;
                            ws.Cells[7, 8].Formula = "='Slide 12'!C18+'Slide 12'!C22"; ws.Cells[7, 9].Formula = "='Slide 12'!E18+'Slide 12'!E22";
                            ws.Cells[7, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[7, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[8, 8].Value = "Savings is "; ws.Cells[8, 9].Formula = "=(H7-I7)/H7*100"; ws.Cells[8, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[8, 9].Style.Font.Bold = true;
                            for (int i = 6; i <= 8; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[10, 8].Value = "PAY G"; ws.Cells[10, 9].Value = "PAY G AHB";
                            ws.Cells[10, 8].Style.Font.Bold = true; ws.Cells[10, 9].Style.Font.Bold = true;
                            ws.Cells[11, 8].Formula = "='Slide 12'!E18+'Slide 12'!E22"; ws.Cells[11, 9].Formula = "='Slide 12'!F18+'Slide 12'!F22";
                            ws.Cells[11, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[11, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[12, 8].Value = "Savings is "; ws.Cells[12, 9].Formula = "=(H11-I11)/H11*100"; ws.Cells[12, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[12, 9].Style.Font.Bold = true;
                            for (int i = 10; i <= 12; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[14, 8].Value = "PAY G AHB"; ws.Cells[14, 9].Value = "1 Y RI AHB";
                            ws.Cells[14, 8].Style.Font.Bold = true; ws.Cells[14, 9].Style.Font.Bold = true;
                            ws.Cells[15, 8].Formula = "='Slide 12'!F18+'Slide 12'!F22"; ws.Cells[15, 9].Formula = "='Slide 12'!G18+'Slide 12'!G22";
                            ws.Cells[15, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[15, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[16, 8].Value = "Savings is "; ws.Cells[16, 9].Formula = "=(H15-I15)/H15*100"; ws.Cells[16, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[16, 9].Style.Font.Bold = true;
                            for (int i = 14; i <= 16; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }
                            ws.Cells[18, 8].Value = "1 Y RI AHB"; ws.Cells[18, 9].Value = "3 Y RI AHB";
                            ws.Cells[18, 8].Style.Font.Bold = true; ws.Cells[18, 9].Style.Font.Bold = true;
                            ws.Cells[19, 8].Formula = "='Slide 12'!G18+'Slide 12'!G22"; ws.Cells[19, 9].Formula = "='Slide 12'!H18+'Slide 12'!H22";
                            ws.Cells[19, 8].Style.Numberformat.Format = CurrencyFormat; ws.Cells[19, 9].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[20, 8].Value = "Savings is "; ws.Cells[20, 9].Formula = "=(H19-I19)/H19*100"; ws.Cells[20, 9].Style.Numberformat.Format = "#0\\.00%"; ws.Cells[20, 9].Style.Font.Bold = true;
                            for (int i = 18; i <= 20; i++)
                            {
                                for (int j = 8; j <= 9; j++)
                                {
                                    ws.Cells[i, j].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                }
                            }

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide15", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide15.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 16");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 1].Value = "Azure Back Up & Disaster Recovery";
                            ws.Cells[2, 1].Style.Font.Bold = true;
                            ws.Cells[2, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[2, 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[2, 1].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[2, 1].Style.Font.Color.SetColor(Color.White);
                            for (int i = 2; i <= 9; i++)
                            {
                                ws.Cells[2, i].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            }
                            if (Proc_AzureBackupAndDR_WindowsServer.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_AzureBackupAndDR_WindowsServer, true);
                                ExcelDesign(ws, Proc_AzureBackupAndDR_WindowsServer.Columns.Count, Proc_AzureBackupAndDR_WindowsServer.Rows.Count, 4, 1);
                                CurrencyFormatDesign(ws, Proc_AzureBackupAndDR_WindowsServer.Columns.Count, Proc_AzureBackupAndDR_WindowsServer.Rows.Count, 7, 2);
                            }
                            if (Proc_AzureBackupAndDR_SQLServer.Rows.Count != 0)
                            {
                                ws.Cells[4, 4].LoadFromDataTable(Proc_AzureBackupAndDR_SQLServer, true);
                                ExcelDesign(ws, Proc_AzureBackupAndDR_SQLServer.Columns.Count, Proc_AzureBackupAndDR_SQLServer.Rows.Count, 4, 4);
                                CurrencyFormatDesign(ws, Proc_AzureBackupAndDR_SQLServer.Columns.Count, Proc_AzureBackupAndDR_SQLServer.Rows.Count, 7, 5);
                            }
                            if (Proc_AzureBackupAndDR_LinuxServer.Rows.Count != 0)
                            {
                                ws.Cells[4, 7].LoadFromDataTable(Proc_AzureBackupAndDR_LinuxServer, true);
                                ExcelDesign(ws, Proc_AzureBackupAndDR_LinuxServer.Columns.Count, Proc_AzureBackupAndDR_LinuxServer.Rows.Count, 4, 7);
                                CurrencyFormatDesign(ws, Proc_AzureBackupAndDR_LinuxServer.Columns.Count, Proc_AzureBackupAndDR_LinuxServer.Rows.Count, 7, 8);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide16", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide16.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 17");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_StorageCostOverview_Summary.Rows.Count != 0)
                            {
                                ws.Cells[2, 1].LoadFromDataTable(Proc_StorageCostOverview_Summary, true);
                                ExcelDesign(ws, Proc_StorageCostOverview_Summary.Columns.Count, Proc_StorageCostOverview_Summary.Rows.Count, 2, 1);
                                CurrencyFormatDesign(ws, Proc_StorageCostOverview_Summary.Columns.Count, Proc_StorageCostOverview_Summary.Rows.Count, 3, 5);
                            }
                            if (Proc_StorageCostOverview_WindowsServer.Rows.Count != 0)
                            {
                                ws.Cells[10, 1].LoadFromDataTable(Proc_StorageCostOverview_WindowsServer, true);
                                ExcelDesign(ws, Proc_StorageCostOverview_WindowsServer.Columns.Count, Proc_StorageCostOverview_WindowsServer.Rows.Count, 10, 1);
                                CurrencyFormatDesign(ws, Proc_StorageCostOverview_WindowsServer.Columns.Count, Proc_StorageCostOverview_WindowsServer.Rows.Count, 14, 2);
                            }
                            if (Proc_StorageCostOverview_SQLServer.Rows.Count != 0)
                            {
                                ws.Cells[10, 4].LoadFromDataTable(Proc_StorageCostOverview_SQLServer, true);
                                ExcelDesign(ws, Proc_StorageCostOverview_SQLServer.Columns.Count, Proc_StorageCostOverview_SQLServer.Rows.Count, 10, 4);
                                CurrencyFormatDesign(ws, Proc_StorageCostOverview_SQLServer.Columns.Count, Proc_StorageCostOverview_SQLServer.Rows.Count, 14, 5);
                            }
                            if (Proc_StorageCostOverview_LinuxServer.Rows.Count != 0)
                            {
                                ws.Cells[10, 7].LoadFromDataTable(Proc_StorageCostOverview_LinuxServer, true);
                                ExcelDesign(ws, Proc_StorageCostOverview_LinuxServer.Columns.Count, Proc_StorageCostOverview_LinuxServer.Rows.Count, 10, 7);
                                CurrencyFormatDesign(ws, Proc_StorageCostOverview_LinuxServer.Columns.Count, Proc_StorageCostOverview_LinuxServer.Rows.Count, 14, 8);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 13, 2, 20].Merge = true;
                            ws.Cells[1, 13, 2, 20].Value = "Reference Slide";
                            ws.Cells[1, 13, 2, 20].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 13, 2, 20].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide17", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide17.png"))).SetPosition(2, 0, 10, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 23");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_CustomBuildApplicationsWindowsAppServers_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWindowsAppServers_Summary, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWindowsAppServers_Summary.Columns.Count, Proc_CustomBuildApplicationsWindowsAppServers_Summary.Rows.Count, 1, 1);
                            }
                            if (Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing.Columns.Count, Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing.Rows.Count, 4, 1);
                                CurrencyFormatDesign(ws, Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing.Columns.Count, Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing.Rows.Count, 5, 2);
                            }
                            if (Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing.Rows.Count != 0)
                            {
                                ws.Cells[12, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing.Columns.Count, Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing.Rows.Count, 12, 1);
                                CurrencyFormatDesign(ws, Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing.Columns.Count, Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing.Rows.Count, 13, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide23", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide23.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 24");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_CustomBuildApplicationsSQLDatabases_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_CustomBuildApplicationsSQLDatabases_Summary, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsSQLDatabases_Summary.Columns.Count, Proc_CustomBuildApplicationsSQLDatabases_Summary.Rows.Count, 1, 1);
                            }
                            if (Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing.Rows.Count != 0)
                            {
                                ws.Cells[9, 1].LoadFromDataTable(Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing.Rows.Count, 9, 1);
                                CurrencyFormatDesign(ws, Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing.Rows.Count, 10, 2);
                            }
                            if (Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing.Rows.Count != 0)
                            {
                                ws.Cells[17, 1].LoadFromDataTable(Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing.Rows.Count, 17, 1);
                                CurrencyFormatDesign(ws, Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing.Rows.Count, 18, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide24", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide24.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 25");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary.Columns.Count, Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary.Rows.Count, 1, 1);
                            }
                            if (Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing.Rows.Count != 0)
                            {
                                ws.Cells[7, 1].LoadFromDataTable(Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing.Rows.Count, 7, 1);
                                CurrencyFormatDesign(ws, Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing.Rows.Count, 8, 2);
                            }
                            if (Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing.Rows.Count != 0)
                            {
                                ws.Cells[15, 1].LoadFromDataTable(Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing.Rows.Count, 15, 1);
                                CurrencyFormatDesign(ws, Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing.Columns.Count, Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing.Rows.Count, 16, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide25", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide25.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 28");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_CustomBuildApplicationsWithSQLDatabases_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWithSQLDatabases_Summary, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWithSQLDatabases_Summary.Columns.Count, Proc_CustomBuildApplicationsWithSQLDatabases_Summary.Rows.Count, 1, 1);
                            }
                            if (Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer.Rows.Count != 0)
                            {
                                ws.Cells[6, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer.Columns.Count, Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer.Rows.Count, 6, 1);
                            }
                            if (Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer.Rows.Count != 0)
                            {
                                ws.Cells[10, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer.Columns.Count, Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer.Rows.Count, 10, 1);
                            }
                            if (Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase.Rows.Count != 0)
                            {
                                ws.Cells[14, 1].LoadFromDataTable(Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase, true);
                                ExcelDesign(ws, Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase.Columns.Count, Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase.Rows.Count, 14, 1);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide28", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide28.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 30");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_WindowsApplicationServersForISVApps_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_WindowsApplicationServersForISVApps_Summary, true);
                                ExcelDesign(ws, Proc_WindowsApplicationServersForISVApps_Summary.Columns.Count, Proc_WindowsApplicationServersForISVApps_Summary.Rows.Count, 1, 1);
                            }
                            if (Proc_WindowsApplicationServersForISVApps_AsIsPricing.Rows.Count != 0)
                            {
                                ws.Cells[8, 1].LoadFromDataTable(Proc_WindowsApplicationServersForISVApps_AsIsPricing, true);
                                ExcelDesign(ws, Proc_WindowsApplicationServersForISVApps_AsIsPricing.Columns.Count, Proc_WindowsApplicationServersForISVApps_AsIsPricing.Rows.Count, 8, 1);
                                CurrencyFormatDesign(ws, Proc_WindowsApplicationServersForISVApps_AsIsPricing.Columns.Count, Proc_WindowsApplicationServersForISVApps_AsIsPricing.Rows.Count, 9, 2);
                            }
                            if (Proc_WindowsApplicationServersForISVApps_RightSizedPricing.Rows.Count != 0)
                            {
                                ws.Cells[15, 1].LoadFromDataTable(Proc_WindowsApplicationServersForISVApps_RightSizedPricing, true);
                                ExcelDesign(ws, Proc_WindowsApplicationServersForISVApps_RightSizedPricing.Columns.Count, Proc_WindowsApplicationServersForISVApps_RightSizedPricing.Rows.Count, 15, 1);
                                CurrencyFormatDesign(ws, Proc_WindowsApplicationServersForISVApps_RightSizedPricing.Columns.Count, Proc_WindowsApplicationServersForISVApps_RightSizedPricing.Rows.Count, 16, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide30", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide30.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 31");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_ISVApplicationsWithSQLDatabases_Summary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_ISVApplicationsWithSQLDatabases_Summary, true);
                                ExcelDesign(ws, Proc_ISVApplicationsWithSQLDatabases_Summary.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_Summary.Rows.Count, 1, 1);
                            }
                            if (Proc_ISVApplicationsWithSQLDatabases_AsIsPricing.Rows.Count != 0)
                            {
                                ws.Cells[8, 1].LoadFromDataTable(Proc_ISVApplicationsWithSQLDatabases_AsIsPricing, true);
                                ExcelDesign(ws, Proc_ISVApplicationsWithSQLDatabases_AsIsPricing.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_AsIsPricing.Rows.Count, 8, 1);
                                CurrencyFormatDesign(ws, Proc_ISVApplicationsWithSQLDatabases_AsIsPricing.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_AsIsPricing.Rows.Count, 9, 2);
                            }
                            if (Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing.Rows.Count != 0)
                            {
                                ws.Cells[15, 1].LoadFromDataTable(Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing, true);
                                ExcelDesign(ws, Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing.Rows.Count, 15, 1);
                                CurrencyFormatDesign(ws, Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing.Rows.Count, 16, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide31", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide31.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 32");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_ISVApplicationsWithSQLDatabases_ISVSummary.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_ISVApplicationsWithSQLDatabases_ISVSummary, true);
                                ExcelDesign(ws, Proc_ISVApplicationsWithSQLDatabases_ISVSummary.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_ISVSummary.Rows.Count, 1, 1);
                            }
                            if (Proc_ISVApplicationsWithSQLDatabases_ApplicationServer.Rows.Count != 0)
                            {
                                ws.Cells[6, 1].LoadFromDataTable(Proc_ISVApplicationsWithSQLDatabases_ApplicationServer, true);
                                ExcelDesign(ws, Proc_ISVApplicationsWithSQLDatabases_ApplicationServer.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_ApplicationServer.Rows.Count, 6, 1);
                            }
                            if (Proc_ISVApplicationsWithSQLDatabases_SQLServer.Rows.Count != 0)
                            {
                                ws.Cells[10, 1].LoadFromDataTable(Proc_ISVApplicationsWithSQLDatabases_SQLServer, true);
                                ExcelDesign(ws, Proc_ISVApplicationsWithSQLDatabases_SQLServer.Columns.Count, Proc_ISVApplicationsWithSQLDatabases_SQLServer.Rows.Count, 10, 1);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide32", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide32.png"))).SetPosition(2, 0, 8, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 34");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            if (Proc_SQLAnalytical_WorkloadCount.Rows.Count != 0)
                            {
                                ws.Cells[1, 1].LoadFromDataTable(Proc_SQLAnalytical_WorkloadCount, true);
                                ExcelDesign(ws, Proc_SQLAnalytical_WorkloadCount.Columns.Count, Proc_SQLAnalytical_WorkloadCount.Rows.Count, 1, 1);
                            }
                            if (Proc_SQLAnalytical_Summary.Rows.Count != 0)
                            {
                                ws.Cells[8, 1].LoadFromDataTable(Proc_SQLAnalytical_Summary, true);
                                ExcelDesign(ws, Proc_SQLAnalytical_Summary.Columns.Count, Proc_SQLAnalytical_Summary.Rows.Count, 8, 1);
                            }
                            if (Proc_SQLAnalytical_ComponentVMPrice.Rows.Count != 0)
                            {
                                ws.Cells[15, 1].LoadFromDataTable(Proc_SQLAnalytical_ComponentVMPrice, true);
                                ExcelDesign(ws, Proc_SQLAnalytical_ComponentVMPrice.Columns.Count, Proc_SQLAnalytical_ComponentVMPrice.Rows.Count, 15, 1);
                                CurrencyFormatDesign(ws, Proc_SQLAnalytical_ComponentVMPrice.Columns.Count, Proc_SQLAnalytical_ComponentVMPrice.Rows.Count, 15, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 11, 2, 18].Merge = true;
                            ws.Cells[1, 11, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 11, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 11, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide34", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide34.png"))).SetPosition(2, 0, 8, 0);

                            //ws = xp.Workbook.Worksheets.Add("Slide 43");
                            //ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            //ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            //ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            //if (Proc_SustainabilityReport_Summary.Rows.Count != 0)
                            //{
                            //    ws.Cells[2, 1].LoadFromDataTable(Proc_SustainabilityReport_Summary, true);
                            //    ExcelDesign(ws, Proc_SustainabilityReport_Summary.Columns.Count, Proc_SustainabilityReport_Summary.Rows.Count, 2, 1);
                            //}
                            //if (Proc_SustainabilityReport_CarbonEmissionByVMType.Rows.Count != 0)
                            //{
                            //    ws.Cells[7, 1].LoadFromDataTable(Proc_SustainabilityReport_CarbonEmissionByVMType, true);
                            //    ExcelDesign(ws, Proc_SustainabilityReport_CarbonEmissionByVMType.Columns.Count, Proc_SustainabilityReport_CarbonEmissionByVMType.Rows.Count, 7, 1);
                            //}
                            //if (Proc_SustainabilityReport_CarbonEmissionByScope.Rows.Count != 0)
                            //{
                            //    ws.Cells[13, 1].LoadFromDataTable(Proc_SustainabilityReport_CarbonEmissionByScope, true);
                            //    ExcelDesign(ws, Proc_SustainabilityReport_CarbonEmissionByScope.Columns.Count, Proc_SustainabilityReport_CarbonEmissionByScope.Rows.Count, 13, 1);
                            //}
                            //if (Proc_SustainabilityReport_CarbonReduction.Rows.Count != 0)
                            //{
                            //    ws.Cells[2, 4].LoadFromDataTable(Proc_SustainabilityReport_CarbonReduction, true);
                            //    ExcelDesign(ws, Proc_SustainabilityReport_CarbonReduction.Columns.Count, Proc_SustainabilityReport_CarbonReduction.Rows.Count, 2, 4);
                            //}

                            //ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            //ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            //ws.Cells[1, 12, 2, 19].Merge = true;
                            //ws.Cells[1, 12, 2, 19].Value = "Reference Slide";
                            //ws.Cells[1, 12, 2, 19].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            //ws.Cells[1, 12, 2, 19].Style.Font.Bold = true;
                            //ws.Cells.Worksheet.Drawings.AddPicture("slide43", System.Drawing.Image.
                            //    FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide43.png"))).SetPosition(2, 0, 9, 0);

                            //#region susatin Low
                            //ws = xp.Workbook.Worksheets.Add("Sustain_Low");
                            //ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            //ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            //ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            //ws.Cells[2, 4].Value = "On-Prem Alternative";
                            //ws.Cells[2, 4, 2, 5].Style.Font.Bold = true;
                            //ws.Cells[2, 5].Value = "Low";
                            //ws.Cells[2, 5].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml("#0070c0"));
                            //ws.Cells[2, 5].Style.Font.Color.SetColor(Color.White);
                            //ws.Cells[3, 5].Value = "DC Power utilization efficiency is low";
                            //simpleExcelDesign(ws, 1, 1, 2, 5);
                            //if (Proc_SustainabilityReport_CarbonFootprintLow.Rows.Count != 0)
                            //{
                            //    ws.Cells[4, 1].LoadFromDataTable(Proc_SustainabilityReport_CarbonFootprintLow, true);
                            //    ws.Cells[5, 2, 12, 2].Style.Numberformat.Format = "###,###,###";
                            //    ExcelDesign(ws, Proc_SustainabilityReport_CarbonFootprintLow.Columns.Count, Proc_SustainabilityReport_CarbonFootprintLow.Rows.Count, 4, 1);
                            //}
                            //if (Proc_SustainabilityReport_CarbonFootprintLow.Rows.Count != 0)
                            //{
                            //    var gasoline = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[1].ItemArray[1]) < 999999) ? 1000 : 1000000;
                            //    var gasolinetext = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[1].ItemArray[1]) < 999999) ? "K" : "Millions";
                            //    var vehicle = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[3].ItemArray[1]) < 999999) ? 1000 : 1000000;
                            //    var vehicletext = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[3].ItemArray[1]) < 999999) ? "K" : "Millions";
                            //    var smartphones = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[7].ItemArray[1]) < 999999) ? 1000 : 1000000;
                            //    var smartphonestxt = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[7].ItemArray[1]) < 999999) ? "K" : "Millions";
                            //    var _phonecharge = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[6].ItemArray[1]) < 1) ? 1 : Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[6].ItemArray[1]), 0); 
                            //    ws.Cells[15, 1, 21, 1].Style.Font.SetFromFont(new Font("Calibri", 16));
                            //    ws.Cells[15, 1, 21, 1].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            //    ws.Cells[15, 1, 21, 1].Style.Font.Color.SetColor(Color.DarkBlue);
                            //    ws.Cells[15, 1].Value = "1. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[1].ItemArray[1]) /gasoline,2)+" "+gasolinetext + " gallon of gasoline.";
                            //    ws.Cells[16, 1].Value = "2. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[2].ItemArray[1]), 0) + " passenger vehicles driven for 1 year.";
                            //    ws.Cells[17, 1].Value = "3. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[3].ItemArray[1])/vehicle,2)+" "+vehicletext + " Miles driven by the average passenger vehicle.";
                            //    ws.Cells[18, 1].Value = "4. Powering " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[4].ItemArray[1]), 0) + " homes for 1 year.";
                            //    ws.Cells[19, 1].Value = "5. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[5].ItemArray[1]), 0) + " acres of forests sequestering CO2 for one year.";
                            //    ws.Cells[20, 1].Value = "6. "+ _phonecharge + " wind turbines running for a year.";
                            //    ws.Cells[21, 1].Value = "7. Charging " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintLow.Rows[7].ItemArray[1])/smartphones,2)+" "+smartphonestxt + " smartphones.";
                            //}
                            //ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            //ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            //ws.Cells[1, 8, 2, 18].Merge = true;
                            //ws.Cells[1, 8, 2, 18].Value = "Reference Slide";
                            //ws.Cells[1, 8, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            //ws.Cells[1, 8, 2, 18].Style.Font.Bold = true;
                            //ws.Cells.Worksheet.Drawings.AddPicture("slide45", System.Drawing.Image.
                            //    FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/SustainSilde43.png"))).SetPosition(2, 0, 7, 0);
                            //#endregion
                            #region susatin Medium
                            ws = xp.Workbook.Worksheets.Add("Sustain_Med");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[2, 4].Value = "On-Prem Alternative";
                            ws.Cells[2, 4, 2, 5].Style.Font.Bold = true;
                            ws.Cells[2, 5].Value = "Medium";
                            ws.Cells[2, 5].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml("#0070c0"));
                            ws.Cells[2, 5].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[3, 5].Value = "DC Power utilization efficiency is Medium";
                            simpleExcelDesign(ws, 1, 1, 2, 5);
                            if (Proc_SustainabilityReport_CarbonFootprintMedium.Rows.Count != 0)
                            {
                                ws.Cells[4, 1].LoadFromDataTable(Proc_SustainabilityReport_CarbonFootprintMedium, true);
                                ws.Cells[5, 2, 12, 2].Style.Numberformat.Format = "###,###,###";
                                ExcelDesign(ws, Proc_SustainabilityReport_CarbonFootprintMedium.Columns.Count, Proc_SustainabilityReport_CarbonFootprintMedium.Rows.Count, 4, 1);
                            }
                            if (Proc_SustainabilityReport_CarbonFootprintMedium.Rows.Count != 0)
                            {
                                var gasoline = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[1].ItemArray[1]) < 999999) ? 1000 : 1000000;
                                var gasolinetext = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[1].ItemArray[1]) < 999999) ? "K" : "Millions";
                                var vehicle = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[3].ItemArray[1]) < 999999) ? 1000 : 1000000;
                                var vehicletext = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[3].ItemArray[1]) < 999999) ? "K" : "Millions";
                                var smartphones = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[7].ItemArray[1]) < 999999) ? 1000 : 1000000;
                                var smartphonestxt = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[7].ItemArray[1]) < 999999) ? "K" : "Millions";
                                var _phonecharge = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[6].ItemArray[1]) < 1) ? 1 : Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[6].ItemArray[1]), 0);
                                ws.Cells[15, 1, 21, 1].Style.Font.SetFromFont(new Font("Calibri", 16));
                                ws.Cells[15, 1, 21, 1].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                                ws.Cells[15, 1, 21, 1].Style.Font.Color.SetColor(Color.DarkBlue);
                                ws.Cells[15, 1].Value = "1. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[1].ItemArray[1]) / gasoline,2) + " " + gasolinetext + " gallon of gasoline.";
                                ws.Cells[16, 1].Value = "2. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[2].ItemArray[1]), 0) + " passenger vehicles driven for 1 year.";
                                ws.Cells[17, 1].Value = "3. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[3].ItemArray[1]) / vehicle ,2)+ " " + vehicletext + " Miles driven by the average passenger vehicle.";
                                ws.Cells[18, 1].Value = "4. Powering " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[4].ItemArray[1]), 0) + " homes for 1 year.";
                                ws.Cells[19, 1].Value = "5. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[5].ItemArray[1]), 0) + " acres of forests sequestering CO2 for one year.";
                                ws.Cells[20, 1].Value = "6. " + _phonecharge + " wind turbines running for a year.";
                                ws.Cells[21, 1].Value = "7. Charging " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintMedium.Rows[7].ItemArray[1]) / smartphones ,2) + " " + smartphonestxt + " smartphones.";
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 8, 2, 18].Merge = true;
                            ws.Cells[1, 8, 2, 18].Value = "Reference Slide";
                            ws.Cells[1, 8, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 8, 2, 18].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide45", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/SustainSilde43.png"))).SetPosition(2, 0, 7, 0);
                            #endregion
                            //#region susatin high
                            //ws = xp.Workbook.Worksheets.Add("Sustain_High");
                            //ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            //ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            //ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            //ws.Cells[2, 4].Value = "On-Prem Alternative";
                            //ws.Cells[2, 4, 2, 5].Style.Font.Bold = true;
                            //ws.Cells[2, 5].Value = "High";
                            //ws.Cells[2, 5].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml("#0070c0"));
                            //ws.Cells[2, 5].Style.Font.Color.SetColor(Color.White);
                            //ws.Cells[3, 5].Value = "DC Power utilization efficiency is high";
                            //simpleExcelDesign(ws, 1, 1, 2, 5);
                            //if (Proc_SustainabilityReport_CarbonFootprintHigh.Rows.Count != 0)
                            //{
                            //    ws.Cells[4, 1].LoadFromDataTable(Proc_SustainabilityReport_CarbonFootprintHigh, true);
                            //    ws.Cells[5, 2, 12, 2].Style.Numberformat.Format = "###,###,###";
                            //    ExcelDesign(ws, Proc_SustainabilityReport_CarbonFootprintHigh.Columns.Count, Proc_SustainabilityReport_CarbonFootprintHigh.Rows.Count, 4, 1);
                            //}
                            //if (Proc_SustainabilityReport_CarbonFootprintHigh.Rows.Count != 0)
                            //{
                            //    var gasoline = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[1].ItemArray[1]) < 999999) ? 1000 : 1000000;
                            //    var gasolinetext = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[1].ItemArray[1]) < 999999) ? "K" : "Millions";
                            //    var vehicle = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[3].ItemArray[1]) < 999999) ? 1000 : 1000000;
                            //    var vehicletext = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[3].ItemArray[1]) < 999999) ? "K" : "Millions";
                            //    var smartphones = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[7].ItemArray[1]) < 999999) ? 1000 : 1000000;
                            //    var smartphonestxt = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[7].ItemArray[1]) < 999999) ? "K" : "Millions";
                            //    var _phonecharge = (Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[6].ItemArray[1]) < 1) ? 1 : Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[6].ItemArray[1]), 0);
                            //    ws.Cells[15, 1, 21, 1].Style.Font.SetFromFont(new Font("Calibri", 16));
                            //    ws.Cells[15, 1, 21, 1].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            //    ws.Cells[15, 1, 21, 1].Style.Font.Color.SetColor(Color.DarkBlue);
                            //    ws.Cells[15, 1].Value = "1. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[1].ItemArray[1]) / gasoline, 2) + " " + gasolinetext + " gallon of gasoline.";
                            //    ws.Cells[16, 1].Value = "2. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[2].ItemArray[1]), 0) + " passenger vehicles driven for 1 year.";
                            //    ws.Cells[17, 1].Value = "3. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[3].ItemArray[1]) / vehicle , 2)+" " + vehicletext + " Miles driven by the average passenger vehicle.";
                            //    ws.Cells[18, 1].Value = "4. Powering " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[4].ItemArray[1]), 0) + " homes for 1 year.";
                            //    ws.Cells[19, 1].Value = "5. " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[5].ItemArray[1]), 0) + " acres of forests sequestering CO2 for one year.";
                            //    ws.Cells[20, 1].Value = "6. " + _phonecharge + " wind turbines running for a year.";
                            //    ws.Cells[21, 1].Value = "7. Charging " + Math.Round(Convert.ToDecimal(Proc_SustainabilityReport_CarbonFootprintHigh.Rows[7].ItemArray[1]) / smartphones, 2) + " " + smartphonestxt + " smartphones.";
                            //}
                            //ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            //ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            //ws.Cells[1, 8, 2, 18].Merge = true;
                            //ws.Cells[1, 8, 2, 18].Value = "Reference Slide";
                            //ws.Cells[1, 8, 2, 18].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            //ws.Cells[1, 8, 2, 18].Style.Font.Bold = true;
                            //ws.Cells.Worksheet.Drawings.AddPicture("slide45", System.Drawing.Image.
                            //    FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/SustainSilde43.png"))).SetPosition(2, 0, 7, 0);
                            //#endregion
                            ws = xp.Workbook.Worksheets.Add("Slide 45");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            
                            ws.Cells[2, 1].Value = "Options"; ws.Cells[2, 2].Value = "1-Year TCO";
                            ws.Cells[3, 1].Value = "Lift & Shift on Azure VM’s (IaaS)"; ws.Cells[3, 1].Style.Font.Bold = true; ws.Cells[3, 2].Formula = "=SUM('Slide 61'!F19:F21)+SUM('Slide 62'!F13:F15)+'Slide 12'!H18+'Slide 12'!H22+('Slide 12'!E18+'Slide 12'!E22)*0.15"; ws.Cells[3, 2].Style.Font.Bold = true;
                            ws.Cells[4, 1].Value = "•Windows App Servers:"; ws.Cells[4, 2].Formula = "='Slide 12'!B17";
                            ws.Cells[5, 1].Value = "•SQL VM:"; ws.Cells[5, 2].Formula = "='Slide 12'!B19";
                            ws.Cells[6, 1].Value = "•Linux VMs:"; ws.Cells[6, 2].Formula = "='Slide 12'!B18";
                            ws.Cells[7, 1].Value = "Optimized Azure (IaaS +SQL PaaS)"; ws.Cells[7, 1].Style.Font.Bold = true; ws.Cells[7, 2].Formula = "=SUM('Slide 62'!F13:F15)+'Slide 12'!H18+'Slide 12'!H22+('Slide 12'!E18+'Slide 12'!E22)*0.15+SUM('Slide 31'!E16:E18)+SUM('Slide 24'!E18:E20)+'Slide 34'!B16"; ws.Cells[7, 2].Style.Font.Bold = true;
                            ws.Cells[8, 1].Value = "•Windows App Servers:"; ws.Cells[8, 2].Formula = "='Slide 12'!B17";
                            ws.Cells[9, 1].Value = "•Linux VM:"; ws.Cells[9, 2].Formula = "='Slide 12'!B18";
                            ws.Cells[10, 1].Value = "•Azure SQL VM for ISV Apps:"; ws.Cells[10, 2].Formula = "='Slide 31'!B3";
                            ws.Cells[11, 1].Value = "•Azure SQL Managed Instances for Custom Build Apps DB's:"; ws.Cells[11, 2].Formula = "='Slide 24'!B3";
                            ws.Cells[12, 1].Value = "•SQL Component Services on Azure SQL VM:"; ws.Cells[12, 2].Formula = "='Slide 34'!B9";

                            ExcelDesign(ws, 2, 10, 2, 1);
                            ws.Cells[3, 2].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[7, 2].Style.Numberformat.Format = CurrencyFormat;

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide45", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide45.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 47");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            
                            ws.Cells[2, 1].Value = "Options"; ws.Cells[2, 2].Value = "Annual TCO";
                            ws.Cells[3, 1].Value = "Lift & Shift on Azure VM’s (IaaS)"; ws.Cells[3, 1].Style.Font.Bold = true; ws.Cells[3, 2].Formula = "=SUM('Slide 61'!F19:F21)+SUM('Slide 62'!F13:F15)+'Slide 12'!H18+'Slide 12'!H22+('Slide 12'!E18+'Slide 12'!E22)*0.15"; ws.Cells[3, 2].Style.Font.Bold = true;
                            ws.Cells[4, 1].Value = "•Windows App Servers:"; ws.Cells[4, 2].Formula = "='Slide 12'!B17";
                            ws.Cells[5, 1].Value = "•Database Server (SQL & PostgreSQL)"; ws.Cells[5, 2].Formula = "='Slide 12'!B19";
                            ws.Cells[6, 1].Value = "Optimized Azure (IaaS +SQL PaaS)"; ws.Cells[6, 1].Style.Font.Bold = true; ws.Cells[6, 2].Formula = "=SUM('Slide 62'!F13:F15)+'Slide 12'!H18+'Slide 12'!H22+('Slide 12'!E18+'Slide 12'!E22)*0.15+SUM('Slide 31'!E16:E18)+SUM('Slide 24'!E18:E20)+'Slide 34'!B16"; ws.Cells[6, 2].Style.Font.Bold = true;
                            ws.Cells[7, 1].Value = "•Windows App Servers:"; ws.Cells[7, 2].Formula = "='Slide 12'!B17";
                            ws.Cells[8, 1].Value = "•Azure SQL Managed Instances :"; ws.Cells[8, 2].Formula = "='Slide 24'!B3";
                            ws.Cells[9, 1].Value = "•Azure PostgreSQL:"; ws.Cells[9, 2].Value = 0;
                            ws.Cells[10, 1].Value = "Azure PaaS"; ws.Cells[10, 1].Style.Font.Bold = true; ws.Cells[10, 2].Formula = "=SUM('Slide 24'!E18:E20)+'Slide 34'!B16"; ws.Cells[10, 2].Style.Font.Bold = true;
                            ws.Cells[11, 1].Value = "•App Services :"; ws.Cells[11, 2].Value = 0;
                            ws.Cells[12, 1].Value = "•Azure SQL Managed Instances :"; ws.Cells[12, 2].Formula = "='Slide 24'!B3";
                            ws.Cells[13, 1].Value = "•Azure PostgreSQL:"; ws.Cells[13, 2].Value = 0;

                            ExcelDesign(ws, 2, 11, 2, 1);
                            ws.Cells[3, 2].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[6, 2].Style.Numberformat.Format = CurrencyFormat;
                            ws.Cells[10, 2].Style.Numberformat.Format = CurrencyFormat;

                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 16, 2, 23].Merge = true;
                            ws.Cells[1, 16, 2, 23].Value = "Reference Slide";
                            ws.Cells[1, 16, 2, 23].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 16, 2, 23].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide47", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide47.png"))).SetPosition(2, 0, 13, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 61");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[3, 1].Value = "SQL VM"; ws.Cells[3, 2].Formula = "='Slide 12'!B19";
                            ws.Cells[3, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[3, 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[3, 1].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[3, 1].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[3, 1].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[3, 2].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            if (Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense.Rows.Count != 0)
                            {
                                ws.Cells[6, 1].LoadFromDataTable(Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense, true);
                                ExcelDesign(ws, Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense.Columns.Count, Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense.Rows.Count, 6, 1);
                            }
                            if (Proc_SQLServerCoreAndCostCalculations_SQLServerLicense.Rows.Count != 0)
                            {
                                ws.Cells[12, 1].LoadFromDataTable(Proc_SQLServerCoreAndCostCalculations_SQLServerLicense, true);
                                ExcelDesign(ws, Proc_SQLServerCoreAndCostCalculations_SQLServerLicense.Columns.Count, Proc_SQLServerCoreAndCostCalculations_SQLServerLicense.Rows.Count, 12, 1);
                            }
                            if (Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Rows.Count != 0)
                            {
                                ws.Cells[18, 1].LoadFromDataTable(Proc_SQLServerCoreAndCostCalculations_DatabaseCost, true);
                                ExcelDesign(ws, Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Columns.Count, Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Rows.Count, 18, 1);
                                CurrencyFormatDesign(ws, Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Columns.Count, Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Rows.Count, 19, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 12, 2, 19].Merge = true;
                            ws.Cells[1, 12, 2, 19].Value = "Reference Slide";
                            ws.Cells[1, 12, 2, 19].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 12, 2, 19].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide61", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide61.png"))).SetPosition(2, 0, 9, 0);

                            ws = xp.Workbook.Worksheets.Add("Slide 62");
                            ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                            ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                            ws.Cells[3, 1].Value = "Windows VM"; ws.Cells[3, 2].Formula = "='Slide 12'!B17";
                            ws.Cells[3, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[3, 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                            ws.Cells[3, 1].Style.Fill.BackgroundColor.SetColor(Color.Black);
                            ws.Cells[3, 1].Style.Font.Color.SetColor(Color.White);
                            ws.Cells[3, 1].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            ws.Cells[3, 2].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
                            if (Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense.Rows.Count != 0)
                            {
                                ws.Cells[6, 1].LoadFromDataTable(Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense, true);
                                ExcelDesign(ws, Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense.Columns.Count, Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense.Rows.Count, 6, 1);
                            }
                            if (Proc_WindowsServerCoreAndCostCalculation_WindowsCost.Rows.Count != 0)
                            {
                                ws.Cells[12, 1].LoadFromDataTable(Proc_WindowsServerCoreAndCostCalculation_WindowsCost, true);
                                ExcelDesign(ws, Proc_WindowsServerCoreAndCostCalculation_WindowsCost.Columns.Count, Proc_WindowsServerCoreAndCostCalculation_WindowsCost.Rows.Count, 12, 1);
                                CurrencyFormatDesign(ws, Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Columns.Count, Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Rows.Count, 13, 2);
                            }
                            ws.Cells[ws.Dimension.Address].AutoFitColumns();
                            ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                            ws.Cells[1, 12, 2, 19].Merge = true;
                            ws.Cells[1, 12, 2, 19].Value = "Reference Slide";
                            ws.Cells[1, 12, 2, 19].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[1, 12, 2, 19].Style.Font.Bold = true;
                            ws.Cells.Worksheet.Drawings.AddPicture("slide62", System.Drawing.Image.
                                FromFile(HttpContext.Current.Server.MapPath("~/img/BoomRang_IMG/New_Template/slide62.png"))).SetPosition(2, 0, 9, 0);

                            Response.AddHeader("content-disposition", "attachment;filename=" + InventoryName + "_" + "NewHBCFormatWorkbook [" + CurrencyMode + "].xlsx");
                            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            Response.BinaryWrite(xp.GetAsByteArray());
                            HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                            HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                            HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                            //Response.End();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        public DataSet GetNewHBCFormatExcelData()
        {
            DataSet ds = new DataSet("BoomRang");
            try
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString());

                BoomRangReportService service = new BoomRangReportService(_ServerName, _DBName, CurrencyMode, Region);

                #region Environment Discovery
                List<Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummaryResult> Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary = service.Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary().ToList();
                if (Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryWindowsServer_WindowsServerSummary));
                    dt.TableName = "Slide 4_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCountResult> Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount = service.Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount().ToList();
                if (Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryWindowsServer_WindowsEditionCount));
                    dt.TableName = "Slide 4_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummaryResult> Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary = service.Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary().ToList();
                if (Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryWindowsServer_SQLServerSummary));
                    dt.TableName = "Slide 4_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCountResult> Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount = service.Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount().ToList();
                if (Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryWindowsServer_SQLEditionCount));
                    dt.TableName = "Slide 4_4";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCountResult> Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount = service.Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount().ToList();
                if (Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryWindowsServer_OtherWorkloadCount));
                    dt.TableName = "Slide 4_5";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryWindowsServer_DBCountResult> Proc_EnvironmentDiscoveryWindowsServer_DBCount = service.Proc_EnvironmentDiscoveryWindowsServer_DBCount().ToList();
                if (Proc_EnvironmentDiscoveryWindowsServer_DBCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryWindowsServer_DBCount));
                    dt.TableName = "Slide 4_6";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummaryResult> Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary = service.Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary().ToList();
                if (Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryLinuxServer_LinuxServerSummary));
                    dt.TableName = "Slide 5_1";
                    ds.Tables.Add(dt);
                }

                List<Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCountResult> Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount = service.Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount().ToList();
                if (Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryLinuxServer_LinuxEditionCount));
                    dt.TableName = "Slide 5_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCountResult> Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount = service.Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount().ToList();
                if (Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryLinuxServer_OtherWorkloadCount));
                    dt.TableName = "Slide 5_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_EnvironmentDiscoveryLinuxServer_DBCountResult> Proc_EnvironmentDiscoveryLinuxServer_DBCount = service.Proc_EnvironmentDiscoveryLinuxServer_DBCount().ToList();
                if (Proc_EnvironmentDiscoveryLinuxServer_DBCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_EnvironmentDiscoveryLinuxServer_DBCount));
                    dt.TableName = "Slide 5_4";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Application Vendor Details
                List<Proc_ISVApplications_WindowsBasedSummaryResult> Proc_ISVApplications_WindowsBasedSummary = service.Proc_ISVApplications_WindowsBasedSummary().ToList();
                if (Proc_ISVApplications_WindowsBasedSummary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplications_WindowsBasedSummary));
                    dt.TableName = "Slide 6_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplications_WindowsBasedVendorListResult> Proc_ISVApplications_WindowsBasedVendorList = service.Proc_ISVApplications_WindowsBasedVendorList().ToList();
                if (Proc_ISVApplications_WindowsBasedVendorList.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplications_WindowsBasedVendorList));
                    dt.TableName = "Slide 6_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplications_WindowsBasedApplicationVendorCountListResult> Proc_ISVApplications_WindowsBasedApplicationVendorCountList = service.Proc_ISVApplications_WindowsBasedApplicationVendorCountList().ToList();
                if (Proc_ISVApplications_WindowsBasedApplicationVendorCountList.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplications_WindowsBasedApplicationVendorCountList));
                    dt.TableName = "Slide 6_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplications_LinuxBasedSummaryResult> Proc_ISVApplications_LinuxBasedSummary = service.Proc_ISVApplications_LinuxBasedSummary().ToList();
                if (Proc_ISVApplications_LinuxBasedSummary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplications_LinuxBasedSummary));
                    dt.TableName = "Slide 7_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplications_LinuxBasedVendorListResult> Proc_ISVApplications_LinuxBasedVendorList = service.Proc_ISVApplications_LinuxBasedVendorList().ToList();
                if (Proc_ISVApplications_LinuxBasedVendorList.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplications_LinuxBasedVendorList));
                    dt.TableName = "Slide 7_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplications_LinuxBasedApplicationVendorCountListResult> Proc_ISVApplications_LinuxBasedApplicationVendorCountList = service.Proc_ISVApplications_LinuxBasedApplicationVendorCountList().ToList();
                if (Proc_ISVApplications_LinuxBasedApplicationVendorCountList.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplications_LinuxBasedApplicationVendorCountList));
                    dt.TableName = "Slide 7_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Infrastructure Optimization
                List<Proc_InfrastructureOptimizationResult> Proc_InfrastructureOptimization = service.Proc_InfrastructureOptimization().ToList();
                if (Proc_InfrastructureOptimization.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_InfrastructureOptimization));
                    dt.TableName = "Slide 11";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Right Sized IaaS Environment
                List<Proc_RightSizedIaaSEnvironmentResult> Proc_RightSizedIaaSEnvironment = service.Proc_RightSizedIaaSEnvironment().ToList();
                if (Proc_RightSizedIaaSEnvironment.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_RightSizedIaaSEnvironment));
                    dt.TableName = "Slide 12";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Windows Server Overview
                List<Proc_WindowsServerOverview_SummaryResult> Proc_WindowsServerOverview_Summary = service.Proc_WindowsServerOverview_Summary().ToList();
                if (Proc_WindowsServerOverview_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsServerOverview_Summary));
                    dt.TableName = "Slide 13_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_WindowsServerOverview_WindowsEditionCountResult> Proc_WindowsServerOverview_WindowsEditionCount = service.Proc_WindowsServerOverview_WindowsEditionCount().ToList();
                if (Proc_WindowsServerOverview_WindowsEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsServerOverview_WindowsEditionCount));
                    dt.TableName = "Slide 13_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_WindowsServerOverview_NetstatDataResult> Proc_WindowsServerOverview_NetstatData = service.Proc_WindowsServerOverview_NetstatData().ToList();
                if (Proc_WindowsServerOverview_NetstatData.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsServerOverview_NetstatData));
                    dt.TableName = "Slide 13_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQL Server Overview
                List<Proc_SQLServerOverview_SummaryResult> Proc_SQLServerOverview_Summary = service.Proc_SQLServerOverview_Summary().ToList();
                if (Proc_SQLServerOverview_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerOverview_Summary));
                    dt.TableName = "Slide 14_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLServerOverview_WindowsEditionCountResult> Proc_SQLServerOverview_WindowsEditionCount = service.Proc_SQLServerOverview_WindowsEditionCount().ToList();
                if (Proc_SQLServerOverview_WindowsEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerOverview_WindowsEditionCount));
                    dt.TableName = "Slide 14_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLServerOverview_SQLEditionCountResult> Proc_SQLServerOverview_SQLEditionCount = service.Proc_SQLServerOverview_SQLEditionCount().ToList();
                if (Proc_SQLServerOverview_SQLEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerOverview_SQLEditionCount));
                    dt.TableName = "Slide 14_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLServerOverview_NetstatDataResult> Proc_SQLServerOverview_NetstatData = service.Proc_SQLServerOverview_NetstatData().ToList();
                if (Proc_SQLServerOverview_NetstatData.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerOverview_NetstatData));
                    dt.TableName = "Slide 14_4";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Linux Server Overview
                List<Proc_LinuxServerOverview_SummaryResult> Proc_LinuxServerOverview_Summary = service.Proc_LinuxServerOverview_Summary().ToList();
                if (Proc_LinuxServerOverview_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_LinuxServerOverview_Summary));
                    dt.TableName = "Slide 15_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_LinuxServerOverview_LinuxEditionCountResult> Proc_LinuxServerOverview_LinuxEditionCount = service.Proc_LinuxServerOverview_LinuxEditionCount().ToList();
                if (Proc_LinuxServerOverview_LinuxEditionCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_LinuxServerOverview_LinuxEditionCount));
                    dt.TableName = "Slide 15_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_LinuxServerOverview_NetstatDataResult> Proc_LinuxServerOverview_NetstatData = service.Proc_LinuxServerOverview_NetstatData().ToList();
                if (Proc_LinuxServerOverview_NetstatData.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_LinuxServerOverview_NetstatData));
                    dt.TableName = "Slide 15_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Azure Backup And DR
                List<Proc_AzureBackupAndDR_WindowsServerResult> Proc_AzureBackupAndDR_WindowsServer = service.Proc_AzureBackupAndDR_WindowsServer().ToList();
                if (Proc_AzureBackupAndDR_WindowsServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_AzureBackupAndDR_WindowsServer));
                    dt.TableName = "Slide 16_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_AzureBackupAndDR_SQLServerResult> Proc_AzureBackupAndDR_SQLServer = service.Proc_AzureBackupAndDR_SQLServer().ToList();
                if (Proc_AzureBackupAndDR_SQLServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_AzureBackupAndDR_SQLServer));
                    dt.TableName = "Slide 16_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_AzureBackupAndDR_LinuxServerResult> Proc_AzureBackupAndDR_LinuxServer = service.Proc_AzureBackupAndDR_LinuxServer().ToList();
                if (Proc_AzureBackupAndDR_LinuxServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_AzureBackupAndDR_LinuxServer));
                    dt.TableName = "Slide 16_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Storage Cost Overview
                List<Proc_StorageCostOverview_SummaryResult> Proc_StorageCostOverview_Summary = service.Proc_StorageCostOverview_Summary().ToList();
                if (Proc_StorageCostOverview_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_StorageCostOverview_Summary));
                    dt.TableName = "Slide 17_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_StorageCostOverview_WindowsServerResult> Proc_StorageCostOverview_WindowsServer = service.Proc_StorageCostOverview_WindowsServer().ToList();
                if (Proc_StorageCostOverview_WindowsServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_StorageCostOverview_WindowsServer));
                    dt.TableName = "Slide 17_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_StorageCostOverview_SQLServerResult> Proc_StorageCostOverview_SQLServer = service.Proc_StorageCostOverview_SQLServer().ToList();
                if (Proc_StorageCostOverview_SQLServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_StorageCostOverview_SQLServer));
                    dt.TableName = "Slide 17_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_StorageCostOverview_LinuxServerResult> Proc_StorageCostOverview_LinuxServer = service.Proc_StorageCostOverview_LinuxServer().ToList();
                if (Proc_StorageCostOverview_LinuxServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_StorageCostOverview_LinuxServer));
                    dt.TableName = "Slide 17_4";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Custom Build Applications Windows App Servers
                List<Proc_CustomBuildApplicationsWindowsAppServers_SummaryResult> Proc_CustomBuildApplicationsWindowsAppServers_Summary = service.Proc_CustomBuildApplicationsWindowsAppServers_Summary().ToList();
                if (Proc_CustomBuildApplicationsWindowsAppServers_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWindowsAppServers_Summary));
                    dt.TableName = "Slide 23_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricingResult> Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing = service.Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing().ToList();
                if (Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWindowsAppServers_AsIsPricing));
                    dt.TableName = "Slide 23_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricingResult> Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing = service.Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing().ToList();
                if (Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWindowsAppServers_RightSizedPricing));
                    dt.TableName = "Slide 23_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Custom Build Applications SQL Databases
                List<Proc_CustomBuildApplicationsSQLDatabases_SummaryResult> Proc_CustomBuildApplicationsSQLDatabases_Summary = service.Proc_CustomBuildApplicationsSQLDatabases_Summary().ToList();
                if (Proc_CustomBuildApplicationsSQLDatabases_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsSQLDatabases_Summary));
                    dt.TableName = "Slide 24_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricingResult> Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing = service.Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing().ToList();
                if (Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsSQLDatabases_BeforeConsolidationPricing));
                    dt.TableName = "Slide 24_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricingResult> Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing = service.Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing().ToList();
                if (Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsSQLDatabases_AfterConsolidationPricing));
                    dt.TableName = "Slide 24_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Custom Build Applications SQL Databases On VM
                List<Proc_CustomBuildApplicationsSQLDatabasesOnVM_SummaryResult> Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary = service.Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary().ToList();
                if (Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsSQLDatabasesOnVM_Summary));
                    dt.TableName = "Slide 25_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricingResult> Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing = service.Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing().ToList();
                if (Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsSQLDatabasesOnVM_AsIsPricing));
                    dt.TableName = "Slide 25_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricingResult> Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing = service.Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing().ToList();
                if (Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsSQLDatabasesOnVM_RightSizedPricing));
                    dt.TableName = "Slide 25_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Custom Build Applications SQL Databases License Distribution
                List<Proc_CustomBuildApplicationsWithSQLDatabases_SummaryResult> Proc_CustomBuildApplicationsWithSQLDatabases_Summary = service.Proc_CustomBuildApplicationsWithSQLDatabases_Summary().ToList();
                if (Proc_CustomBuildApplicationsWithSQLDatabases_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWithSQLDatabases_Summary));
                    dt.TableName = "Slide 28_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServerResult> Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer = service.Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer().ToList();
                if (Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWithSQLDatabases_ApplicationServer));
                    dt.TableName = "Slide 28_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsWithSQLDatabases_SQLServerResult> Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer = service.Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer().ToList();
                if (Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWithSQLDatabases_SQLServer));
                    dt.TableName = "Slide 28_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabaseResult> Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase = service.Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase().ToList();
                if (Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_CustomBuildApplicationsWithSQLDatabases_SQLDatabase));
                    dt.TableName = "Slide 28_4";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Windows Application Servers For ISV Apps
                List<Proc_WindowsApplicationServersForISVApps_SummaryResult> Proc_WindowsApplicationServersForISVApps_Summary = service.Proc_WindowsApplicationServersForISVApps_Summary().ToList();
                if (Proc_WindowsApplicationServersForISVApps_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsApplicationServersForISVApps_Summary));
                    dt.TableName = "Slide 30_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_WindowsApplicationServersForISVApps_AsIsPricingResult> Proc_WindowsApplicationServersForISVApps_AsIsPricing = service.Proc_WindowsApplicationServersForISVApps_AsIsPricing().ToList();
                if (Proc_WindowsApplicationServersForISVApps_AsIsPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsApplicationServersForISVApps_AsIsPricing));
                    dt.TableName = "Slide 30_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_WindowsApplicationServersForISVApps_RightSizedPricingResult> Proc_WindowsApplicationServersForISVApps_RightSizedPricing = service.Proc_WindowsApplicationServersForISVApps_RightSizedPricing().ToList();
                if (Proc_WindowsApplicationServersForISVApps_RightSizedPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsApplicationServersForISVApps_RightSizedPricing));
                    dt.TableName = "Slide 30_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region ISV Applications With SQL Databases
                List<Proc_ISVApplicationsWithSQLDatabases_SummaryResult> Proc_ISVApplicationsWithSQLDatabases_Summary = service.Proc_ISVApplicationsWithSQLDatabases_Summary().ToList();
                if (Proc_ISVApplicationsWithSQLDatabases_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplicationsWithSQLDatabases_Summary));
                    dt.TableName = "Slide 31_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplicationsWithSQLDatabases_AsIsPricingResult> Proc_ISVApplicationsWithSQLDatabases_AsIsPricing = service.Proc_ISVApplicationsWithSQLDatabases_AsIsPricing().ToList();
                if (Proc_ISVApplicationsWithSQLDatabases_AsIsPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplicationsWithSQLDatabases_AsIsPricing));
                    dt.TableName = "Slide 31_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplicationsWithSQLDatabases_RightSizedPricingResult> Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing = service.Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing().ToList();
                if (Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplicationsWithSQLDatabases_RightSizedPricing));
                    dt.TableName = "Slide 31_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region ISV Applications With SQL Databases License Distribution
                List<Proc_ISVApplicationsWithSQLDatabases_SummaryResult> Proc_ISVApplicationsWithSQLDatabases_ISVSummary = service.Proc_ISVApplicationsWithSQLDatabases_Summary().ToList();
                if (Proc_ISVApplicationsWithSQLDatabases_ISVSummary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplicationsWithSQLDatabases_ISVSummary));
                    dt.TableName = "Slide 32_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplicationsWithSQLDatabases_ApplicationServerResult> Proc_ISVApplicationsWithSQLDatabases_ApplicationServer = service.Proc_ISVApplicationsWithSQLDatabases_ApplicationServer().ToList();
                if (Proc_ISVApplicationsWithSQLDatabases_ApplicationServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplicationsWithSQLDatabases_ApplicationServer));
                    dt.TableName = "Slide 32_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_ISVApplicationsWithSQLDatabases_SQLServerResult> Proc_ISVApplicationsWithSQLDatabases_SQLServer = service.Proc_ISVApplicationsWithSQLDatabases_SQLServer().ToList();
                if (Proc_ISVApplicationsWithSQLDatabases_SQLServer.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_ISVApplicationsWithSQLDatabases_SQLServer));
                    dt.TableName = "Slide 32_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region SQL Analytical Workload Count
                List<Proc_SQLAnalytical_WorkloadCountResult> Proc_SQLAnalytical_WorkloadCount = service.Proc_SQLAnalytical_WorkloadCount().ToList();
                if (Proc_SQLAnalytical_WorkloadCount.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLAnalytical_WorkloadCount));
                    dt.TableName = "Slide 34_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLAnalytical_SummaryResult> Proc_SQLAnalytical_Summary = service.Proc_SQLAnalytical_Summary().ToList();
                if (Proc_SQLAnalytical_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLAnalytical_Summary));
                    dt.TableName = "Slide 34_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLAnalytical_ComponentVMPriceResult> Proc_SQLAnalytical_ComponentVMPrice = service.Proc_SQLAnalytical_ComponentVMPrice().ToList();
                if (Proc_SQLAnalytical_ComponentVMPrice.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLAnalytical_ComponentVMPrice));
                    dt.TableName = "Slide 34_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Sustainability Report
                List<Proc_SustainabilityReport_SummaryResult> Proc_SustainabilityReport_Summary = service.Proc_SustainabilityReport_Summary().ToList();
                if (Proc_SustainabilityReport_Summary.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_Summary));
                    dt.TableName = "Slide 43_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_SustainabilityReport_CarbonEmissionByVMTypeResult> Proc_SustainabilityReport_CarbonEmissionByVMType = service.Proc_SustainabilityReport_CarbonEmissionByVMType().ToList();
                if (Proc_SustainabilityReport_CarbonEmissionByVMType.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_CarbonEmissionByVMType));
                    dt.TableName = "Slide 43_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_SustainabilityReport_CarbonEmissionByScopeResult> Proc_SustainabilityReport_CarbonEmissionByScope = service.Proc_SustainabilityReport_CarbonEmissionByScope().ToList();
                if (Proc_SustainabilityReport_CarbonEmissionByScope.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_CarbonEmissionByScope));
                    dt.TableName = "Slide 43_3";
                    ds.Tables.Add(dt);
                }
                List<Proc_SustainabilityReport_CarbonReductionResult> Proc_SustainabilityReport_CarbonReduction = service.Proc_SustainabilityReport_CarbonReduction().ToList();
                if (Proc_SustainabilityReport_CarbonReduction.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_CarbonReduction));
                    dt.TableName = "Slide 43_4";
                    ds.Tables.Add(dt);
                }
                //List<Proc_SustainabilityReport_CarbonFootprintResult> Proc_SustainabilityReport_CarbonFootprintLow = service.Proc_SustainabilityReport_CarbonFootprint("Low").ToList();
                //if (Proc_SustainabilityReport_CarbonFootprintLow.Count >= 0)
                //{
                //    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_CarbonFootprintLow));
                //    dt.TableName = "Slide 44_1";
                //    ds.Tables.Add(dt);
                //}
                List<Proc_SustainabilityReport_CarbonFootprintResult> Proc_SustainabilityReport_CarbonFootprintMedium = service.Proc_SustainabilityReport_CarbonFootprint("Medium").ToList();
                if (Proc_SustainabilityReport_CarbonFootprintMedium.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_CarbonFootprintMedium));
                    dt.TableName = "Slide 44_2";
                    ds.Tables.Add(dt);
                }
                //List<Proc_SustainabilityReport_CarbonFootprintResult> Proc_SustainabilityReport_CarbonFootprintHigh = service.Proc_SustainabilityReport_CarbonFootprint("High").ToList();
                //if (Proc_SustainabilityReport_CarbonFootprintHigh.Count >= 0)
                //{
                //    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SustainabilityReport_CarbonFootprintHigh));
                //    dt.TableName = "Slide 44_3";
                //    ds.Tables.Add(dt);
                //}
                #endregion

                #region SQL Server Core And Cost Calculations
                List<Proc_SQLServerCoreAndCostCalculations_WindowsServerLicenseResult> Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense = service.Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense().ToList();
                if (Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerCoreAndCostCalculations_WindowsServerLicense));
                    dt.TableName = "Slide 61_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLServerCoreAndCostCalculations_SQLServerLicenseResult> Proc_SQLServerCoreAndCostCalculations_SQLServerLicense = service.Proc_SQLServerCoreAndCostCalculations_SQLServerLicense().ToList();
                if (Proc_SQLServerCoreAndCostCalculations_SQLServerLicense.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerCoreAndCostCalculations_SQLServerLicense));
                    dt.TableName = "Slide 61_2";
                    ds.Tables.Add(dt);
                }
                List<Proc_SQLServerCoreAndCostCalculations_DatabaseCostResult> Proc_SQLServerCoreAndCostCalculations_DatabaseCost = service.Proc_SQLServerCoreAndCostCalculations_DatabaseCost().ToList();
                if (Proc_SQLServerCoreAndCostCalculations_DatabaseCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_SQLServerCoreAndCostCalculations_DatabaseCost));
                    dt.TableName = "Slide 61_3";
                    ds.Tables.Add(dt);
                }
                #endregion

                #region Windows Server Core And Cost Calculations
                List<Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicenseResult> Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense = service.Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense().ToList();
                if (Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsServerCoreAndCostCalculation_WindowsServerLicense));
                    dt.TableName = "Slide 62_1";
                    ds.Tables.Add(dt);
                }
                List<Proc_WindowsServerCoreAndCostCalculation_WindowsCostResult> Proc_WindowsServerCoreAndCostCalculation_WindowsCost = service.Proc_WindowsServerCoreAndCostCalculation_WindowsCost().ToList();
                if (Proc_WindowsServerCoreAndCostCalculation_WindowsCost.Count >= 0)
                {
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Proc_WindowsServerCoreAndCostCalculation_WindowsCost));
                    dt.TableName = "Slide 62_2";
                    ds.Tables.Add(dt);
                }
                #endregion
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return ds;
        }

        //Application Details
        protected void LinkButtonAppDetails_Click(object sender, EventArgs e)
        {
            try
            {
                CreateApplicationDataExcelFile();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        void CreateApplicationDataExcelFile()
        {
            try
            {
                #region DataTables
                DataTable ApplicationDetails_Custom = new DataTable();
                DataTable ApplicationDetails_ISV = new DataTable();
                #endregion

                using (ExcelPackage xp = new ExcelPackage())
                {
                    BoomRangReportService service = new BoomRangReportService(Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString()), _DBName, CurrencyMode, Region);

                    List<Proc_GetApplicationDetailsResult> listApplicationDetails_Custom = service.Proc_GetApplicationDetails("CustomApp");
                    List<Proc_GetApplicationDetailsResult> listApplicationDetails_ISV = service.Proc_GetApplicationDetails("ISV_App");

                    if (listApplicationDetails_Custom != null && listApplicationDetails_Custom.Count > 0)
                    {
                        ApplicationDetails_Custom = Proc_ApplicationDetailsResultDataTable(listApplicationDetails_Custom);
                    }
                    if (listApplicationDetails_ISV != null && listApplicationDetails_ISV.Count > 0)
                    {
                        ApplicationDetails_ISV = Proc_ApplicationDetailsResultDataTable(listApplicationDetails_ISV);
                    }

                    ExcelWorksheet ws;
                    bool isDataAvailable = false;
                    if (ApplicationDetails_Custom.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("Custom Applications");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(ApplicationDetails_Custom, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, ApplicationDetails_Custom.Columns.Count, ApplicationDetails_Custom.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }
                    if (ApplicationDetails_ISV.Rows.Count != 0)
                    {
                        ws = xp.Workbook.Worksheets.Add("ISV Applications");
                        ws.Cells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        ws.Cells.Style.Fill.BackgroundColor.SetColor(Color.White);
                        ws.Cells.Style.Font.SetFromFont(new Font("Calibri", 11));
                        ws.Cells[1, 1].LoadFromDataTable(ApplicationDetails_ISV, true);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[ws.Dimension.Address].Style.WrapText = true;
                        ExcelDesignDB(ws, ApplicationDetails_ISV.Columns.Count, ApplicationDetails_ISV.Rows.Count, 1, 1);
                        isDataAvailable = true;
                    }

                    if (!isDataAvailable) ws = xp.Workbook.Worksheets.Add("No Custom or ISV Applications");

                    Response.AddHeader("content-disposition", "attachment;filename=" + InventoryName + "_" + "HBCApplicationDetails.xlsx");
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.BinaryWrite(xp.GetAsByteArray());
                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                                                                               //Response.End();
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
       
        //SQL 2012 and Prior v1.0
        protected void LinkButtonSql2012_Click(object sender, EventArgs e)
        {
            try
            {
                CreateSql2012Data();
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        void CreateSql2012Data()
        {
            try
            {
                #region DataTables
                DataTable DataTableCustomappsMI = new DataTable();
                DataTable DataTableSQL_2012_MI=new DataTable();
                DataTable DataTableISVappVM = new DataTable();
                DataTable DataTableSQL_2012_VM=new DataTable();
                #endregion

                using (ExcelPackage xp = new ExcelPackage())
                {
                    BoomRangReportService service = new BoomRangReportService(Convert.ToString(Helper.SQLHelper.UCBoomRangConnectionString()), _DBName, CurrencyMode, Region);

                    List<Proc_CustomappsMIResult> Sp_Proc_CustomappsMI = service.Sp_Proc_CustomappsMI();
                    List<Proc_SQL_2012_MIResult> Sp_Proc_SQL_2012_MI = service.Sp_Proc_SQL_2012_MI();
                    List<Proc_ISVappVMResult> Sp_Proc_ISVappVM = service.Sp_Proc_ISVappVM();
                    List<Proc_SQL_2012_VMResult> Sp_Proc_SQL_2012_VM = service.Sp_Proc_SQL_2012_VM();
                    if (Sp_Proc_CustomappsMI.Count >= 0)
                    {
                        DataTableCustomappsMI = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Sp_Proc_CustomappsMI));
                    }
                    if (Sp_Proc_SQL_2012_MI.Count >= 0)
                    {
                        DataTableSQL_2012_MI = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Sp_Proc_SQL_2012_MI));
                    }
                    if (Sp_Proc_ISVappVM.Count >= 0)
                    {
                        DataTableISVappVM = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Sp_Proc_ISVappVM));
                    }
                    if (Sp_Proc_SQL_2012_VM.Count >= 0)
                    {
                        DataTableSQL_2012_VM = JsonConvert.DeserializeObject<DataTable>(JsonConvert.SerializeObject(Sp_Proc_SQL_2012_VM));
                    }

                    ExcelWorksheet ws;

                    ws = xp.Workbook.Worksheets.Add("SQL 2012 and Prior");
                    bool isDataAvailable = false;
                    if (DataTableCustomappsMI.Rows.Count != 0)
                    {
                        ws.Cells[14, 2].Value = "# SQL Server 2012 and Prior:";
                        ws.Cells[15, 2].Value = "#DB:";
                        ws.Cells[14, 3].Value = Convert.ToInt32(DataTableCustomappsMI.Rows[0].ItemArray[0]);
                        ws.Cells[15, 3].Value = Convert.ToInt32(DataTableCustomappsMI.Rows[1].ItemArray[0]);
                        ws.Cells[14, 3, 15, 3].Style.Font.Color.SetColor(Color.Blue);
                        ws.Cells[14, 2, 15, 3].Style.Font.Bold = true;
                        isDataAvailable = true;
                    }
                    if (DataTableSQL_2012_MI.Rows.Count != 0)
                    {
                        ws.Cells[13, 4].LoadFromDataTable(DataTableSQL_2012_MI, true);
                        ExcelDesign(ws, DataTableSQL_2012_MI.Columns.Count, DataTableSQL_2012_MI.Rows.Count, 13, 4);
                        CurrencyFormatDesign(ws, DataTableSQL_2012_MI.Columns.Count, DataTableSQL_2012_MI.Rows.Count+1, 14, 4);
                        ws.Cells[17, 4].Value = "Total Annual Cost";
                        ws.Cells[17, 4].Style.Font.Bold = true;
                        ws.Cells[17, 4].Style.Font.Color.SetColor(Color.Black);
                        ws.Cells[17, 5].Formula = "=SUM(E14:E16)";
                        ws.Cells[17, 6].Formula = "=SUM(F14:F16)";
                        ws.Cells[17, 7].Formula = "=SUM(G14:G16)";
                        ws.Cells[17, 8].Formula = "=SUM(H14:H16)";

                        isDataAvailable = true;
                    }
                    if (DataTableISVappVM.Rows.Count != 0)
                    {
                        ws.Cells[5, 2].Value = "# SQL Server 2012 and Prior:";
                        ws.Cells[6, 2].Value = "#DB:";
                        ws.Cells[5, 3].Value = Convert.ToInt32(DataTableISVappVM.Rows[0].ItemArray[0]);
                        ws.Cells[6, 3].Value = Convert.ToInt32(DataTableISVappVM.Rows[1].ItemArray[0]);
                        ws.Cells[5, 3, 6, 3].Style.Font.Color.SetColor(Color.Blue);
                        ws.Cells[5, 2, 6, 3].Style.Font.Bold = true;

                        isDataAvailable = true;
                    }
                    if (DataTableSQL_2012_VM.Rows.Count != 0)
                    {
                        ws.Cells[4, 4].LoadFromDataTable(DataTableSQL_2012_VM, true);
                        ExcelDesign(ws, DataTableSQL_2012_VM.Columns.Count, DataTableSQL_2012_VM.Rows.Count, 4, 4);
                        CurrencyFormatDesign(ws, DataTableSQL_2012_VM.Columns.Count, DataTableSQL_2012_VM.Rows.Count + 1, 5, 5);
                        ws.Cells[ws.Dimension.Address].AutoFitColumns();
                        ws.Cells[8, 4].Value = "Total Annual Cost";
                        ws.Cells[8, 4].Style.Font.Bold = true;
                        ws.Cells[8, 4].Style.Font.Color.SetColor(Color.Black);
                        ws.Cells[8, 5].Formula = "=SUM(E5:E7)";
                        ws.Cells[8, 6].Formula = "=SUM(F5:F7)";
                        ws.Cells[8, 7].Formula = "=SUM(G5:G7)";
                        ws.Cells[8, 8].Formula = "=SUM(H5:H7)";                       
                        isDataAvailable = true;
                    }
                    

                    Response.AddHeader("content-disposition", "attachment;filename=" + InventoryName + "_" + "SQL_2012_and_Priorv1.0.xlsx");
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.BinaryWrite(xp.GetAsByteArray());
                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                                                                               //Response.End();
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }
        public DataTable Proc_ApplicationDetailsResultDataTable(List<Proc_GetApplicationDetailsResult> Proc_ApplicationDetails)
        {
            #region Datatable
            DataTable dt = new DataTable();
            dt.Columns.Add("Device State", typeof(string));
            dt.Columns.Add("Device Name", typeof(string));
            dt.Columns.Add("Software Publisher", typeof(string));
            dt.Columns.Add("Product Name", typeof(string));
            dt.Columns.Add("Version", typeof(string));
            dt.Columns.Add("Install Date", typeof(string));
            dt.Columns.Add("Preferred User", typeof(string));

            #endregion
            foreach (var item in Proc_ApplicationDetails)
            {
                dt.Rows.Add(
                    string.IsNullOrEmpty(item.Device_State) ? "-" : item.Device_State,
                    string.IsNullOrEmpty(item.Device_Name) ? "-" : item.Device_Name,
                    string.IsNullOrEmpty(item.Software_Publisher) ? "-" : item.Software_Publisher,
                    string.IsNullOrEmpty(item.Product_Name) ? "-" : item.Product_Name,
                    string.IsNullOrEmpty(item.Version) ? "-" : item.Version,
                    string.IsNullOrEmpty(item.Install_Date) ? "-" : item.Install_Date,
                    string.IsNullOrEmpty(item.Preferred_User) ? "-" : item.Preferred_User
                    );
            }

            return dt;
        }
    }
}