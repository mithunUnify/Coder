﻿using DecryptionCode;
using Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Services;
using System.Web.UI.WebControls;
using UCCloudRecon.TCOInfrastructure;
using UCCloudRecon.TCOInfrastructure.Abstract;
using UCCloudRecon.TCOInfrastructure.DTO;
using UCCloudReconDAL;
using UCCloudReconDTO;
using UCCloudReconService;
using UCMAPDTO;
using UCMAPService;

namespace UCCloudRecon
{
    public partial class TCOCalculator : System.Web.UI.Page
    {
        public static string _ServerName = "";
        public static string _DBName = "";
        public static string _Region = "";
        public static int DBID = 0;
        public static int UserID = 0;
        List<TestFileDTO> TestFileDTOs;
        private Stream filePath;

        protected void Page_Load(object sender, EventArgs e)
        {
           
            try
            {
                if (Session["UserMID"] == null)
                {
                    Session.Clear();
                    Session.Abandon();
                    Response.Redirect("LoginPopup.aspx");
                }

                if (Session["DBID"] != null)
                {
                    DBID = Convert.ToInt32(Session["DBID"]);


                    int UserID = (int)Session["UserMID"];


                    TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(DBID));
                    if (TestFileDTOs.Count > 0)
                    {
                        _DBName = TestFileDTOs.Where(s => s.FileID == DBID).ToList()[0].DbName;
                        _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                        Session["_DBName"] = _DBName;
                        Session["_ServerName"] = _ServerName;
                    }


                }

            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }


        }

        [WebMethod]
        public static List<Sp_GetReconLiftandShift_InputDataNewResult> ReconLiftandShift_InputData()
        {
            List<Sp_GetReconLiftandShift_InputDataNewResult> data = null;
            string CurrencyMode = string.Empty; ;
            if (HttpContext.Current.Session["Currency"] != null)
                CurrencyMode = HttpContext.Current.Session["Currency"].ToString().Substring(4);
            else
                CurrencyMode = Convert.ToString(ConfigurationManager.AppSettings["DefaultCurrency"]);
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            try
            {
                data = service.GetReconLiftandShift_InputData(CurrencyMode);
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }

        [WebMethod(EnableSession = false)]
        public static AssumptionsViewModel GetAssumptions()
        {
            AssumptionsViewModel data = null;
            if (HttpContext.Current.Session["DBID"] == null)
            {
                return null;
            }
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            IAssumptions assumptions = new Assumption(service);
            try
            {
                data = assumptions.GetAssumptions();
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }

        public AssumptionsViewModel GetAssumptions1(string _ServerName, string _DBName)
        {
            AssumptionsViewModel data = null;
            if (HttpContext.Current.Session["DBID"] == null)
            {
                return null;
            }
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            IAssumptions assumptions = new Assumption(service);
            try
            {
                data = assumptions.GetAssumptions();
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }

        [WebMethod(EnableSession = false)]
        public static WorkloadDTO GetWorkLoads()

        {
            WorkloadDTO workDtoRes = new WorkloadDTO();
            if (HttpContext.Current.Session["DBID"] != null)
            {
                List<TestFileDTO> TestFileDTOs = new TestFileMasterService().GetFileByDBID(Convert.ToInt32(HttpContext.Current.Session["DBID"]));
                _DBName = TestFileDTOs.Where(s => s.FileID == Convert.ToInt32(HttpContext.Current.Session["DBID"])).ToList()[0].DbName;
                _ServerName = Convert.ToString(Helper.SQLHelper.GetServerName());
                _Region = HttpContext.Current.Session["Region"].ToString();
                string CurrencyMode = string.Empty; ;
                if (HttpContext.Current.Session["Currency"] != null)
                    CurrencyMode = HttpContext.Current.Session["Currency"].ToString();
                else
                    CurrencyMode = Convert.ToString(ConfigurationManager.AppSettings["DefaultCurrency"]);

                try
                {
                    TCOReportService service = new TCOReportService(_ServerName, _DBName);
                    var DiscountStatus = 0;
                    int DBID = Convert.ToInt32(HttpContext.Current.Session["DBID"]);

                    StringCipher objStringCipher = new StringCipher();
                    string test = "";
                    string Currencyname = "";
                    var data = service.get_Tbl_Save_OnPremises_Azure_data();
                    if (data.Count > 0)
                    {
                        //var AssumSavedata = service.GetDatabaseCost();
                        //var Assumdata = service.GetDatabaseCostAssumption();
                        //var currencyrate = service.GetCurrencyRate(CurrencyMode);
                        //var currencyvalue = service.GetCurrencyAssumption();
                        //decimal? currencyratevalue = (AssumSavedata[0].Cost / Assumdata[0].Cost);
                        //decimal? ratevalue = Convert.ToDecimal(String.Format("{0:0.00}", currencyratevalue));
                        //Assumdata[0].Cost = Convert.ToDecimal(Assumdata[0].Cost * currencyrate[0].Rate);
                        //int val2 = Convert.ToInt32(Assumdata[0].Cost);

                        var mastervalues = service.get_MasterData();
                        if (mastervalues.Count() > 0)
                        {
                            if (mastervalues[0].currency != null)
                            {
                                if (mastervalues[0].currency != CurrencyMode)
                                {
                                    Currencyname = mastervalues[0].currency;
                                    test = "No";
                                }

                            }
                            //else if (mastervalues[0].currency == null && mastervalues.Count() > 0)
                            //{
                            //    decimal? rate = 0;
                            //    foreach (var item in currencyvalue)
                            //    {
                            //        rate = Convert.ToDecimal(String.Format("{0:0.00}", item.Rate));
                            //        if (rate == ratevalue)
                            //        {
                            //            Currencyname = item.ToCur;
                            //        }
                            //    }
                            //    test = "No";
                            //}
                        }

                    }
                    workDtoRes = new WorkloadDTO
                    {
                        workload = service.GetWorkLoadDetailWithCount().Select(x => new WorkLoadDetailDTO
                        {
                            Name = HttpContext.Current.Session["EncryptionPassword"] != null ? IsEncrypted(x.ComputerName) == true ? objStringCipher.Decrypt(x.ComputerName, Convert.ToString(HttpContext.Current.Session["EncryptionPassword"])) : x.ComputerName : x.ComputerName,
                            Environment = x.Environment,
                            Core = Convert.ToInt32(x.NumberOfCores),
                            CorePerProc = x.NumberOfCores,
                            Ram = x.RamIn_GB_,
                            GPU = x.GPU,
                            isVm = x.Environment.Contains("physical") ? false : true,
                            Optimizeby = x.Optimizeby,
                            OS = x.OperatingSystem.ToLower(),
                            ProcPerServer = x.NumberOfProcessors,
                            Servers = x.Servers,
                            Virtualization = "vmware",
                            Vms = x.Vms,
                            UsedStorage = x.UsedSotrage,
                            Workload = x.MachineType,
                            CurrentOS = x.CurrentOperatingSystem,
                            BizTalkMachine = x.BizTalkMachine,
                            LicenseType = x.LicenseType,
                            EnvType = x.EnvType
                        }).ToList(),
                        HostMachineDetail = service.GetHostMachineDetail(),
                        ReconLiftandShiftSqlLicenseCost = service.GetReconLiftandShiftSqlLicenseCost(CurrencyMode),
                        tbl_DatabaseDetail = service.GetDatabaseDetail(),
                        SoftwareCostAssumption = service.getSoftwareCostAssumptions(),
                        tbl_StorageDetail = service.GetStorageDetailsAsync(),
                        ReconLiftandShift_InputData = service.GetReconLiftandShift_InputData(CurrencyMode),
                        ReconLiftandShift_ManagedDisk = service.GetReconLiftandShift_ManagedDisk(),
                        ReconLiftandShift_BackUpStorage = service.GetReconLiftandShift_BackUpStorage(),
                        Recon_OracleToPostgreData = service.Sp_GetRecon_OracleToPostgreData(CurrencyMode),
                        ReconLiftShift_MLSData = service.GetReconLiftShift_MLSData(CurrencyMode, "sizingonutil"),
                        //SQLSizing_SqlAzureDB = service.GetSQLSizing_SqlAzureDB().Where(x => x.IsThirdPartyDatabase == false).ToList(),
                        Tbl_BenchmarkPricing = service.getBanchMarkPricing(),
                        // CostOfEndPointProtection = service.GetCostOfEndPointProtection(),
                        SQLServerAssumption = service.GetSQLServerAssumptionAsync(),
                        Tbl_StorageCostAssumption = service.GetTbl_StorageCostAssumption(),
                        vw_CountVMOnPhysicalServer = service.Getvw_CountVMOnPhysicalServer(),
                        vw_SQLVersionLicenseDetail = service.Getvw_SQLVersionLicenseDetail(),
                        vw_OracleVersionLicenseDetail = service.Getvw_OracleVersionLicenseDetail(),
                        vw_AzureOracleCost = service.GetAzureOracleCost(),
                        Recon_SQLManagedInstanceSummary = service.GetRecon_SQLManagedInstanceSummary(),
                        Recon_SQLSizingSummary = service.GetRecon_SQLSizingSummary().Where(x => x.AzureServiceName == "SQL Azure DB" && x.UtilMeasure == "Avg").ToList(),
                        SqlSizingPricingData = service.getSqlSizingPricingData(CurrencyMode),
                        CurrencyTable = service.GetCurrency("USD_" + CurrencyMode),
                        DiscountStatus = DiscountStatus,
                        DBID = DBID,
                        Tbl_Save_physicalserver = service.get_Tbl_Save_physicalserver(),
                        Tbl_Save_DatabaseDetail = service.get_DatabaseCalculationRequire(),
                        Tbl_Save_SqlVersionLicense = service.get_SqlVersionLicenseRequire(),
                        Tbl_Save_StorageData = service.get_StorageDataRequire(),
                        Tbl_Save_Mastervalue = service.get_MasterData(),
                        Tbl_Save_MigrationData = service.Get_MigrationSaveData(),
                        Tbl_Save_OnPremises_Azure_data = service.get_Tbl_Save_OnPremises_Azure_data(),
                        Tbl_Save_RentingBenefit = service.Get_RentingBenefitsSaveData("Tbl_Save_RentingBenefit"),
                        CurrencyValue = test,
                        CurrencyName = Currencyname
                    };
                    #region [Decrpyt Field]
                    try
                    {


                        if (workDtoRes.tbl_DatabaseDetail.Count() > 0)
                        {
                            if (HttpContext.Current.Session["EncryptionPassword"] != null)
                            {
                                workDtoRes.tbl_DatabaseDetail.ForEach(item =>
                                {
                                    if (item.ComputerName != null)
                                    {
                                        // For Computer Name
                                        if (IsEncrypted(item.ComputerName.ToString()))
                                        {

                                            item.ComputerName = objStringCipher.Decrypt(item.ComputerName, Convert.ToString(HttpContext.Current.Session["EncryptionPassword"]));
                                        }
                                    }
                                });
                            }
                        }
                    }
                    catch { }
                    #endregion [Decrpyt Field]

                }

                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }

                }

                return workDtoRes;
            }
            else
            {
                return workDtoRes;
            }
        }

        [WebMethod(EnableSession = false)]
        public static List<ReconLiftandShift_OthersServicesCost> GetNetworkingCost()
        {
            List<ReconLiftandShift_OthersServicesCost> lstnetWork = null;
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            try
            {
                int DBID = Convert.ToInt32(HttpContext.Current.Session["DBID"]);
                if (DBID > 0)
                {
                    var backUpCost = GetBackupCost();
                    lstnetWork = service.ReconLiftandShift_OthersServicesCost();
                    foreach (var item in lstnetWork)
                    {
                        if (item.Components == "Production_Management and Governance_Backup" && item.Price == null)
                        {
                            double price = 37187.24;
                            if (DBID == 41209)
                                item.Price = Convert.ToDecimal(price);
                            else
                            {
                                item.Price = backUpCost;
                            }
                        }
                    }
                }
                return lstnetWork;
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return lstnetWork;
        }
        /// <summary>
        /// Get Azure GetBackupCost.
        /// </summary>
        /// <returns></returns>

        private static decimal GetBackupCost()
        {
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            try
            {
                service.ReconLiftandShift_BackupsCost();
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return service.ReconLiftandShift_BackupsCost();
        }

        [WebMethod(EnableSession = false)]
        public static List<vw_DatabaseDetail> GetDatabaseDetails()
        {
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            try
            {

                service.GetDatabaseDetail().Where(x => x.Cores != null).ToList();
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }

            return service.GetDatabaseDetail().Where(x => x.Cores != null).ToList();
        }

        [WebMethod(EnableSession = false)]
        public static List<vw_OnpremisesStorageDetail> GetStorageDetails()
        {
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            try
            {
                service.GetStorageDetailsAsync();
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return service.GetStorageDetailsAsync();
        }

        public static bool IsFileinUse(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }
            return false;
        }

        [WebMethod(EnableSession = false)]
        public static string saveAssumption(PhysicalServerDTO phy, List<vw_DatabaseDetail> Datab1, List<SQLVersionLicenseDetail> SQLVersionLicenseDetail1, List<WorkLoadDetailDTO2> StorageSave, List<RentingBenifitsDTO> YearCostDetail, List<Migration> Migration, List<CashFlowDTO> CashFlow, AssumptionsViewModel Assumptions, List<softCostAssumptionDTO> SoftwareCostAssumption, List<CostCalculationOfYearDetailDTO> SaveYearCostDetails, masterDataDTO MasterData)
        {
            string Currency = string.Empty;
            if (HttpContext.Current.Session["Currency"] != null)
                Currency = HttpContext.Current.Session["Currency"].ToString();
            else
                Currency = Convert.ToString(ConfigurationManager.AppSettings["DefaultCurrency"]);

            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            var ResetStatus = service.ResetCostInDB();
            service.Save_PhysicalServerData(phy.ServerModelList);
            service.Save_Database(SQLVersionLicenseDetail1, Datab1);
            object lst = StorageSave.Where(x => x.Environment == "physicalserver").Select(x => new { x.Name, x.UsedStorage }).ToList();
            service.Save_StorageData(StorageSave.Where(x => x.Environment == "physicalserver").Select(x => new WorkLoadCustomDTO { Name = x.Name, UsedStorage = x.UsedStorage }).ToList());
            service.Save_benefitData(YearCostDetail);
            service.Save_MigrationData(Migration);
            CashFlowDTO cashFlow_Obj = new CashFlowDTO();
            #region Create CashFlow Object
            List<Payback> lstobj = new List<Payback>();
            foreach (var item in CashFlow)
            {
                Payback newobj1 = new Payback();
                newobj1.Type = item.Type;
                newobj1.OneYear = item.BenefitsRealizedRate0;
                newobj1.TwoYear = item.BenefitsRealizedRate1;
                newobj1.ThreeYear = item.BenefitsRealizedRate2;
                newobj1.FourYear = item.BenefitsRealizedRate3;
                newobj1.FiveYear = item.BenefitsRealizedRate4;
                lstobj.Add(newobj1);
            }
            foreach (var item in CashFlow[0].Undiscounted_Cash_Flows)
            {
                Payback newobj2 = new Payback();
                newobj2.Type = item.Type;
                newobj2.OneYear = item.OneYear;
                newobj2.TwoYear = item.TwoYear;
                newobj2.ThreeYear = item.ThreeYear;
                newobj2.FourYear = item.FourYear;
                newobj2.FiveYear = item.FiveYear;
                lstobj.Add(newobj2);
            }
            foreach (var item in CashFlow[0].Discounted_Cash_Flows)
            {
                Payback newobj3 = new Payback();
                newobj3.Type = item.Type;
                newobj3.OneYear = item.OneYear;
                newobj3.TwoYear = item.TwoYear;
                newobj3.ThreeYear = item.ThreeYear;
                newobj3.FourYear = item.FourYear;
                newobj3.FiveYear = item.FiveYear;
                lstobj.Add(newobj3);
            }
            foreach (var item in CashFlow[0].Payback)
            {
                Payback newobj4 = new Payback();
                newobj4.Type = item.Type;
                newobj4.OneYear = item.OneYear;
                newobj4.TwoYear = item.TwoYear;
                newobj4.ThreeYear = item.ThreeYear;
                newobj4.FourYear = item.FourYear;
                newobj4.FiveYear = item.FiveYear;
                lstobj.Add(newobj4);
            }
            foreach (var item in CashFlow)
            {
                Payback newobj5 = new Payback();
                newobj5.Type = "Cost Of Capital(%)";
                newobj5.OneYear = item.CapitalCost;
                lstobj.Add(newobj5);
            }
            foreach (var item in CashFlow)
            {
                Payback newobj6 = new Payback();
                newobj6.Type = "Total VM Moved To Cloud";
                newobj6.OneYear = item.TotalVM;
                lstobj.Add(newobj6);
            }
            foreach (var item in CashFlow)
            {
                Payback newobj7 = new Payback();
                newobj7.Type = "PaybackYearsFraction";
                newobj7.OneYear = item.PaybackYearsFraction;
                lstobj.Add(newobj7);
            }
            foreach (var item in CashFlow)
            {
                Payback newobj8 = new Payback();
                newobj8.Type = "PaybackYears";
                newobj8.OneYear = item.PaybackYears;
                lstobj.Add(newobj8);
            }
            foreach (var item in CashFlow)
            {
                Payback newobj9 = new Payback();
                newobj9.Type = "TCO";
                newobj9.OneYear = item.TCO;
                lstobj.Add(newobj9);
            }
            Payback newobj10 = new Payback();
            newobj10.Type = "IRR";
            newobj10.OneYear = CashFlow[0].IRR;
            lstobj.Add(newobj10);
            Payback newobj11 = new Payback();
            newobj11.Type = "NPV";
            newobj11.OneYear = CashFlow[0].NPV;
            lstobj.Add(newobj11);
            #endregion
            service.Save_CashFlowData(lstobj);
            service.Save_AssumptionData(Assumptions, Currency, SoftwareCostAssumption, Convert.ToInt32(Migration[7].value));

            List<CostCalculationOfYearDTO> SaveYearCostDetailsList = new List<CostCalculationOfYearDTO>();
            int j = 0;
            for (int i = 0; i < Convert.ToInt32(MasterData.years); i++)
            {
                for (int r = 0; r <= 13; r++)  //compute year 1
                {
                    CostCalculationOfYearDTO Onpre = new CostCalculationOfYearDTO
                    {
                        OnPremise = SaveYearCostDetails[0 + j].SubItems[r].OnPremise.ToString(),
                        Azure = SaveYearCostDetails[0 + j].SubItems[r].Azure.ToString(),
                        Type = SaveYearCostDetails[0 + j].SubItems[r].Type.ToString(),
                        Year = SaveYearCostDetails[0 + j].SubItems[r].Year.ToString(),
                        DCModel = "Renting"
                    };
                    SaveYearCostDetailsList.Add(Onpre);
                }
                CostCalculationOfYearDTO Onpre1 = new CostCalculationOfYearDTO
                {
                    OnPremise = SaveYearCostDetails[1 + j].OnPremise.ToString(),
                    Azure = SaveYearCostDetails[1 + j].Azure.ToString(),
                    Type = SaveYearCostDetails[1 + j].Type.ToString(),
                    Year = SaveYearCostDetails[1 + j].Year.ToString(),
                    DCModel = "Renting"
                };
                SaveYearCostDetailsList.Add(Onpre1);
                for (int r = 0; r < 13; r++)  //networking year 1
                {
                    CostCalculationOfYearDTO Onpre2 = new CostCalculationOfYearDTO
                    {
                        OnPremise = SaveYearCostDetails[2 + j].SubItems[r].OnPremise.ToString(),
                        Azure = SaveYearCostDetails[2 + j].SubItems[r].Azure.ToString(),
                        Type = SaveYearCostDetails[2 + j].SubItems[r].Type.ToString(),
                        Year = SaveYearCostDetails[2 + j].Year.ToString(),
                        DCModel = "Renting"
                    };
                    SaveYearCostDetailsList.Add(Onpre2);
                }
                for (int r = 0; r < 3; r++)  //storage year 1
                {
                    CostCalculationOfYearDTO Onpre3 = new CostCalculationOfYearDTO
                    {
                        OnPremise = SaveYearCostDetails[3 + j].SubItems[r].OnPremise.ToString(),
                        Azure = SaveYearCostDetails[3 + j].SubItems[r].Azure.ToString(),
                        Type = SaveYearCostDetails[3 + j].SubItems[r].Type.ToString(),
                        Year = SaveYearCostDetails[3 + j].Year.ToString(),
                        DCModel = "Renting"
                    };
                    SaveYearCostDetailsList.Add(Onpre3);
                }

                CostCalculationOfYearDTO Onpre4 = new CostCalculationOfYearDTO
                {
                    OnPremise = SaveYearCostDetails[4 + j].OnPremise.ToString(),
                    Azure = SaveYearCostDetails[4 + j].Azure.ToString(),
                    Type = SaveYearCostDetails[4 + j].Type.ToString(),
                    Year = SaveYearCostDetails[4 + j].Year.ToString(),
                    DCModel = "Renting"
                };
                SaveYearCostDetailsList.Add(Onpre4);

                j += 5;
            }


            service.SaveCostInDB(SaveYearCostDetailsList, "Tbl_Save_OnPremises_Azure_data");
            service.Save_MasterData(MasterData.sqlType, MasterData.tcoType, MasterData.plan, MasterData.planNew, MasterData.years, MasterData.planPostgre, _Region, Currency);
            return "";
        }
        [WebMethod(EnableSession = false)]
        public static string SaveTCOCostForAIS(List<CostCalculationOfYearDetailDTO> SaveYearCostDetails, masterDataDTO MasterData)
        {
            try
            {
                TCOReportService service = new TCOReportService(_ServerName, _DBName);
                string Currency = "";
                if (HttpContext.Current.Session["Currency"] != null)
                {
                    Currency = string.IsNullOrEmpty(HttpContext.Current.Session["Currency"].ToString()) ?
                        Convert.ToString(ConfigurationManager.AppSettings["DefaultCurrency"]) : HttpContext.Current.Session["Currency"].ToString();
                }
                else
                {
                    Currency = Convert.ToString(ConfigurationManager.AppSettings["DefaultCurrency"]);
                }
                decimal CurrencyRate = service.GetCurrency("USD_" + Currency).Rate;
                List<CostCalculationOfYearDTO> SaveYearCostDetailsList = new List<CostCalculationOfYearDTO>();
                int j = 0;
                for (int i = 0; i < 1; i++)
                {
                    for (int r = 0; r <= 12; r++)  //compute year 1
                    {
                        CostCalculationOfYearDTO Onpre = new CostCalculationOfYearDTO
                        {
                            OnPremise = SaveYearCostDetails[0 + j].SubItems[r].OnPremise.ToString(),
                            Azure = SaveYearCostDetails[0 + j].SubItems[r].Azure.ToString(),
                            Type = SaveYearCostDetails[0 + j].SubItems[r].Type.ToString(),
                            Year = SaveYearCostDetails[0 + j].SubItems[r].Year.ToString(),
                            DCModel = "Compute"
                        };
                        SaveYearCostDetailsList.Add(Onpre);
                    }
                    CostCalculationOfYearDTO Onpre1 = new CostCalculationOfYearDTO
                    {
                        OnPremise = SaveYearCostDetails[1 + j].OnPremise.ToString(),
                        Azure = SaveYearCostDetails[1 + j].Azure.ToString(),
                        Type = SaveYearCostDetails[1 + j].Type.ToString(),
                        Year = SaveYearCostDetails[1 + j].Year.ToString(),
                        DCModel = "Data Center"
                    };
                    SaveYearCostDetailsList.Add(Onpre1);
                    for (int r = 0; r < 13; r++)  //networking year 1
                    {
                        CostCalculationOfYearDTO Onpre2 = new CostCalculationOfYearDTO
                        {
                            OnPremise = SaveYearCostDetails[2 + j].SubItems[r].OnPremise.ToString(),
                            Azure = SaveYearCostDetails[2 + j].SubItems[r].Azure.ToString(),
                            Type = SaveYearCostDetails[2 + j].SubItems[r].Type.ToString(),
                            Year = SaveYearCostDetails[2 + j].Year.ToString(),
                            DCModel = "Networking"
                        };
                        SaveYearCostDetailsList.Add(Onpre2);
                    }
                    for (int r = 0; r < 3; r++)  //storage year 1
                    {
                        CostCalculationOfYearDTO Onpre3 = new CostCalculationOfYearDTO
                        {
                            OnPremise = SaveYearCostDetails[3 + j].SubItems[r].OnPremise.ToString(),
                            Azure = SaveYearCostDetails[3 + j].SubItems[r].Azure.ToString(),
                            Type = SaveYearCostDetails[3 + j].SubItems[r].Type.ToString(),
                            Year = SaveYearCostDetails[3 + j].Year.ToString(),
                            DCModel = "Storage"
                        };
                        SaveYearCostDetailsList.Add(Onpre3);
                    }

                    CostCalculationOfYearDTO Onpre4 = new CostCalculationOfYearDTO
                    {
                        OnPremise = SaveYearCostDetails[4 + j].OnPremise.ToString(),
                        Azure = SaveYearCostDetails[4 + j].Azure.ToString(),
                        Type = SaveYearCostDetails[4 + j].Type.ToString(),
                        Year = SaveYearCostDetails[4 + j].Year.ToString(),
                        DCModel = "IT Labor"
                    };
                    SaveYearCostDetailsList.Add(Onpre4);

                    j += 5;
                }
                service.SaveCostInDBHBC(SaveYearCostDetailsList, "Tbl_Save_OnPremises_data_HBC");
                //service.Save_MasterData(MasterData.sqlType, MasterData.tcoType, MasterData.plan, MasterData.planNew, MasterData.years);

            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return "";
        }

        [WebMethod(EnableSession = false)]
        public static void ResetSaveCost()
        {
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            var ResetStatus = service.ResetCostInDB();
        }
        [WebMethod(EnableSession = false)]
        public static void ResetFilterInDB()
        {
            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            service.ResetFilterInDB();
        }
        public static bool IsEncrypted(string sFiledValue)
        {
            try
            {
                byte[] data = Convert.FromBase64String(sFiledValue);
                return true;
            }
            catch
            {
                return false;
            }
        }
        [WebMethod(EnableSession = false)]
        public static void SaveOnPreEditData(List<EditOnPremisesCostDTO> Editlist)
        {

            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            //var ResetStatus = service.ResetCostInDB();
            service.saveOnPremiseEditData(Editlist);


        }
        [WebMethod(EnableSession = false)]
        public static void SaveAzureEditData(List<EditOnPremisesCostDTO> Editlist)
        {

            TCOReportService service = new TCOReportService(_ServerName, _DBName);
            //var ResetStatus = service.ResetCostInDB();
            service.saveAzureEditData(Editlist);


        }
        [WebMethod(EnableSession = false)]
        public static bool CheckCurrency(string ID)
        {
            int id = Convert.ToInt32(ID);
            try
            {
                var Currency = HttpContext.Current.Session["Currency"].ToString();
                int createdby = Convert.ToInt32(HttpContext.Current.Session["UserMID"]);
                TestFileMasterService objTestFileMasterService = new TestFileMasterService();
                List<CustomerTCOAssumtion> cusassumption = objTestFileMasterService.GetCurrencyName(id);
                var currencyass = cusassumption.Select(s => s.Currency).SingleOrDefault();
                if (currencyass == Currency)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                return false;
            }


        }
    }
}
