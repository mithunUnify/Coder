app.controller('serverController', function ($scope, $http, sampleService, $log) {
    $scope.ServerModelList = [];
    $scope.StorageModelList = [];
    $scope.isVm = false;
    sampleService.serverGrowth = 5;
    sampleService.VMPer = 100;
    sampleService.VMThroughputRate = 25;
    sampleService.CostofCapitalPer = 5.5;
    sampleService.BenefitsRealizedRate0 = 30;
    sampleService.BenefitsRealizedRate1 = 80;
    sampleService.BenefitsRealizedRate2 = 100;
    sampleService.BenefitsRealizedRate3 = 100;
    sampleService.BenefitsRealizedRate4 = 100;
    sampleService.azurePageBlobStorageCost = 0.18;
    sampleService.storageGrowth = 5;
    sampleService.tcoType = "all";
    sampleService.sqlType = '';
    sampleService.loader = true;
    sampleService.IsFilterReset = false;
    sampleService.planPostgre = '';
    $http.post('TCOCalculator.aspx/GetWorkLoads', { data: {} }).then(function (response) {
        $http.post('TCOCalculator.aspx/GetNetworkingCost', { data: {} }).then(function (netres) {
          
            sampleService.AzureNetworkingCost = netres.data.d;
            $scope.ServerModelList = response.data.d.workload;
            sampleService.ServerAssumptions = $scope.ServerModelList;
            sampleService.Tbl_BenchmarkPricing = response.data.d.Tbl_BenchmarkPricing;
            sampleService.SQLSizing_SqlAzureDB = response.data.d.SQLSizing_SqlAzureDB;
            $scope.DatabaseModelList = response.data.d.tbl_DatabaseDetail;
            sampleService.DatabaseAssumptions = $scope.DatabaseModelList;
            $scope.StorageModelList = response.data.d.tbl_StorageDetail;
            sampleService.StorageAssumptions = $scope.StorageModelList;
            sampleService.ReconLiftandShift_InputData = response.data.d.ReconLiftandShift_InputData;
            sampleService.ReconLiftandShift_ManagedDisk = response.data.d.ReconLiftandShift_ManagedDisk;
            sampleService.ReconLiftandShift_BackUpStorage = response.data.d.ReconLiftandShift_BackUpStorage;
            sampleService.ReconLiftShift_MLSData = response.data.d.ReconLiftShift_MLSData;
            sampleService.Recon_OracleToPostgreData = response.data.d.Recon_OracleToPostgreData;
            sampleService.Tbl_OsPricing = response.data.d.Tbl_OsPricing;
            sampleService.SQLServerAssumption = response.data.d.SQLServerAssumption;
           // sampleService.CostOfEndPointProtection = response.data.d.CostOfEndPointProtection;
            sampleService.Tbl_StorageCostAssumption = response.data.d.Tbl_StorageCostAssumption;
            sampleService.vw_CountVMOnPhysicalServer = response.data.d.vw_CountVMOnPhysicalServer;
            //software Cost Assumptions
            sampleService.softCostAssumption = response.data.d.SoftwareCostAssumption;
            sampleService.Load = response.data.d.Servers;
            //
            sampleService.vw_SQLVersionLicenseDetail = response.data.d.vw_SQLVersionLicenseDetail;
            sampleService.vw_OracleVersionLicenseDetail = response.data.d.vw_OracleVersionLicenseDetail;
            sampleService.vw_AzureOracleCost = response.data.d.vw_AzureOracleCost;
            sampleService.Recon_SQLManagedInstanceSummary = response.data.d.Recon_SQLManagedInstanceSummary;
            sampleService.Recon_SQLSizingSummary = response.data.d.Recon_SQLSizingSummary;
            sampleService.SqlSizingPricingData = response.data.d.SqlSizingPricingData;
            sampleService.CurrencyTable = response.data.d.CurrencyTable; sampleService.CurrencyTableTemp = response.data.d.CurrencyTable.Rate;
            sampleService.azurePageBlobStorageCost = (sampleService.azurePageBlobStorageCost * response.data.d.CurrencyTable.Rate).toFixed(2);
            //Tco  Currency  Calculation
            // sampleService.SelectedCurrencyName = response.data.d.CurrencyTable.CurrencyName;
            
            if (response.data.d.Tbl_Save_OnPremises_Azure_data.length > 0 && response.data.d.Tbl_Save_OnPremises_Azure_data[0].SubItems != 'OwnModel') {
                sampleService.IsUserCostSavedStatus = true;
                sampleService.IsRenting = true;
                sampleService.UserCostSavedInDbphysicalserver = response.data.d.Tbl_Save_physicalserver;
                sampleService.vw_SQLVersionLicenseDetail = response.data.d.Tbl_Save_SqlVersionLicense.length > 0 ? response.data.d.Tbl_Save_SqlVersionLicense : sampleService.vw_SQLVersionLicenseDetail;
                sampleService.DatabaseAssumptions = response.data.d.Tbl_Save_DatabaseDetail.length > 0 ? response.data.d.Tbl_Save_DatabaseDetail : sampleService.DatabaseAssumptions;
                sampleService.MigrationStatus = true;
                sampleService.migrationData = response.data.d.Tbl_Save_MigrationData;
                sampleService.SaveStoragedata = response.data.d.Tbl_Save_StorageData.length > 0 ? response.data.d.Tbl_Save_StorageData : sampleService.ServerAssumptions;

                sampleService.IsUserCostSavedStatus1 = true;
                sampleService.UserCostSavedInDb = response.data.d.Tbl_Save_OnPremises_Azure_data;
                sampleService.RentingBenefitsStatus = true;
                sampleService.RentingBenefitsData = response.data.d.Tbl_Save_RentingBenefit;
            }
            else {
                sampleService.IsUserCostSavedStatus1 = false;
                sampleService.RentingBenefitsStatus = false;
                sampleService.IsUserCostSavedStatus = false;
                sampleService.MigrationStatus = false;
                sampleService.IsRenting = false;
            }
            sampleService.IsAzureCostSavedStatus = true;
            if (response.data.d.Tbl_Save_Mastervalue.length > 0 && response.data.d.Tbl_Save_OnPremises_Azure_data[0].SubItems != 'OwnModel') {
                sampleService.CurrencyTable.Rate = 1;
                sampleService.Tbl_Save_Mastervalue = response.data.d.Tbl_Save_Mastervalue[0];
                sampleService.tcoType = sampleService.Tbl_Save_Mastervalue.tcoType;
                sampleService.sqlType = sampleService.Tbl_Save_Mastervalue.sqlType; sampleService.plan = sampleService.Tbl_Save_Mastervalue.plans;
                sampleService.planNew = sampleService.Tbl_Save_Mastervalue.planNew; sampleService.years = sampleService.Tbl_Save_Mastervalue.years;
                sampleService.planNewPostgre = sampleService.Tbl_Save_Mastervalue.planPostgre;
                sampleService.IsFilterReset = response.data.d.Tbl_Save_Mastervalue[0].IsFilterReset;
                if (sampleService.IsFilterReset === true) {
                    sampleService.IsAzureCostSavedStatus = false;
                }
               
            }
            else {
               
                sampleService.tcoType = "all";
                sampleService.sqlType = ''; 
                sampleService.years = "5";
                sampleService.tcoModel = "renting";
            }
            sampleService.loader = false;
            $scope.$broadcast('broadCastDataAgain', {

            });

        }, function (error) {
            sampleService.loader = false;
            $scope.NoData = true;
            $scope.errorMessage = "Lift Shift Data Not Available";

        });

    }, function (error) {
        $scope.loader = false;
        $scope.NoData = true;
        if (error.data.Message.indexOf('dbo.ReconLiftandShift_InputData')!==-1) {
            $scope.errorMessage = "Lift Shift Data Not Available";
        }
        else {
            sampleService.loader = false;
            $scope.NoData = true;
            $scope.errorMessage = "Something went wrong....";
            $log.log(error.data.Message);
        }
    });
   
    sampleService.StorageAssumptions = $scope.StorageModelList;
    
    $scope.ChangeEnvironment = function (element) {

        if ($scope.isVm) {
            $scope.isVm = false;
        }
        else {
            $scope.isVm = true;
        }
    }
    $scope.$on('loadAgain', function (event, data) {
        $http.post('TCOCalculator.aspx/GetWorkLoads', { data: {} }).then(function (response) {
            $http.post('TCOCalculator.aspx/GetNetworkingCost', { data: {} }).then(function (netres) {
                sampleService.AzureNetworkingCost = netres.data.d;
                $scope.ServerModelList = response.data.d.workload;
                sampleService.ServerAssumptions = $scope.ServerModelList;
                sampleService.Tbl_BenchmarkPricing = response.data.d.Tbl_BenchmarkPricing;
                sampleService.SQLSizing_SqlAzureDB = response.data.d.SQLSizing_SqlAzureDB;
                $scope.DatabaseModelList = response.data.d.tbl_DatabaseDetail;
                sampleService.DatabaseAssumptions = $scope.DatabaseModelList;
                $scope.StorageModelList = response.data.d.tbl_StorageDetail;
                sampleService.StorageAssumptions = $scope.StorageModelList;
                sampleService.ReconLiftandShift_InputData = response.data.d.ReconLiftandShift_InputData;
                sampleService.ReconLiftandShift_ManagedDisk = response.data.d.ReconLiftandShift_ManagedDisk;
                sampleService.Tbl_OsPricing = response.data.d.Tbl_OsPricing;
                sampleService.SQLServerAssumption = response.data.d.SQLServerAssumption;
               // sampleService.CostOfEndPointProtection = response.data.d.CostOfEndPointProtection;
                sampleService.Tbl_StorageCostAssumption = response.data.d.Tbl_StorageCostAssumption;
                sampleService.vw_CountVMOnPhysicalServer = response.data.d.vw_CountVMOnPhysicalServer;
                sampleService.SqlSizingPricingData = response.data.d.SqlSizingPricingData;
                //sampleService.CurrencyTable = response.data.d.CurrencyTable;
                
                //software Cost Assumptions
                sampleService.softCostAssumption = response.data.d.SoftwareCostAssumption;
                //
            });

        });
        $scope.$broadcast('broadCastDataAgain', {

        });
    });

});





