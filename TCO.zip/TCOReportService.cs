﻿using Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using UCCloudReconDAL;
using UCCloudReconDTO;
using UCCloudReconService;
using UCMAPDTO;

namespace UCMAPService
{
    public class TCOReportService : ITCOReportService
    {
        string _ConnectionString = "";
        string _ServerName = "";
        string _DBName = "";
        public TCOReportService(string ServerName, string DBName)
        {
            _ServerName = ServerName;
            _DBName = DBName;
            _ConnectionString = SQLHelper.GetDynamicConnectionString(_DBName, _ServerName);
        }
        #region TCO Methods
        public List<Tbl_HardwareCost> GetHardwareCost()
        {
            List<Tbl_HardwareCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_HardwareCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }

        }
        public List<SQLSizing_SqlAzureDB> GetSQLSizing_SqlAzureDB()
        {
            List<SQLSizing_SqlAzureDB> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<SQLSizing_SqlAzureDB>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Tbl_ElectricityCost> GetElectricityCost()
        {
            List<Tbl_ElectricityCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_ElectricityCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_DataCenterCost> GetDataCenterCost()
        {
            List<Tbl_DataCenterCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_DataCenterCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_ITlaborCost> GetItLabourCost()
        {
            List<Tbl_ITlaborCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_ITlaborCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_SoftwareCost> GetSoftwareCost()
        {
            List<Tbl_SoftwareCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_SoftwareCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_StorageCost> GetStorageCost()
        {
            List<Tbl_StorageCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_StorageCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_DatabaseCost> GetDatabaseCost()
        {
            List<Tbl_DatabaseCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_DatabaseCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_OracleDbCost> GetOracleDbCost()
        {
            List<Tbl_OracleDbCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_OracleDbCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_DatabaseCost> GetDatabaseCostAssumption()
        {
            using (UCCloudReconDataContext oAssessorCloudCostDataContext = new UCCloudReconDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                List<Tbl_DatabaseCost> data = new List<Tbl_DatabaseCost>();
                try
                {
                    data = oAssessorCloudCostDataContext.Tbl_DatabaseCosts.ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<CurrentCurrencyRate> GetCurrencyAssumption()
        {
            using (UCCloudReconDataContext context = new UCCloudReconDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                List<CurrentCurrencyRate> data = new List<CurrentCurrencyRate>();
                try
                {
                    data = context.CurrentCurrencyRates.ToList();
                }

                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;

            }
        }
        public List<CurrentCurrencyRate> GetCurrencyRate(string CurrencyName)
        {
            using (UCCloudReconDataContext context = new UCCloudReconDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                List<CurrentCurrencyRate> data = new List<CurrentCurrencyRate>();


                try
                {
                    data = context.CurrentCurrencyRates.Where(x => x.ToCur == CurrencyName).ToList();
                }

                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;

            }
        }
        #endregion
        public List<vw_WorkloadDetail> GetWorkLoadDetail()
        {
            List<vw_WorkloadDetail> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<vw_WorkloadDetail>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Vw_workloadDetailWithVmCount> GetWorkLoadDetailWithCount()
        {
            List<Vw_workloadDetailWithVmCount> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {

                    data = context.GetTable<Vw_workloadDetailWithVmCount>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<HostMachineDetailDTO> GetHostMachineDetail()
        {
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            List<usp_HostMachineDetailResult> data = context.usp_HostMachineDetail().ToList();
            List<HostMachineDetailDTO> result = new List<HostMachineDetailDTO>();
            
            try
            {
                using (context)
                {
                    data.ForEach(row =>
                    {
                        HostMachineDetailDTO obj = new HostMachineDetailDTO();
                        obj.ComputerName = row.ComputerName;
                        obj.VMCount = Convert.ToInt32(row.VMCount);
                        obj.NumberOfProcessors = Convert.ToInt32(row.NumberOfProcessors);
                        obj.NumberOfCores = Convert.ToInt32(row.NumberOfCores);
                        obj.RamInGB = Convert.ToInt32(row.RamInGB);
                        obj.PhysicalCoreNeeded = Convert.ToDouble(row.PhysicalCoreNeeded);
                        obj.TargetProcessor = Convert.ToInt32(row.TargetProcessor);
                        obj.TargetCorePerProcessor = Convert.ToInt32(row.TargetCorePerProcessor);
                        obj.TargetRam = Convert.ToDecimal(row.TargetRam);
                        obj.RackRequired = Convert.ToInt32(row.RackRequired);
                        obj.OperatingSystem = row.OperatingSystem;
                        obj.LicenseType = row.LicenseType;
                        obj.VMType = row.VMType;
                        obj.EnvType = row.EnvType;
                        obj.Optimizeby = row.Optimizeby;
                        result.Add(obj);
                    });
                    return result;
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return result;
        }
        public List<ReconLiftandShiftSqlLicenseCostDTO> GetReconLiftandShiftSqlLicenseCost(string CurrencyMode)
        {
            List<ReconLiftandShiftSqlLicenseCostDTO> result = new List<ReconLiftandShiftSqlLicenseCostDTO>();
            try
            {
                UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
                List<ReconLiftandShift_SqlLicenseCost> data = context.ReconLiftandShift_SqlLicenseCosts.ToList();
                List<ReconLiftandShift_InputData> data1 = context.ReconLiftandShift_InputDatas.ToList();
                result = (from SQLLicenseCost in data
                          join InputData in data1 on SQLLicenseCost.ComputerName equals InputData.ComputerName into sql
                          from InputData2 in sql.Where(x => x.Included == true).ToList()
                          select new ReconLiftandShiftSqlLicenseCostDTO
                          {
                              VmId = SQLLicenseCost.VmId,
                              ComputerName = SQLLicenseCost.ComputerName,
                              SizingType = SQLLicenseCost.SizingType,
                              AzureVmSize = SQLLicenseCost.AzureVmSize,
                              AzureVmDesc = SQLLicenseCost.AzureVmDesc,
                              EnvType = InputData2.Environment,
                              VMType = InputData2.VMType,
                              MonthlyPrice_Payasyougo = (CurrencyMode == "USD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo) :
                                                        (CurrencyMode == "INR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_INR) :
                                                        (CurrencyMode == "EUR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_EUR) :
                                                        (CurrencyMode == "GBP" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_GBP) :
                                                        (CurrencyMode == "AUD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_AUD) :
                                                        (CurrencyMode == "CAD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_CAD) :
                                                        (CurrencyMode == "MYR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_MYR) :
                                                        (CurrencyMode == "KRW" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_KRW) :
                                                        (CurrencyMode == "IDR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_IDR) :
                                                        (CurrencyMode == "NZD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_NZD) :
                                                        (CurrencyMode == "ZAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_ZAR) :
                                                        (CurrencyMode == "SAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_SAR) :
                                                        (CurrencyMode == "JPY" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_JPY) : 0))))))))))))),

                              MonthlyPrice_Payasyougo_Hybrid = (CurrencyMode == "USD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid) :
                                                               (CurrencyMode == "INR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_INR) :
                                                               (CurrencyMode == "EUR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_EUR) :
                                                               (CurrencyMode == "GBP" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_GBP) :
                                                               (CurrencyMode == "AUD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_AUD) :
                                                               (CurrencyMode == "CAD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_CAD) :
                                                               (CurrencyMode == "MYR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_MYR) :
                                                               (CurrencyMode == "KRW" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_KRW) :
                                                               (CurrencyMode == "IDR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_IDR) :
                                                               (CurrencyMode == "NZD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_NZD) :
                                                               (CurrencyMode == "ZAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_ZAR) :
                                                               (CurrencyMode == "SAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_SAR) :
                                                               (CurrencyMode == "JPY" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Payasyougo_Hybrid_JPY) : 0))))))))))))),

                              MonthlyPrice_One_Year = (CurrencyMode == "USD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year) :
                                                       (CurrencyMode == "INR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_INR) :
                                                       (CurrencyMode == "EUR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_EUR) :
                                                       (CurrencyMode == "GBP" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_GBP) :
                                                       (CurrencyMode == "AUD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_AUD) :
                                                       (CurrencyMode == "CAD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_CAD) :
                                                       (CurrencyMode == "MYR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_MYR) :
                                                       (CurrencyMode == "KRW" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_KRW) :
                                                       (CurrencyMode == "IDR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_IDR) :
                                                       (CurrencyMode == "NZD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_NZD) :
                                                       (CurrencyMode == "ZAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_ZAR) :
                                                       (CurrencyMode == "SAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_SAR) :
                                                       (CurrencyMode == "JPY" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_JPY) : 0))))))))))))),

                              MonthlyPrice_One_Year_Hybrid = (CurrencyMode == "USD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid) :
                                                               (CurrencyMode == "INR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_INR) :
                                                               (CurrencyMode == "EUR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_EUR) :
                                                               (CurrencyMode == "GBP" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_GBP) :
                                                               (CurrencyMode == "AUD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_AUD) :
                                                               (CurrencyMode == "CAD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_CAD) :
                                                               (CurrencyMode == "MYR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_MYR) :
                                                               (CurrencyMode == "KRW" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_KRW) :
                                                               (CurrencyMode == "IDR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_IDR) :
                                                               (CurrencyMode == "NZD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_NZD) :
                                                               (CurrencyMode == "ZAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_ZAR) :
                                                               (CurrencyMode == "SAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_SAR) :
                                                               (CurrencyMode == "JPY" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_One_Year_Hybrid_JPY) : 0))))))))))))),

                              MonthlyPrice_Three_Year = (CurrencyMode == "USD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year) :
                                                       (CurrencyMode == "INR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_INR) :
                                                       (CurrencyMode == "EUR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_EUR) :
                                                       (CurrencyMode == "GBP" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_GBP) :
                                                       (CurrencyMode == "AUD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_AUD) :
                                                       (CurrencyMode == "CAD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_CAD) :
                                                       (CurrencyMode == "MYR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_MYR) :
                                                       (CurrencyMode == "KRW" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_KRW) :
                                                       (CurrencyMode == "IDR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_IDR) :
                                                       (CurrencyMode == "NZD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_NZD) :
                                                       (CurrencyMode == "ZAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_ZAR) :
                                                       (CurrencyMode == "SAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_SAR) :
                                                       (CurrencyMode == "JPY" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_JPY) : 0))))))))))))),

                              MonthlyPrice_Three_Year_Hybrid = (CurrencyMode == "USD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid) :
                                                               (CurrencyMode == "INR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_INR) :
                                                               (CurrencyMode == "EUR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_EUR) :
                                                               (CurrencyMode == "GBP" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_GBP) :
                                                               (CurrencyMode == "AUD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_AUD) :
                                                               (CurrencyMode == "CAD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_CAD) :
                                                               (CurrencyMode == "MYR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_MYR) :
                                                               (CurrencyMode == "KRW" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_KRW) :
                                                               (CurrencyMode == "IDR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_IDR) :
                                                               (CurrencyMode == "NZD" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_NZD) :
                                                               (CurrencyMode == "ZAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_ZAR) :
                                                               (CurrencyMode == "SAR" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_SAR) :
                                                               (CurrencyMode == "JPY" ? Convert.ToDecimal(SQLLicenseCost.MonthlyPrice_Three_Year_Hybrid_JPY) : 0))))))))))))),
                          }).Distinct().ToList();

            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return result;
        }
        public List<vw_DatabaseDetail> GetDatabaseDetail()
        {
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            var data = context.GetTable<vw_DatabaseDetail>().ToList();
            try
            {
                using (context)
                {
                    return data;
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<vw_OnpremisesStorageDetail> GetStorageDetailsAsync()
        {
            List<vw_OnpremisesStorageDetail> data = null;

            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<vw_OnpremisesStorageDetail>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Sp_GetReconLiftandShift_InputDataNewResult> GetReconLiftandShift_InputData(string CurrencyMode)
        {
            List<Sp_GetReconLiftandShift_InputDataNewResult> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.Sp_GetReconLiftandShift_InputDataNew(CurrencyMode).Where(x => x.Cores != null).ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public int GetReconLiftandShift_ManagedDisk()
        {
            int data = 0;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<ReconLiftandShift_ManagedDisk>().ToList().Count();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<ReconLiftandShift_BackUpStorage> GetReconLiftandShift_BackUpStorage()
        {
            List<ReconLiftandShift_BackUpStorage> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<ReconLiftandShift_BackUpStorage>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Sp_GetRecon_OracleToPostgreResult> Sp_GetRecon_OracleToPostgreData(string CurrencyMode)
        {
            List<Sp_GetRecon_OracleToPostgreResult> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.Sp_GetRecon_OracleToPostgre(CurrencyMode).ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<ReconLiftandShift_OthersServicesCost> ReconLiftandShift_OthersServicesCost()
        {
            List<ReconLiftandShift_OthersServicesCost> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<ReconLiftandShift_OthersServicesCost>().Where(x => x.Status == true && x.Id != 1 && x.Id != 5 && x.Id != 6 && x.Id != 11 && x.Id != 12 && x.Id != 1 && x.Id != 18 && x.Id != 19 && x.Id != 20).ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        /// <summary>
        /// Get Azure BackupCost
        /// </summary>
        /// <returns></returns> 
        public decimal ReconLiftandShift_BackupsCost()
        {
            decimal TotalBackUpCost = 0;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {

                using (context)
                {
                    decimal AzureBackupCost = context.GetTable<ReconLiftandShift_BackUpStorage>().Sum(t => Convert.ToDecimal(t.AzureBackupCost));
                    decimal StorageMonthlyCost = context.GetTable<ReconLiftandShift_BackUpStorage>().Sum(t => Convert.ToDecimal(t.StorageMonthlyCost));
                    return TotalBackUpCost = AzureBackupCost + StorageMonthlyCost;
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return TotalBackUpCost;
        }
        public List<Tbl_BenchmarkPricing> getBanchMarkPricing()
        {
            List<Tbl_BenchmarkPricing> data = null;
            UCMAPDataContext context = new UCMAPDataContext(SQLHelper.UCCloudReconConnectionString());
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_BenchmarkPricing>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<SoftwareCostAssumption> getSoftwareCostAssumptions()
        {
            List<SoftwareCostAssumption> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<SoftwareCostAssumption>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<SQLServerAssumption> GetSQLServerAssumptionAsync()
        {
            List<SQLServerAssumption> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<SQLServerAssumption>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<CostOfEndPointProtection> GetCostOfEndPointProtection()
        {
            List<CostOfEndPointProtection> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<CostOfEndPointProtection>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Tbl_StorageCostAssumption> GetTbl_StorageCostAssumption()
        {
            List<Tbl_StorageCostAssumption> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_StorageCostAssumption>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<vw_CountVMOnPhysicalServer> Getvw_CountVMOnPhysicalServer()
        {
            List<vw_CountVMOnPhysicalServer> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<vw_CountVMOnPhysicalServer>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<vw_SQLVersionLicenseDetail> Getvw_SQLVersionLicenseDetail()
        {
            List<vw_SQLVersionLicenseDetail> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<vw_SQLVersionLicenseDetail>().Where(w => w.Cores > 0).ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<vw_OracleVersionLicenseDetail> Getvw_OracleVersionLicenseDetail()
        {
            List<vw_OracleVersionLicenseDetail> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<vw_OracleVersionLicenseDetail>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<vw_AzureOracleCost> GetAzureOracleCost()
        {
            List<vw_AzureOracleCost> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<vw_AzureOracleCost>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Recon_SQLManagedInstanceSummary> GetRecon_SQLManagedInstanceSummary()
        {
            List<Recon_SQLManagedInstanceSummary> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Recon_SQLManagedInstanceSummary>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Recon_SQLSizingSummary> GetRecon_SQLSizingSummary()
        {
            List<Recon_SQLSizingSummary> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Recon_SQLSizingSummary>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<SqlSizingPricingData> getSqlSizingPricingData(string CurrencyMode)
        {
            List<SqlSizingPricingData> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<SqlSizingPricingData>().Where(x => x.CurrencyType == CurrencyMode).ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public bool IsCurrencyUpdated(out string command)
        {
            command = string.Empty;
            using (UCMAPDataContext context = new UCMAPDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                var res = context.ExecuteQuery<DateTime>("select top 1 LastUpdate from [CurrentCurrencyRates]").FirstOrDefault();
                if (res.Date.Date == DateTime.MinValue.Date)
                {
                    command = "insert";
                    return false;

                }
                else if (res.Date.Date != DateTime.Now.Date.Date)
                {
                    command = "update";
                    return false;
                }

                else
                {
                    command = "none";
                    return true;
                }
            }
        }
        public void InsertCurrencyUpdates(List<Country> county)
        {
            using (UCMAPDataContext context = new UCMAPDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                foreach (var item in county)
                {
                    string qry = @"insert into CurrentCurrencyRates(CurrencyName,Country,ToCur,Rate,CreatedDate,LastUpdate)
                                            values('" + item.Currency + "','" + item.Name + "','" + item.To + "'," + item.Rate + ",'" + DateTime.Now + "','" + DateTime.Now + "')";
                    context.ExecuteCommand(qry);
                }
            }
        }
        public void UpdateCurrencyUpdates(List<Country> county)
        {
            using (UCMAPDataContext context = new UCMAPDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                foreach (var item in county)
                {
                    context.ExecuteCommand(@"update CurrentCurrencyRates set Rate=" + item.Rate + ",LastUpdate='" + DateTime.Now + "' where CurrencyName='" + item.Currency + "'");
                }
            }
        }
        public CurrencyTable GetCurrency(string CurrencyName)
        {
            using (UCMAPDataContext context = new UCMAPDataContext(Helper.SQLHelper.UCCloudReconConnectionString()))
            {
                try
                {
                    string qry = "select CurrencyName,Country,FromCur,ToCur,Rate from [CurrentCurrencyRates] where CurrencyName='" + CurrencyName + "'";
                    CurrencyTable res = context.ExecuteQuery<CurrencyTable>(qry).FirstOrDefault();
                    return res;
                }
                catch (Exception ex) { throw ex; }

            }
        }
        public List<Tbl_BizTalkLicenseCost> GetBizTalkLicenseCost()
        {
            List<Tbl_BizTalkLicenseCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_BizTalkLicenseCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_MigrationCost> GetMigrationCost()
        {
            List<Tbl_MigrationCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_MigrationCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_EndPointProtection> GetEndPointProtection()
        {
            List<Tbl_EndPointProtection> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_EndPointProtection>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_CostForVirtualizedVM> GetCostForVirtualizedVMs()
        {
            List<Tbl_CostForVirtualizedVM> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_CostForVirtualizedVM>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_ElectricityCost_KW> GetElectricityCost_KW()
        {
            List<Tbl_ElectricityCost_KW> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_ElectricityCost_KW>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }

                }
                return data;
            }
        }
        public List<Tbl_VirtualizationCost> GetVirtualizationCost()
        {
            List<Tbl_VirtualizationCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_VirtualizationCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_DataCenterConstructionCost> GetDataCenterConstructionCost()
        {
            List<Tbl_DataCenterConstructionCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_DataCenterConstructionCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }
        public List<Tbl_NetworkingCost> GetNetworkingCost()
        {
            List<Tbl_NetworkingCost> data = null;
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                try
                {
                    data = context.GetTable<Tbl_NetworkingCost>().ToList();
                }
                catch (Exception ex)
                {
                    double DBID = 0;
                    string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                           "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                return data;
            }
        }

        //public string Save_MasterData(string sqlType, string tcoType, string plan, string planNew, string years, string planPostgre, string Currency)
        //{

        //    SqlConnection con = new SqlConnection(_ConnectionString);
        //    using (con)
        //    {
        //        SqlCommand cmd = new SqlCommand("truncate table Tbl_Save_Mastervalues", con);
        //        SqlCommand cmd1 = new SqlCommand("insert into Tbl_Save_Mastervalues (sqlType,tcoType,plans,planNew,years,planPostgre,dataStatus) values ('" + sqlType + "','" + tcoType + "','" + plan + "','" + planNew + "','" + years + "','" + planPostgre + "',1)", con);               
        //        con.Open();
        //        cmd.ExecuteNonQuery();
        //        cmd1.ExecuteNonQuery();
        //        con.Close();
        //    }

        //    return "";
        //}
        public string Save_MasterData(string sqlType, string tcoType, string plan, string planNew, string years, string planPostgre, string region ,string Currency)
        {



            SqlConnection con = new SqlConnection(_ConnectionString);
            using (con)
            {
                SqlCommand cmd = new SqlCommand("truncate table Tbl_Save_Mastervalues", con);
                SqlCommand cmd1 = new SqlCommand("insert into Tbl_Save_Mastervalues (sqlType,tcoType,plans,planNew,years,planPostgre,dataStatus,IsFilterReset,region,currency) values ('" + sqlType + "','" + tcoType + "','" + plan + "','" + planNew + "','" + years + "','" + planPostgre + "',1,0,'" + region + "','" + Currency + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                cmd1.ExecuteNonQuery();
                con.Close();
            }



            return "";
        }
        public string Save_PhysicalServerData(dynamic phy)
        {
            SaveCostInDB(phy, "Tbl_Save_physicalserver");
            return "";
        }
        public string Save_Database(dynamic SQLVersionLicenseDetail1, dynamic Datab1)
        {
            SaveCostInDB(SQLVersionLicenseDetail1, "Tbl_Save_SqlVersionLicense");
            SaveCostInDB(Datab1, "Tbl_Save_DatabaseDetail");
            return "";
        }
        public string Save_StorageData(dynamic lst)
        {
            SaveCostInDB(lst, "Tbl_Save_StorageData");
            return " ";
        }
        public string Save_benefitData(dynamic Rentingbenefit)
        {

            using (SqlConnection con = new SqlConnection(_ConnectionString))
            {
                using (SqlCommand command = new SqlCommand("truncate table Tbl_Save_RentingBenefits", con))
                {
                    con.Open();
                    command.ExecuteNonQuery();
                    SqlCommand cmd1 = new SqlCommand();
                    int x = 0;
                    foreach (var item in Rentingbenefit)
                    {
                        item.year1.Difference = item.year1.Difference == null ? 0 : item.year1.Difference;
                        item.year2.Difference = item.year2.Difference == null ? 0 : item.year2.Difference;
                        item.year3.Difference = item.year3.Difference == null ? 0 : item.year3.Difference;
                        item.year4.Difference = item.year4.Difference == null ? 0 : item.year4.Difference;
                        item.year5.Difference = item.year5.Difference == null ? 0 : item.year5.Difference;
                        item.year1.Total = item.year1.Total == null ? 0 : item.year1.Total;
                        item.year2.Total = item.year2.Total == null ? 0 : item.year2.Total;
                        item.year3.Total = item.year3.Total == null ? 0 : item.year3.Total;
                        item.year4.Total = item.year4.Total == null ? 0 : item.year4.Total;
                        item.year5.Total = item.year5.Total == null ? 0 : item.year5.Total;
                        item.Total = item.Total == null ? 0 : item.Total;


                        if (x == 5)
                        {
                            cmd1 = new SqlCommand("insert into Tbl_Save_RentingBenefits values('" + item.Type + "','" + item.year1.Total + "','" + item.year2.Total + "','" + item.year3.Total + "','" + item.year4.Total + "','" + item.year5.Total + "','" + item.Total + "')", con);
                            cmd1.ExecuteNonQuery();
                        }
                        else
                        {
                            cmd1 = new SqlCommand("insert into Tbl_Save_RentingBenefits values('" + item.Type + "','" + item.year1.Difference + "','" + item.year2.Difference + "','" + item.year3.Difference + "','" + item.year4.Difference + "','" + item.year5.Difference + "','" + item.Total + "')", con);
                            cmd1.ExecuteNonQuery();
                        }

                        x++;
                    }


                    con.Close();
                }
            }

            return "";
        }
        public string Save_benefitDataOwn(dynamic Rentingbenefit)
        {
            using (SqlConnection con = new SqlConnection(_ConnectionString))
            {
                using (SqlCommand command = new SqlCommand("truncate table Tbl_Save_RentingBenefits", con))
                {
                    con.Open();
                    command.ExecuteNonQuery();
                    SqlCommand cmd1 = new SqlCommand();
                    int x = 0;
                    foreach (var item in Rentingbenefit)
                    {
                        item.year1.Difference = item.year1.Difference == null ? 0 : item.year1.Difference;
                        item.year2.Difference = item.year2.Difference == null ? 0 : item.year2.Difference;
                        item.year3.Difference = item.year3.Difference == null ? 0 : item.year3.Difference;
                        item.year4.Difference = item.year4.Difference == null ? 0 : item.year4.Difference;
                        item.year5.Difference = item.year5.Difference == null ? 0 : item.year5.Difference;
                        item.year1.Total = item.year1.Total == null ? 0 : item.year1.Total;
                        item.year2.Total = item.year2.Total == null ? 0 : item.year2.Total;
                        item.year3.Total = item.year3.Total == null ? 0 : item.year3.Total;
                        item.year4.Total = item.year4.Total == null ? 0 : item.year4.Total;
                        item.year5.Total = item.year5.Total == null ? 0 : item.year5.Total;
                        item.Total = item.Total == null ? 0 : item.Total;


                        if (x == 5)
                        {
                            cmd1 = new SqlCommand("insert into Tbl_Save_RentingBenefits values('" + item.Type + "','" + item.year1.Total + "','" + item.year2.Total + "','" + item.year3.Total + "','" + item.year4.Total + "','" + item.year5.Total + "','" + item.Total + "')", con);
                            cmd1.ExecuteNonQuery();
                        }
                        else
                        {
                            cmd1 = new SqlCommand("insert into Tbl_Save_RentingBenefits values('" + item.Type + "','" + item.year1.Difference + "','" + item.year2.Difference + "','" + item.year3.Difference + "','" + item.year4.Difference + "','" + item.year5.Difference + "','" + item.Total + "')", con);
                            cmd1.ExecuteNonQuery();
                        }

                        x++;
                    }


                    con.Close();
                }
            }

            return "";
        }

        public string Save_MigrationData(dynamic Migration)
        {
            SaveCostInDB(Migration, "Tbl_Save_MigrationData");
            return "";
        }
        public string Save_CashFlowData(dynamic lstobj)
        {
            SaveCostInDB(lstobj, "Tbl_Save_Cashflow");
            return "";
        }
        public void saveOnPremiseEditData(dynamic Editlist)
        {
            SqlConnection con = new SqlConnection(_ConnectionString);
            using (con)
            {
                using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
                {
                    SqlCommand cmd1 = new SqlCommand();
                    con.Open();

                    List<Tbl_Save_OnPremises_Azure_data> output = new List<Tbl_Save_OnPremises_Azure_data>();

                    foreach (var item in Editlist)
                    {
                        output = (from Onpremise in context.GetTable<Tbl_Save_OnPremises_Azure_data>()
                                  where (Onpremise.Year == "1 Year" &&
                                  (Onpremise.Type == "Hardware"
                                  || Onpremise.Type == "Hardware Maintanence Cost"
                                  || Onpremise.Type == "Software (Linux)"
                                  || Onpremise.Type == "Software (Windows)"
                                  || Onpremise.Type == "Electricity"
                                  || Onpremise.Type == "Bandwidth"
                                  || Onpremise.Type == "Azure Advisor"
                                  || Onpremise.Type == "Azure Security Center"
                                  || Onpremise.Type == "Storage"
                                  || Onpremise.Type == "It Labor"
                                  || Onpremise.Type == "Oracle License"
                                  || Onpremise.Type == "Sa(Oracle)"
                                  || Onpremise.Type == "BizTalk"
                                  || Onpremise.Type == "Sql License Cost"
                                  || Onpremise.Type == "Data Center"
                                  || Onpremise.Type == "Virtualization Cost"))
                                  select Onpremise).ToList();
                        output = output.Where(s => s.Type == item.category).ToList();

                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year1 + " WHERE Year = '1 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year2 + " WHERE Year = '2 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year3 + " WHERE Year = '3 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year4 + " WHERE Year = '4 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year5 + " WHERE Year = '5 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                    }
                    con.Close();
                }
            }
        }
        public void saveOnPremiseEditDataOwn(dynamic Editlist)
        {
            SqlConnection con = new SqlConnection(_ConnectionString);
            using (con)
            {
                using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
                {
                    SqlCommand cmd1 = new SqlCommand();
                    con.Open();
                    List<Tbl_Save_OnPremises_Azure_data> output = new List<Tbl_Save_OnPremises_Azure_data>();
                    foreach (var item in Editlist)
                    {
                        output = (from Onpremise in context.GetTable<Tbl_Save_OnPremises_Azure_data>()
                                  where (Onpremise.Year == "1 Year" && (Onpremise.Type == "Hardware" || Onpremise.Type == "Hardware Maintanence Cost"
                                      || Onpremise.Type == "Software (Linux)" || Onpremise.Type == "Software (Windows)" || Onpremise.Type == "Electricity" || Onpremise.Type == "Bandwidth" || Onpremise.Type == "Azure Advisor" || Onpremise.Type == "Azure Security Center" || Onpremise.Type == "Storage" || Onpremise.Type == "It Labor" || Onpremise.Type == "End Point" || Onpremise.Type == "BizTalk" || Onpremise.Type == "Sql License Cost" || Onpremise.Type == "Data Center" || Onpremise.Type == "Virtualization Cost"))
                                  select Onpremise).ToList();
                        output = output.Where(s => s.Type == item.category).ToList();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year1 + " WHERE Year = '1 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year2 + " WHERE Year = '2 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year3 + " WHERE Year = '3 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year4 + " WHERE Year = '4 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();
                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET OnPremise =  " + item.Year5 + " WHERE Year = '5 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                    }
                    con.Close();
                }
            }
        }
        public void saveAzureEditData(dynamic Editlist)
        {
            SqlConnection con = new SqlConnection(_ConnectionString);
            using (con)
            {
                using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
                {

                    SqlCommand cmd1 = new SqlCommand();
                    con.Open();


                    List<Tbl_Save_OnPremises_Azure_data> output = new List<Tbl_Save_OnPremises_Azure_data>();

                    foreach (var item in Editlist)
                    {

                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET Azure =  " + item.Year1 + " WHERE Year = '1 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET Azure =  " + item.Year2 + " WHERE Year = '2 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET Azure =  " + item.Year3 + " WHERE Year = '3 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET Azure =  " + item.Year4 + " WHERE Year = '4 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                        cmd1 = new SqlCommand("UPDATE Tbl_Save_OnPremises_Azure_data SET Azure =  " + item.Year5 + " WHERE Year = '5 Year' and Type = '" + item.category + "' ", con);
                        cmd1.ExecuteNonQuery();

                    }
                    con.Close();
                }
            }
        }
        public string Save_AssumptionData(dynamic Assumptions, string currencyname, dynamic SoftwareCostAssumption, int VMCount)
        {
            SqlConnection con = new SqlConnection(_ConnectionString);
            using (con)
            {
                SqlCommand cmd1 = new SqlCommand();
                con.Open();
                foreach (var item in Assumptions.BizTalkLicenseCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_BizTalkLicenseCost SET Price =  " + item.Price + "   WHERE ID =  " + item.id + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.CostForVirtualizedVM)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_CostForVirtualizedVMs SET Price =  " + item.Price + "   WHERE ID =  " + item.id + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.OracleDbCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_OracleDbCost SET Cost =  " + item.Cost + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                //foreach (var item in Assumptions.EndPointProtection)
                //{
                //    cmd1 = new SqlCommand("UPDATE Tbl_EndPointProtection SET Price =  " + item.Price + "   WHERE ID =  " + item.id + " ", con);
                //    cmd1.ExecuteNonQuery();
                //}
                foreach (var item in Assumptions.MigrationCost)
                {
                    if (VMCount < 1000)
                    {
                        cmd1 = new SqlCommand("UPDATE Tbl_MigrationCost SET VM_1_1000_Price =  " + item.VM_1_1000_Price + "   WHERE ID =  " + item.id + " ", con);
                        cmd1.ExecuteNonQuery();
                    }
                    else if (VMCount < 2000)
                    {
                        cmd1 = new SqlCommand("UPDATE Tbl_MigrationCost SET VM_1000_2000_Price =  " + item.VM_1000_2000_Price + "   WHERE ID =  " + item.id + " ", con);
                        cmd1.ExecuteNonQuery();
                    }
                    else if (VMCount < 3000)
                    {
                        cmd1 = new SqlCommand("UPDATE Tbl_MigrationCost SET VM_2000_3000_Price =  " + item.VM_2000_3000_Price + "   WHERE ID =  " + item.id + " ", con);
                        cmd1.ExecuteNonQuery();
                    }
                    else if (VMCount < 4000)
                    {
                        cmd1 = new SqlCommand("UPDATE Tbl_MigrationCost SET VM_3000_4000_Price =  " + item.VM_3000_4000_Price + "   WHERE ID =  " + item.id + " ", con);
                        cmd1.ExecuteNonQuery();
                    }
                    else
                    {
                        cmd1 = new SqlCommand("UPDATE Tbl_MigrationCost SET VM_4000_5000_Price =  " + item.VM_4000_5000_Price + "   WHERE ID =  " + item.id + " ", con);
                        cmd1.ExecuteNonQuery();
                    }
                }
                foreach (var item in Assumptions.databaseCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_DatabaseCost SET Cost =  " + item.Cost + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.datacenterCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_DataCenterCost SET RackUnitsRequired =  " + item.RackUnitsRequired + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.electricityCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_ElectricityCost SET PowerRating =  " + item.PowerRating + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.hardwareCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_HardwareCost SET Price =  " + item.Price + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.itlabourCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_ITlaborCost SET ITLaborCost =  " + item.ITLaborCost + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.softwareCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_SoftwareCost SET WindowsDatacenterLicenseCost =  " + item.WindowsDatacenterLicenseCost + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.storageCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_StorageCost SET CostPerGB =  " + item.CostPerGB + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in SoftwareCostAssumption)
                {
                    cmd1 = new SqlCommand("UPDATE SoftwareCostAssumption SET Pricing =  " + item.Pricing + "   WHERE OS =  '" + item.OS + "' ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.DataCenterConstructionCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_DataCenterConstructionCost SET RackUnitRequired =  " + item.RackUnitRequired + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.NetworkingCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_NetworkingCost SET Cost =  " + item.Cost + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }
                foreach (var item in Assumptions.ElectricityCost_KW)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_ElectricityCost_KW SET Cost =  " + item.Cost + "   WHERE ID =  " + item.ID + " ", con);
                    cmd1.ExecuteNonQuery();
                }

                foreach (var item in Assumptions.VirtualizationCost)
                {
                    cmd1 = new SqlCommand("UPDATE Tbl_VirtualizationCost SET VirtualisationCost =  " + item.VirtualisationCost + " WHERE Type =  '" + item.Type + "' ", con);
                    cmd1.ExecuteNonQuery();
                }


                //foreach (var item in Assumptions.storageCost)
                //{
                //    cmd1 = new SqlCommand("UPDATE SQLServerAssumption SET CostPerGB =  " + item.Pricing + "   WHERE ID =  " + item.ID + " ", con);
                //    cmd1.ExecuteNonQuery();
                //}
                con.Close();
            }
            SqlConnection conStr = new SqlConnection(ConfigurationManager.ConnectionStrings["UCCloudReconConnectionString"].ConnectionString);
            using (conStr)
            {
                SqlCommand cmd1 = new SqlCommand();
                conStr.Open();
                cmd1 = new SqlCommand("UPDATE CurrentCurrencyRates SET Symbol = 0  where Symbol = 1", conStr);
                cmd1.ExecuteNonQuery();
                cmd1 = new SqlCommand("UPDATE CurrentCurrencyRates SET Symbol = 1   WHERE CurrencyName = '" + currencyname + "' ", conStr);
                cmd1.ExecuteNonQuery();
            }
            return "";
        }
        public DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public void SaveCostInDB<T>(List<T> list, string TableName)
        {
            DataTable dt = new DataTable("MyTable");
            dt = ConvertToDataTable(list);

            using (SqlConnection conn = new SqlConnection(_ConnectionString))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    try
                    {
                        conn.Open();
                        //command.CommandTimeout = 50000;
                        //command.ExecuteNonQuery();
                        using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                        {
                            bulkCopy.DestinationTableName = TableName;
                            bulkCopy.WriteToServer(dt);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception properly
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }
        public List<Tbl_Save_physicalserver> get_Tbl_Save_physicalserver()
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_physicalserver>().ToList();
            }
        }
        public List<Tbl_Save_DatabaseDetail> get_DatabaseCalculationRequire()
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_DatabaseDetail>().ToList();
            }
        }
        public List<Tbl_Save_SqlVersionLicense> get_SqlVersionLicenseRequire()
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_SqlVersionLicense>().ToList();
            }
        }
        public List<Tbl_Save_StorageData> get_StorageDataRequire()
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_StorageData>().ToList();
            }
        }
        public List<Tbl_Save_MigrationData> Get_MigrationSaveData()
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_MigrationData>().ToList();
            }
        }
        public List<Tbl_Save_Mastervalue> get_MasterData()
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_Mastervalue>().ToList();
            }
        }
        public List<Tbl_Save_OnPremises_Azure_data> get_Tbl_Save_OnPremises_Azure_data()
        {

            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_OnPremises_Azure_data>().ToList();
            }
        }
        public List<Tbl_Save_OnPremises_Azure_data_AI> get_Tbl_Save_OnPremises_Azure_data_AIS()
        {

            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_OnPremises_Azure_data_AI>().ToList();
            }
        }
        public List<Tbl_Save_RentingBenefit> Get_RentingBenefitsSaveData(string TableName)
        {
            using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
            {
                return context.GetTable<Tbl_Save_RentingBenefit>().ToList();
            }
        }
        public Boolean ResetCostInDB()
        {
            bool flag = false;
            using (SqlConnection conn = new SqlConnection(_ConnectionString))
            {
                SqlCommand sqlCommand = new SqlCommand("Sp_TCOReset", conn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.Add("@flag", SqlDbType.Int).Direction = ParameterDirection.Output;
                conn.Open();
                sqlCommand.ExecuteScalar();

                int ResetStatus = Convert.ToInt32(sqlCommand.Parameters["@flag"].Value);
                if (ResetStatus == 1)
                {
                    flag = true;
                }

            }
            return flag;


        }
        public void ResetFilterInDB()
        {
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                var data = context.Tbl_Save_Mastervalues.FirstOrDefault();
                data.IsFilterReset = true;
                data.sqlType = string.Empty;
                data.tcoType = "all";
                data.plans = "threeyearhybrid";
                data.planNew = "threeyearhybrid";
                data.planPostgre = "threeyear";
                data.years = "5";
                data.dataStatus = true;
                context.SubmitChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<ReconLiftandShift_MultiCurrency_MLSResult> GetReconLiftShift_MLSData(string CurrencyMode, string sizingType)
        {
            List<ReconLiftandShift_MultiCurrency_MLSResult> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.ReconLiftandShift_MultiCurrency_MLS(CurrencyMode, sizingType).ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Sp_GetReconLiftandShift_InputDataNewResult> GetReconLiftandShiftInputData(string currency, string sizingType)
        {
            try
            {
                using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
                {
                    List<ReconLiftandShiftDTO> MachineList = null;
                    if (sizingType == "sizingonutil")
                    {
                        var input = context.ReconLiftandShift_InputData_SizingType(sizingType).ToList();
                        MachineList = (from item in input
                                       select new ReconLiftandShiftDTO
                                       {
                                           Id = item.id,
                                           ComputerName = item.ComputerName,
                                           Platform = item.Platform,
                                           CurrentOperatingSystem = item.CurrentOperatingSystem,
                                           VMType = item.VMType,
                                           EnvironmentType = item.Environment,
                                           OSType = item.OSType,
                                           LicenseType = item.LicenseType,

                                           Cores = item.Cores,
                                           SystemMemory_GB = item.SystemMemory_GB_,
                                           NICCount = item.NICCount,
                                           Storage_GB = item.Storage_GB_,
                                           MaxNetworkThroughputMB_S = item.MaxNetworkThroughputMB_S,

                                           IPAddress = item.IPAddress,
                                           RegionID = item.RegionID,
                                           City = item.City,
                                           Country = item.Country,
                                           Role = item.Role,
                                           OrgUnit = item.OrgUnit,

                                           Cores2 = item.Cores2,
                                           IOPS2 = item.IOPS2,
                                           SystemMemory_GB_2 = item.SystemMemory_GB_2,
                                           NICCount2 = item.NICCount2,
                                           Storage_GB2 = item.Storage_GB_2,
                                           MaxNetworkThroughputMB_S2 = item.MaxNetworkThroughputMB_S2,

                                           IOPS = item.IOPS,
                                           Used_Storage_GB = item.Used_Storage_GB_,

                                           StorageSize = item.AzureStorageSize,
                                           StorageType = item.StorageType,
                                           StorageSizeDesc = item.StorageDesc,

                                           CriticalFactor = item.CriticalFactor,

                                           AvgCPUUtilization_Per = item.AvgCPUUtilization_95per,
                                           AvgCoreUtilizationCountAssumption = item.CPUAssumption,
                                           AvgCoreUtilizationCount = item.AvgCoreUtilizationCount95per,
                                           AvgRAMUtilization_Per = item.AvgRAMUtilization_95per,
                                           AvgRAMUtilization_GBAssumption = item.RAMAssumption,
                                           AvgRAMUtilization_GB = item.AvgRAMUtilization_GB_95per,

                                           AvgAzureVmSize = (item.AzureVmSize == null ? item.AzureVmSize : item.AzureVmSize.ToUpper()),
                                           AvgAzureVmSizeDesc = item.AzureVmDesc,

                                           AvgMonthlyPrice_Payasyougo =
                                           (currency == "USD" ? item.MonthlyPrice_Payasyougo :
                                           (currency == "EUR" ? item.MonthlyPrice_Payasyougo_EUR :
                                           (currency == "GBP" ? item.MonthlyPrice_Payasyougo_GBP :
                                           (currency == "AUD" ? item.MonthlyPrice_Payasyougo_AUD :
                                           (currency == "INR" ? item.MonthlyPrice_Payasyougo_INR :
                                           (currency == "CAD" ? item.MonthlyPrice_Payasyougo_CAD :
                                           (currency == "MYR" ? item.MonthlyPrice_Payasyougo_MYR :
                                           (currency == "KRW" ? item.MonthlyPrice_Payasyougo_KRW :
                                           (currency == "IDR" ? item.MonthlyPrice_Payasyougo_IDR :
                                           (currency == "NZD" ? item.MonthlyPrice_Payasyougo_NZD :
                                           (currency == "ZAR" ? item.MonthlyPrice_Payasyougo_ZAR :
                                           (currency == "SAR" ? item.MonthlyPrice_Payasyougo_SAR :
                                           (currency == "JPY" ? item.MonthlyPrice_Payasyougo_JPY : null
                                           ))))))))))))),

                                           AvgMonthlyPrice_Payasyougo_Hybrid =
                                             (currency == "USD" ? item.MonthlyPrice_Payasyougo_Hybrid :
                                             (currency == "EUR" ? item.MonthlyPrice_Payasyougo_Hybrid_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_Payasyougo_Hybrid_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_Payasyougo_Hybrid_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_Payasyougo_Hybrid_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_Payasyougo_Hybrid_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_Payasyougo_Hybrid_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_Payasyougo_Hybrid_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_Payasyougo_Hybrid_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_Payasyougo_Hybrid_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_Payasyougo_Hybrid_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_Payasyougo_Hybrid_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_Payasyougo_Hybrid_JPY : null
                                             ))))))))))))),

                                           AvgMonthlyPrice_One_Year =
                                           (currency == "USD" ? item.MonthlyPrice_One_Year :
                                           (currency == "EUR" ? item.MonthlyPrice_One_Year_EUR :
                                           (currency == "GBP" ? item.MonthlyPrice_One_Year_GBP :
                                           (currency == "AUD" ? item.MonthlyPrice_One_Year_AUD :
                                           (currency == "INR" ? item.MonthlyPrice_One_Year_INR :
                                           (currency == "CAD" ? item.MonthlyPrice_One_Year_CAD :
                                           (currency == "MYR" ? item.MonthlyPrice_One_Year_MYR :
                                           (currency == "KRW" ? item.MonthlyPrice_One_Year_KRW :
                                           (currency == "IDR" ? item.MonthlyPrice_One_Year_IDR :
                                           (currency == "NZD" ? item.MonthlyPrice_One_Year_NZD :
                                           (currency == "ZAR" ? item.MonthlyPrice_One_Year_ZAR :
                                           (currency == "SAR" ? item.MonthlyPrice_One_Year_SAR :
                                           (currency == "JPY" ? item.MonthlyPrice_One_Year_JPY : null
                                           ))))))))))))),

                                           AvgMonthlyPrice_One_Year_Hybrid =
                                             (currency == "USD" ? item.MonthlyPrice_One_Year_Hybrid :
                                             (currency == "EUR" ? item.MonthlyPrice_One_Year_Hybrid_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_One_Year_Hybrid_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_One_Year_Hybrid_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_One_Year_Hybrid_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_One_Year_Hybrid_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_One_Year_Hybrid_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_One_Year_Hybrid_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_One_Year_Hybrid_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_One_Year_Hybrid_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_One_Year_Hybrid_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_One_Year_Hybrid_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_One_Year_Hybrid_JPY : null
                                             ))))))))))))),

                                           AvgMonthlyPrice_Three_Year =
                                             (currency == "USD" ? item.MonthlyPrice_Three_Year :
                                             (currency == "EUR" ? item.MonthlyPrice_Three_Year_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_Three_Year_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_Three_Year_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_Three_Year_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_Three_Year_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_Three_Year_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_Three_Year_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_Three_Year_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_Three_Year_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_Three_Year_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_Three_Year_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_Three_Year_JPY : null
                                             ))))))))))))),

                                           AvgMonthlyPrice_Three_Year_Hybrid =
                                             (currency == "USD" ? item.MonthlyPrice_Three_Year_Hybrid :
                                             (currency == "EUR" ? item.MonthlyPrice_Three_Year_Hybrid_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_Three_Year_Hybrid_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_Three_Year_Hybrid_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_Three_Year_Hybrid_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_Three_Year_Hybrid_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_Three_Year_Hybrid_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_Three_Year_Hybrid_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_Three_Year_Hybrid_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_Three_Year_Hybrid_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_Three_Year_Hybrid_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_Three_Year_Hybrid_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_Three_Year_Hybrid_JPY : null
                                             ))))))))))))),

                                           StoragePrice =
                                             (currency == "USD" ? Math.Round(Convert.ToDouble(item.StoragePrice), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "EUR" ? Math.Round(Convert.ToDouble(item.StoragePrice_EUR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "GBP" ? Math.Round(Convert.ToDouble(item.StoragePrice_GBP), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "AUD" ? Math.Round(Convert.ToDouble(item.StoragePrice_AUD), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "INR" ? Math.Round(Convert.ToDouble(item.StoragePrice_INR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "CAD" ? Math.Round(Convert.ToDouble(item.StoragePrice_CAD), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "MYR" ? Math.Round(Convert.ToDouble(item.StoragePrice_MYR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "KRW" ? Math.Round(Convert.ToDouble(item.StoragePrice_KRW), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "IDR" ? Math.Round(Convert.ToDouble(item.StoragePrice_IDR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "NZD" ? Math.Round(Convert.ToDouble(item.StoragePrice_NZD), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "ZAR" ? Math.Round(Convert.ToDouble(item.StoragePrice_ZAR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "SAR" ? Math.Round(Convert.ToDouble(item.StoragePrice_SAR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "JPY" ? Math.Round(Convert.ToDouble(item.StoragePrice_JPY), 2, MidpointRounding.AwayFromZero) : 00
                                             ))))))))))))),

                                           DatabaseRunning = item.DatabaseRunning,
                                           Included = item.Included,
                                           Tagging = item.Tagging,
                                           Groups = item.Groups,
                                           IsModification = item.IsModification,
                                           ModifiedBy = item.ModifiedBy,
                                           ExcludedServer = item.ExcludedServer,
                                           WorkLoads = item.WorkLoads,
                                           Status = item.Status
                                       }).OrderBy(x => x.Id).ToList();

                    }
                    if (sizingType == "sizingonbasic")
                    {
                        var input = context.ReconLiftandShift_InputData_SizingType(sizingType).ToList();
                        MachineList = (from item in context.ReconLiftandShift_InputData_SizingType(sizingType)
                                       select new ReconLiftandShiftDTO
                                       {

                                           Id = item.id,
                                           ComputerName = item.ComputerName,
                                           Platform = item.Platform,
                                           CurrentOperatingSystem = item.CurrentOperatingSystem,
                                           VMType = item.VMType,
                                           EnvironmentType = item.Environment,
                                           OSType = item.OSType,
                                           LicenseType = item.LicenseType,

                                           Cores = item.Cores,
                                           SystemMemory_GB = item.SystemMemory_GB_,
                                           NICCount = item.NICCount,
                                           Storage_GB = item.Storage_GB_,
                                           MaxNetworkThroughputMB_S = item.MaxNetworkThroughputMB_S,

                                           IPAddress = item.IPAddress,
                                           RegionID = item.RegionID,
                                           City = item.City,
                                           Country = item.Country,
                                           Role = item.Role,
                                           OrgUnit = item.OrgUnit,

                                           Cores2 = item.Cores2,
                                           IOPS2 = item.IOPS2,
                                           SystemMemory_GB_2 = item.SystemMemory_GB_2,
                                           NICCount2 = item.NICCount2,
                                           Storage_GB2 = item.Storage_GB_2,
                                           MaxNetworkThroughputMB_S2 = item.MaxNetworkThroughputMB_S2,

                                           IOPS = item.IOPS,
                                           Used_Storage_GB = item.Used_Storage_GB_,

                                           StorageSize = item.AzureStorageSize,
                                           StorageType = item.StorageType,
                                           StorageSizeDesc = item.StorageDesc,

                                           CriticalFactor = item.CriticalFactor,

                                           AvgCPUUtilization_Per = item.AvgCPUUtilization_95per,
                                           AvgCoreUtilizationCountAssumption = item.CPUAssumption,
                                           AvgCoreUtilizationCount = item.AvgCoreUtilizationCount95per,
                                           AvgRAMUtilization_Per = item.AvgRAMUtilization_95per,
                                           AvgRAMUtilization_GBAssumption = item.RAMAssumption,
                                           AvgRAMUtilization_GB = item.AvgRAMUtilization_GB_95per,

                                           AvgAzureVmSize = (item.AzureVmSize == null ? item.AzureVmSize : item.AzureVmSize.ToUpper()),
                                           AvgAzureVmSizeDesc = item.AzureVmDesc,

                                           AvgMonthlyPrice_Payasyougo =
                                           (currency == "USD" ? item.MonthlyPrice_Payasyougo :
                                           (currency == "EUR" ? item.MonthlyPrice_Payasyougo_EUR :
                                           (currency == "GBP" ? item.MonthlyPrice_Payasyougo_GBP :
                                           (currency == "AUD" ? item.MonthlyPrice_Payasyougo_AUD :
                                           (currency == "INR" ? item.MonthlyPrice_Payasyougo_INR :
                                           (currency == "CAD" ? item.MonthlyPrice_Payasyougo_CAD :
                                           (currency == "MYR" ? item.MonthlyPrice_Payasyougo_MYR :
                                           (currency == "KRW" ? item.MonthlyPrice_Payasyougo_KRW :
                                           (currency == "IDR" ? item.MonthlyPrice_Payasyougo_IDR :
                                           (currency == "NZD" ? item.MonthlyPrice_Payasyougo_NZD :
                                           (currency == "ZAR" ? item.MonthlyPrice_Payasyougo_ZAR :
                                           (currency == "SAR" ? item.MonthlyPrice_Payasyougo_SAR :
                                           (currency == "JPY" ? item.MonthlyPrice_Payasyougo_JPY : null
                                           ))))))))))))),

                                           AvgMonthlyPrice_Payasyougo_Hybrid =
                                             (currency == "USD" ? item.MonthlyPrice_Payasyougo_Hybrid :
                                             (currency == "EUR" ? item.MonthlyPrice_Payasyougo_Hybrid_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_Payasyougo_Hybrid_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_Payasyougo_Hybrid_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_Payasyougo_Hybrid_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_Payasyougo_Hybrid_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_Payasyougo_Hybrid_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_Payasyougo_Hybrid_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_Payasyougo_Hybrid_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_Payasyougo_Hybrid_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_Payasyougo_Hybrid_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_Payasyougo_Hybrid_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_Payasyougo_Hybrid_JPY : null
                                             ))))))))))))),

                                           AvgMonthlyPrice_One_Year =
                                           (currency == "USD" ? item.MonthlyPrice_One_Year :
                                           (currency == "EUR" ? item.MonthlyPrice_One_Year_EUR :
                                           (currency == "GBP" ? item.MonthlyPrice_One_Year_GBP :
                                           (currency == "AUD" ? item.MonthlyPrice_One_Year_AUD :
                                           (currency == "INR" ? item.MonthlyPrice_One_Year_INR :
                                           (currency == "CAD" ? item.MonthlyPrice_One_Year_CAD :
                                           (currency == "MYR" ? item.MonthlyPrice_One_Year_MYR :
                                           (currency == "KRW" ? item.MonthlyPrice_One_Year_KRW :
                                           (currency == "IDR" ? item.MonthlyPrice_One_Year_IDR :
                                           (currency == "NZD" ? item.MonthlyPrice_One_Year_NZD :
                                           (currency == "ZAR" ? item.MonthlyPrice_One_Year_ZAR :
                                           (currency == "SAR" ? item.MonthlyPrice_One_Year_SAR :
                                           (currency == "JPY" ? item.MonthlyPrice_One_Year_JPY : null
                                           ))))))))))))),

                                           AvgMonthlyPrice_One_Year_Hybrid =
                                             (currency == "USD" ? item.MonthlyPrice_One_Year_Hybrid :
                                             (currency == "EUR" ? item.MonthlyPrice_One_Year_Hybrid_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_One_Year_Hybrid_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_One_Year_Hybrid_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_One_Year_Hybrid_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_One_Year_Hybrid_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_One_Year_Hybrid_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_One_Year_Hybrid_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_One_Year_Hybrid_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_One_Year_Hybrid_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_One_Year_Hybrid_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_One_Year_Hybrid_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_One_Year_Hybrid_JPY : null
                                             ))))))))))))),

                                           AvgMonthlyPrice_Three_Year =
                                             (currency == "USD" ? item.MonthlyPrice_Three_Year :
                                             (currency == "EUR" ? item.MonthlyPrice_Three_Year_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_Three_Year_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_Three_Year_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_Three_Year_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_Three_Year_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_Three_Year_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_Three_Year_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_Three_Year_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_Three_Year_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_Three_Year_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_Three_Year_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_Three_Year_JPY : null
                                             ))))))))))))),

                                           AvgMonthlyPrice_Three_Year_Hybrid =
                                             (currency == "USD" ? item.MonthlyPrice_Three_Year_Hybrid :
                                             (currency == "EUR" ? item.MonthlyPrice_Three_Year_Hybrid_EUR :
                                             (currency == "GBP" ? item.MonthlyPrice_Three_Year_Hybrid_GBP :
                                             (currency == "AUD" ? item.MonthlyPrice_Three_Year_Hybrid_AUD :
                                             (currency == "INR" ? item.MonthlyPrice_Three_Year_Hybrid_INR :
                                             (currency == "CAD" ? item.MonthlyPrice_Three_Year_Hybrid_CAD :
                                             (currency == "MYR" ? item.MonthlyPrice_Three_Year_Hybrid_MYR :
                                             (currency == "KRW" ? item.MonthlyPrice_Three_Year_Hybrid_KRW :
                                             (currency == "IDR" ? item.MonthlyPrice_Three_Year_Hybrid_IDR :
                                             (currency == "NZD" ? item.MonthlyPrice_Three_Year_Hybrid_NZD :
                                             (currency == "ZAR" ? item.MonthlyPrice_Three_Year_Hybrid_ZAR :
                                             (currency == "SAR" ? item.MonthlyPrice_Three_Year_Hybrid_SAR :
                                             (currency == "JPY" ? item.MonthlyPrice_Three_Year_Hybrid_JPY : null
                                             ))))))))))))),

                                           StoragePrice =
                                             (currency == "USD" ? Math.Round(Convert.ToDouble(item.StoragePrice), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "EUR" ? Math.Round(Convert.ToDouble(item.StoragePrice_EUR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "GBP" ? Math.Round(Convert.ToDouble(item.StoragePrice_GBP), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "AUD" ? Math.Round(Convert.ToDouble(item.StoragePrice_AUD), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "INR" ? Math.Round(Convert.ToDouble(item.StoragePrice_INR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "CAD" ? Math.Round(Convert.ToDouble(item.StoragePrice_CAD), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "MYR" ? Math.Round(Convert.ToDouble(item.StoragePrice_MYR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "KRW" ? Math.Round(Convert.ToDouble(item.StoragePrice_KRW), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "IDR" ? Math.Round(Convert.ToDouble(item.StoragePrice_IDR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "NZD" ? Math.Round(Convert.ToDouble(item.StoragePrice_NZD), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "ZAR" ? Math.Round(Convert.ToDouble(item.StoragePrice_ZAR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "SAR" ? Math.Round(Convert.ToDouble(item.StoragePrice_SAR), 2, MidpointRounding.AwayFromZero) :
                                             (currency == "JPY" ? Math.Round(Convert.ToDouble(item.StoragePrice_JPY), 2, MidpointRounding.AwayFromZero) : 0
                                             ))))))))))))),

                                           DatabaseRunning = item.DatabaseRunning,
                                           Included = item.Included,
                                           Tagging = item.Tagging,
                                           Groups = item.Groups,
                                           IsModification = item.IsModification,
                                           ModifiedBy = item.ModifiedBy,
                                           ExcludedServer = item.ExcludedServer,
                                           WorkLoads = item.WorkLoads,
                                           Status = item.Status
                                       }).OrderBy(x => x.Id).ToList();

                    }

                    foreach (var ExMachine in MachineList.Where(x => x.Included == false))
                    {
                        ExMachine.AvgMonthlyPrice_Payasyougo = null;
                        ExMachine.AvgAzureVmSize = null;
                        ExMachine.AvgAzureVmSizeDesc = null;
                        ExMachine.AvgMonthlyPrice_Payasyougo = null;
                        ExMachine.AvgMonthlyPrice_Payasyougo_Hybrid = null;
                        ExMachine.AvgMonthlyPrice_One_Year = null;
                        ExMachine.AvgMonthlyPrice_One_Year_Hybrid = null;
                        ExMachine.AvgMonthlyPrice_Three_Year = null;
                        ExMachine.AvgMonthlyPrice_Three_Year_Hybrid = null;
                        ExMachine.StoragePrice = null;
                        ExMachine.StorageSize = null;
                        ExMachine.StorageSizeDesc = null;
                    }

                    List<Sp_GetReconLiftandShift_InputDataNewResult> MachineListNew = new List<Sp_GetReconLiftandShift_InputDataNewResult>();
                    MachineList.ForEach(item =>
                    {
                        Sp_GetReconLiftandShift_InputDataNewResult lstitem = new Sp_GetReconLiftandShift_InputDataNewResult();
                        lstitem.Id = item.Id;
                        lstitem.ComputerName = item.ComputerName;
                        lstitem.Platform = item.Platform;
                        lstitem.OSType = item.OSType;
                        lstitem.LicenseType = item.LicenseType;
                        lstitem.CurrentOperatingSystem = item.CurrentOperatingSystem;
                        lstitem.Environment = item.EnvironmentType;
                        lstitem.Cores = item.Cores;
                        lstitem.SystemMemory_GB_ = item.SystemMemory_GB;
                        lstitem.NICCount = item.NICCount;
                        lstitem.IOPS = item.IOPS;
                        lstitem.MaxNetworkThroughputMB_S = item.MaxNetworkThroughputMB_S;
                        lstitem.Storage_GB_ = item.Storage_GB;
                        lstitem.Used_Storage_GB_ = item.Used_Storage_GB;
                        lstitem.IPAddress = item.IPAddress;
                        lstitem.RegionID = item.RegionID;
                        lstitem.City = item.City;
                        lstitem.Country = item.Country;
                        lstitem.Role = item.Role;
                        lstitem.OrgUnit = item.OrgUnit;
                        //lstitem. = item.AvgCPUUtilization_Per;
                        //lstitem. = item.AvgCoreUtilizationCount;
                        //lstitem. = item.AvgCoreUtilizationCountAssumption;
                        lstitem.AvgRAMUtilization_95per = item.AvgRAMUtilization_Per;
                        lstitem.AvgRAMUtilization_GB_95per = item.AvgRAMUtilization_GB;
                        //lstitem. = item.AvgRAMUtilization_GBAssumption;
                        lstitem.DatabaseRunning = item.DatabaseRunning;
                        lstitem.Included = item.Included;
                        lstitem.Cores2 = item.Cores2;
                        lstitem.IOPS2 = item.IOPS2;
                        lstitem.SystemMemory_GB_2 = item.SystemMemory_GB_2;
                        lstitem.NICCount2 = item.NICCount2;
                        lstitem.MaxNetworkThroughputMB_S2 = item.MaxNetworkThroughputMB_S2;
                        lstitem.Storage_GB_2 = item.Storage_GB2;
                        //lstitem. = item.StorageAssumption;
                        lstitem.Tagging = item.Tagging;
                        lstitem.Groups = item.Groups;
                        lstitem.IsModification = item.IsModification;
                        lstitem.ModificationDate = item.ModificationDate;
                        lstitem.ModifiedBy = item.ModifiedBy;
                        lstitem.ExcludedServer = item.ExcludedServer;
                        lstitem.WorkLoads = item.WorkLoads;
                        lstitem.Status = item.Status;
                        lstitem.VMType = item.VMType;
                        lstitem.CriticalFactor = item.CriticalFactor;
                        lstitem.AzureVmSize = item.AvgAzureVmSize;
                        lstitem.AzureVmDesc = item.AvgAzureVmSizeDesc;
                        lstitem.MonthlyPrice_Payasyougo = item.AvgMonthlyPrice_Payasyougo;
                        lstitem.MonthlyPrice_Payasyougo_Hybrid = item.AvgMonthlyPrice_Payasyougo_Hybrid;
                        lstitem.MonthlyPrice_One_Year = item.AvgMonthlyPrice_One_Year;
                        lstitem.MonthlyPrice_One_Year_Hybrid = item.AvgMonthlyPrice_One_Year_Hybrid;
                        lstitem.MonthlyPrice_Three_Year = item.AvgMonthlyPrice_Three_Year;
                        lstitem.MonthlyPrice_Three_Year_Hybrid = item.AvgMonthlyPrice_Three_Year_Hybrid;
                        //lstitem. = item.MLSPrice;
                        //lstitem. = item.MLSPriceType;
                        lstitem.StoragePrice = item.StoragePrice;
                        lstitem.AzureStorageSize = item.StorageSize;
                        lstitem.StorageDesc = item.StorageSizeDesc;
                        lstitem.StorageType = item.StorageType;
                        //lstitem. = item.SA_Applied;

                        MachineListNew.Add(lstitem);
                    });

                    return MachineListNew;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //Save Data For Script
        public List<Tbl_Save_OnPremises_Azure_PaasSQLMI> getAzure_PaasSQLMI()
        {
            List<Tbl_Save_OnPremises_Azure_PaasSQLMI> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_Save_OnPremises_Azure_PaasSQLMI>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Tbl_Save_OnPremises_Azure_PaasSQLVcore> getAzure_PaasSQLVcore()
        {
            List<Tbl_Save_OnPremises_Azure_PaasSQLVcore> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_Save_OnPremises_Azure_PaasSQLVcore>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }

            }
            return data;
        }
        public List<Tbl_Save_OnPremises_Azure_PaasSQLInstancePool> getAzure_PaasSQLInstancePool()
        {
            List<Tbl_Save_OnPremises_Azure_PaasSQLInstancePool> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_Save_OnPremises_Azure_PaasSQLInstancePool>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Tbl_Save_OnPremises_Azure_PaasSQLElasticPool> getAzure_PaasSQLElasticPool()
        {
            List<Tbl_Save_OnPremises_Azure_PaasSQLElasticPool> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_Save_OnPremises_Azure_PaasSQLElasticPool>().ToList();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Tbl_Save_OnPremises_Azure_SQLVM_RightSized> getAzure_IAASRightSize()
        {
            List<Tbl_Save_OnPremises_Azure_SQLVM_RightSized> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_Save_OnPremises_Azure_SQLVM_RightSized>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;
        }
        public List<Tbl_Save_OnPremises_Azure_SQLVM_AsI> getAzure_IAASASIS()
        {
            List<Tbl_Save_OnPremises_Azure_SQLVM_AsI> data = null;
            UCMAPDataContext context = new UCMAPDataContext(_ConnectionString);
            try
            {
                using (context)
                {
                    data = context.GetTable<Tbl_Save_OnPremises_Azure_SQLVM_AsI>().ToList();
                }
            }

            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
            return data;

        }
        public void saveSaCostDetails(string OnPremSaCost, string EntLicCost, string StdLicCost)
        {
            try
            {
                using (UCMAPDataContext context = new UCMAPDataContext(_ConnectionString))
                {
                    context.CommandTimeout = 300;
                    context.Sp_CalculateBoomrangSACost("MI", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangSACost("vCore", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangSACost("InstancePool", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangSACost("ElasticPool", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangSACost("RightSized", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangSACost("AsIs", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangSACost("ComponentVM", Convert.ToDecimal(OnPremSaCost), Convert.ToDecimal(StdLicCost), Convert.ToDecimal(EntLicCost));
                    context.Sp_CalculateBoomrangComponentServiceCost();
                }
            }
            catch (Exception ex)
            {
                double DBID = 0;
                string filePath = ConfigurationManager.AppSettings["TCOErrorLoggerLocation"];
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + " DatabaseID=" + DBID + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
            }
        }


        public void SaveCostInDBHBC<T>(List<T> list, string TableName)
        {
            DataTable dt = new DataTable("MyTable");
            dt = ConvertToDataTable(list);

            using (SqlConnection conn = new SqlConnection(_ConnectionString))
            {
                using (SqlCommand command = new SqlCommand("truncate table Tbl_Save_OnPremises_data_HBC", conn))
                {
                    SqlCommand command1 = new SqlCommand("update Tbl_Save_OnPremises_data_HBC set Azure =0.00 where Type !='IT Labor' and SubItems !='Compute'", conn);
                    SqlCommand command2 = new SqlCommand("update Tbl_Save_OnPremises_data_HBC set OnPremise=0.00 where Type='Sa(SQL)'  or Type = 'Sa(Windows License)' or Type = 'Sa(Linux License)' or Type= 'Sa(Oracle)'", conn);
                    try
                    {
                        conn.Open();
                        command.ExecuteNonQuery();
                        //command.CommandTimeout = 50000;
                        //command.ExecuteNonQuery();
                        using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                        {
                            bulkCopy.DestinationTableName = TableName;
                            bulkCopy.WriteToServer(dt);
                            command1.ExecuteNonQuery();
                            command2.ExecuteNonQuery();
                        }
                    }

                    catch (Exception ex)
                    {
                        // Handle exception properly
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }
     
    }
}
